local P = {}
local W = require("scripts.warehouse")
local C = require("scripts.circuit")
local T = require("scripts.tier")
local R = require("scripts.research")
P.name = "air-logistics-belt-port"
P.interval = 20
P.buffer_name = "air-logistics-storage-bin"
P.belt_types = {"transport-belt", "underground-belt", "splitter", "lane-splitter", "linked-belt"}
P.layout = {
  {x=-1.5, y=-2.5, direction=0, dx=0, dy=-1}, {x=1.5, y=-2.5, direction=0, dx=0, dy=-1},
  {x=2.5, y=-1.5, direction=4, dx=1, dy=0}, {x=2.5, y=1.5, direction=4, dx=1, dy=0},
  {x=-1.5, y=2.5, direction=8, dx=0, dy=1}, {x=1.5, y=2.5, direction=8, dx=0, dy=1},
  {x=-2.5, y=-1.5, direction=12, dx=-1, dy=0}, {x=-2.5, y=1.5, direction=12, dx=-1, dy=0}
}
P.space_layout = {}
for _, side in ipairs({{0,-1,0},{1,0,4},{0,1,8},{-1,0,12}}) do
  for _, offset in ipairs({-3.5,-0.5,3.5}) do
    P.space_layout[#P.space_layout+1] = {x=side[1] == 0 and offset or side[1]*4.5,
      y=side[2] == 0 and offset or side[2]*4.5, dx=side[1], dy=side[2], direction=side[3]}
  end
end
function P.get_layout(tower) return T.get(tower) == T.space and P.space_layout or P.layout end

P.belt_type_set = {}
for _, name in ipairs(P.belt_types) do P.belt_type_set[name] = true end

local function scan_belts(tower)
  local entity = tower.entity
  local position, surface, force = entity.position, entity.surface, entity.force
  local layout = P.get_layout(tower)
  local belts = {}
  for i = 1, #layout do
    local spec = layout[i]
    belts[i] = surface.find_entities_filtered{
      position={position.x+spec.x+spec.dx, position.y+spec.y+spec.dy}, type=P.belt_types, force=force
    }[1]
  end
  tower.port_belts, tower.port_scan_dirty, tower.port_scan_tick = belts, nil, game.tick
  return belts
end

local RESCAN_INTERVAL = 300
local function belts(tower)
  local cached = tower.port_belts
  local stale = cached == nil or tower.port_scan_dirty ~= nil or #cached ~= #P.get_layout(tower)
    or game.tick - (tower.port_scan_tick or 0) >= RESCAN_INTERVAL
  if not stale then
    for i = 1, #cached do
      local belt = cached[i]
      if belt and not belt.valid then stale = true; break end
    end
  end
  if stale then return scan_belts(tower), true end
  return cached, false
end

local spoilage = {}
local function spoil_class(name, quality)
  local key = name .. "/" .. quality
  local cached = spoilage[key]
  if cached == nil then
    local prototype = prototypes.item[name]
    cached = prototype and (prototype.spoil_result ~= nil) and 1 or 0
    cached = cached + ((prototype and prototype.get_spoil_ticks(quality) or 0) > 0 and 2 or 0)
    spoilage[key] = cached
  end
  return cached
end

local stack_sizes = {}
local function item_stack_size(name)
  local size = stack_sizes[name]
  if not size then
    local prototype = prototypes.item[name]
    size = prototype and prototype.stack_size or 1
    stack_sizes[name] = size
  end
  return size
end

local function layout_reach(layout)
  local best = 0
  for _, spec in ipairs(layout) do
    local dx, dy = math.abs(spec.x) + math.abs(spec.dx), math.abs(spec.y) + math.abs(spec.dy)
    local distance = math.sqrt(dx*dx + dy*dy)
    if distance > best then best = distance end
  end
  return best
end

P.query_radius = math.max(layout_reach(P.layout), layout_reach(P.space_layout)) + 1

function P.invalidate(surface, position, type_name)
  if not surface or not surface.valid then return end
  if type_name and not P.belt_type_set[type_name] then return end
  for _, entity in ipairs(surface.find_entities_filtered{
    position=position, radius=P.query_radius, name={T.planet.name,T.space.name}}) do
    local tower = storage.towers[entity.unit_number]
    if tower then tower.port_scan_dirty = true end
  end
end

local function create(tower, spec, name, replace)
  local position = tower.entity.position
  local port = tower.entity.surface.create_entity{
    name=name, position={position.x+spec.x, position.y+spec.y}, force=tower.entity.force,
    direction=spec.direction, type="output", fast_replace=replace
  }
  assert(port, "Air Logistics Tower: could not create belt interface")
  port.destructible, port.operable, port.rotatable = false, false, false
  port.disabled_by_script = true
  return port
end

local function create_buffer(tower, spec)
  local position = tower.entity.position
  local buffer = tower.entity.surface.create_entity{
    name=P.buffer_name, position={position.x+spec.x-2*spec.dx, position.y+spec.y-2*spec.dy}, force=tower.entity.force
  }
  assert(buffer, "Air Logistics Tower: could not create belt transfer buffer")
  buffer.destructible, buffer.operable, buffer.rotatable = false, false, false
  buffer.get_or_create_control_behavior().read_contents = false
  return buffer
end

local function drain(port, tower, buffer)
  local inventory = buffer.get_inventory(defines.inventory.chest)
  for i=1,#inventory do if inventory[i].valid_for_read then W.restore(tower, inventory[i]) end end
  for lane=1,2 do
    local line = port.get_transport_line(lane)
    local rounds = 0
    while #line>0 do
      rounds = rounds + 1
      if rounds > 400 then
        log("Air Logistics Tower: belt could not be drained, leaving items on the line")
        return false
      end
      local stack = line[1]
      W.restore(tower, stack)
      if stack.valid_for_read then return false end
    end
  end
  return true
end

local function set_buffer_filters(buffer, filters, allow_unfiltered)
  local inventory = buffer.get_inventory(defines.inventory.chest)
  for i=1,#inventory do
    local filter = #filters > 0 and filters[(i-1) % #filters + 1]
    inventory.set_filter(i, filter and {name=filter.name, quality=filter.quality, comparator="="} or nil)
  end
  if #filters == 0 and not allow_unfiltered then inventory.set_bar(1)
  elseif inventory.get_bar() == 1 then inventory.set_bar() end
end

local PORT_VERIFY_INTERVAL = 60

function P.ensure(tower)
  tower.ports = tower.ports or {}
  tower.port_buffers = tower.port_buffers or {}
  tower.port_filters = tower.port_filters or {}
  tower.port_modes = tower.port_modes or {}
  tower.port_speeds = tower.port_speeds or {}
  tower.port_applied = tower.port_applied or {}
  tower.port_input_filters = tower.port_input_filters or {}
  tower.port_filter_cursor = tower.port_filter_cursor or {}
  tower.port_auto = tower.port_auto or {}
  local buffers_moved = false
  local control = tower.entity.get_or_create_control_behavior()
  local networks = W.supports_output_networks(control) and control.output_networks or nil
  local signature = {tower.entity.force.index, control.read_contents,
    networks and networks.red or false, networks and networks.green or false}
  local stored = tower.port_ensure_signature
  local unchanged = stored ~= nil
  if unchanged then
    for i = 1, 4 do if stored[i] ~= signature[i] then unchanged = false; break end end
  end
  local intact = true
  for i=1,#P.get_layout(tower) do
    local port,buffer = tower.ports[i],tower.port_buffers[i]
    if not port or not port.valid or not buffer or not buffer.valid or port.loader_container ~= buffer then intact=false; break end
  end
  if game.tick >= (tower.port_verify_tick or 0) then
    tower.port_verify_tick = game.tick + PORT_VERIFY_INTERVAL
    local position = tower.entity.position
    local checked = tower.port_verified_position
    if not checked then
      tower.port_verified_position = {position.x, position.y}
    elseif checked[1] ~= position.x or checked[2] ~= position.y then
      checked[1], checked[2] = position.x, position.y
      unchanged = false
      for i = 1, #P.get_layout(tower) do tower.port_applied[i] = nil end
    end
  end
  if intact and unchanged then return end
  tower.port_scan_dirty = true
  tower.port_buffer_inventories = nil
  tower.port_buffer_size = nil
  local position = tower.entity.position
  for i, spec in ipairs(P.get_layout(tower)) do
    if not tower.port_buffers[i] or not tower.port_buffers[i].valid then
      tower.port_buffers[i] = create_buffer(tower, spec)
      tower.port_applied[i] = nil
    end
    local buffer = tower.port_buffers[i]
    if buffer.force ~= tower.entity.force then buffer.force = tower.entity.force end
    local reader = buffer.get_or_create_control_behavior()
    reader.read_contents = control.read_contents
    if W.supports_output_networks(control) then reader.output_networks = control.output_networks end
    if script.active_mods.base:match('^2%.1%.') then reader.read_empty_slots = false end
    for _, color in ipairs({defines.wire_connector_id.circuit_red, defines.wire_connector_id.circuit_green}) do
      local connector, target = buffer.get_wire_connector(color, true), tower.entity.get_wire_connector(color, true)
      if not connector.is_connected_to(target, defines.wire_origin.script) then connector.connect_to(target, false, defines.wire_origin.script) end
    end
    local target_position = {x=position.x+spec.x-2*spec.dx, y=position.y+spec.y-2*spec.dy}
    if buffer.position.x ~= target_position.x or buffer.position.y ~= target_position.y then
      assert(buffer.teleport(target_position), "Air Logistics Tower: could not move belt transfer buffer")
      tower.port_applied[i], buffers_moved = nil, true
    end
    if not tower.ports[i] or not tower.ports[i].valid then
      tower.ports[i] = create(tower, spec, P.name)
      tower.port_applied[i] = nil
    end
  end
  for i, port in ipairs(tower.ports) do
    if port.valid and (buffers_moved or port.loader_container ~= tower.port_buffers[i]) then port.update_connections() end
  end
  tower.port_ensure_signature = signature
end

local function collect_items(entity, seen, keys)
  if not entity or not entity.valid then return end
  for lane = 1, entity.get_max_transport_line_index() do
    local line = entity.get_transport_line(lane)
    for _, item in ipairs(line.get_contents()) do
      local key = item.name .. "/" .. item.quality
      if not seen[key] then
        seen[key] = {name = item.name, quality = item.quality}
        keys[#keys + 1] = key
      end
    end
  end
end

local function input_filters(tower, index, belt, port)
  local seen, keys = {}, {}
  collect_items(belt, seen, keys)
  collect_items(port, seen, keys)
  if #keys == 0 then return tower.port_input_filters[index] or {} end
  table.sort(keys)
  local filters, start = {}, tower.port_filter_cursor[index] or 1
  for offset = 0, math.min(5, #keys) - 1 do
    filters[#filters + 1] = seen[keys[(start + offset - 1) % #keys + 1]]
  end
  tower.port_filter_cursor[index] = #keys > 5 and (start + 4) % #keys + 1 or 1
  return filters
end

local loader_names = {}
local function loader_name(belt)
  if not belt then return nil end
  local cached = loader_names[belt.name]
  if not cached then
    cached = P.name .. "-" .. belt.name
    if not prototypes.entity[cached] then cached = P.name end
    loader_names[belt.name] = cached
  end
  return cached
end

function P.learn(tower)
  local port_auto, applied = tower.port_auto, tower.port_input_filters
  local port_belts, ports = tower.port_belts, tower.ports
  if not port_auto or not port_belts or not applied then return end
  for i = 1, #P.get_layout(tower) do
    if port_auto[i] then
      local belt, port = port_belts[i], ports[i]
      if belt and belt.valid and port and port.valid then
        local filters = input_filters(tower, i, belt, port)
        local previous = applied[i]
        local same = previous ~= nil and #previous == #filters
        if same then
          for k = 1, #filters do
            local a, b = previous[k], filters[k]
            if a.name ~= b.name or (a.quality or "normal") ~= (b.quality or "normal") then same = false; break end
          end
        end
        if not same then P.update(tower); return end
      elseif belt then P.update(tower); return
      end
    end
  end
end

local loader_properties = {}
function P.update(tower, skip_circuit)
  if not tower.entity.valid then return end
  P.ensure(tower)
  if not skip_circuit then C.update(tower) end
  local entity = tower.entity
  local force = entity.force
  local layout = P.get_layout(tower)
  local port_belts, rescanned = belts(tower)
  tower.port_interval = P.interval
  tower.preservation_ports = {}
  for i, spec in ipairs(layout) do
    local port, buffer = tower.ports[i], tower.port_buffers[i]
    local belt = port_belts[i]
    local mode = belt and (belt.direction==(spec.direction+8)%16 and "input" or "output") or port.loader_type
    local name = belt and loader_name(belt) or port.name
    local slot = tower.effective_slots and tower.effective_slots[i]
    local filter = tower.filters_controlled and tower.effective_port_filters[i]
      or (slot and {name=slot.name, quality=slot.quality or "normal"})
    tower.port_filters[i] = filter
    local filters = filter and {filter} or {}
    tower.port_input_filters[i] = nil
    tower.port_auto[i] = false
    local spoilable, spoiled = false, false
    for _, value in ipairs(filters) do
      local class = spoil_class(value.name, value.quality or "normal")
      if class > 1 then spoilable = true end
      if class % 2 == 1 then spoiled = true end
    end
    if spoilable then tower.preservation_ports[#tower.preservation_ports+1] = i end
    if spoiled then
      local inventory = buffer.get_inventory(defines.inventory.chest)
      for _, item in ipairs(inventory.get_contents()) do
        local accepted = false
        for _, value in ipairs(filters) do
          if item.name == value.name and item.quality == value.quality then accepted = true; break end
        end
        if not accepted then
          local stack, rounds = inventory.find_item_stack(item), 0
          while stack do
            W.restore(tower,stack)
            rounds = rounds + 1
            if rounds > 200 then
              log("Air Logistics Tower: interface buffer would not release " .. item.name
                .. ", leaving the remainder in place")
              break
            end
            stack = inventory.find_item_stack(item)
          end
        end
      end
    end
    local parts = {mode}
    for _, value in ipairs(filters) do parts[#parts + 1] = value.name .. "/" .. value.quality end
    local key = table.concat(parts, ":")
    local ready, replaced = true, false
    if port.name~=name or tower.port_applied[i]~=key then
      port.disabled_by_script = true
      ready = drain(port, tower, buffer)
      if ready then
        set_buffer_filters(buffer, filters, false)
        if port.name~=name then
          port = create(tower, spec, name, true)
          tower.ports[i], replaced = port, true
        end
        port.loader_type = mode
        port.direction = mode=="input" and (spec.direction+8)%16 or spec.direction
        port.loader_filter_mode = "whitelist"
        for slot=1,5 do port.set_filter(slot, nil) end
        for slot, value in ipairs(filters) do
          port.set_filter(slot, {name=value.name, quality=value.quality, comparator="="})
        end
        tower.port_applied[i] = key
      end
    end
    if port.force~=force then port.force = force end
    local connected
    if not rescanned and not replaced then
      local cached = tower.port_connected
      connected = cached and cached[i]
    end
    if connected == nil then
      connected = false
      for _, neighbour in ipairs(port.belt_neighbours[mode=="input" and "inputs" or "outputs"]) do
        if neighbour==belt then connected = true; break end
      end
      if not tower.port_connected then tower.port_connected = {} end
      tower.port_connected[i] = connected
    end
    local port_name = port.name
    local properties = loader_properties[port_name]
    if not properties then
      local prototype = port.prototype
      properties = {max_stack=prototype.loader_max_belt_stack_size, speed=prototype.belt_speed*480}
      loader_properties[port_name] = properties
    end
    local max_stack = properties.max_stack
    local belt_stack = port.loader_belt_stack_size_override
    if max_stack>1 then
      local override = math.min(max_stack, force.belt_stack_size_bonus+1)
      if belt_stack ~= override then port.loader_belt_stack_size_override = override end
      belt_stack = override
    end
    local filter_ready = filter ~= nil
    local disabled = not (tower.enabled and ready and connected and filter_ready
      and not (mode=="output" and T.is_aircraft(filter.name)))
    disabled = disabled or mode == "input" and tower.port_full and tower.port_full[i] or false
    if port.disabled_by_script ~= disabled then port.disabled_by_script = disabled end
    tower.port_modes[i] = not ready and "blocked" or connected and mode or "disconnected"
    tower.port_speeds[i] = connected and properties.speed*math.max(1, belt_stack) or 0
    if connected and tower.port_speeds[i] > 0 then
      local size = math.huge
      for _, value in ipairs(filters) do size = math.min(size, item_stack_size(value.name)) end
      if size == math.huge then size = 1 end
      local buffer_size = tower.port_buffer_size
      if not buffer_size then buffer_size = #buffer.get_inventory(defines.inventory.chest); tower.port_buffer_size = buffer_size end
      local capacity = math.floor(buffer_size / math.max(1, #filters)) * size
      local interval = math.max(1, math.floor((capacity - 2*math.max(1, belt_stack)) * 60 / tower.port_speeds[i]))
      tower.port_interval = math.min(tower.port_interval, interval)
    end
  end
end

function P.tick(tower)
  if not tower.entity.valid then return end
  local groups = {}
  local stocks = {}
  local function stock(item)
    local key = item.name .. "/" .. (item.quality or "normal")
    local count = stocks[key]
    if count == nil then count = W.count(tower, item); stocks[key] = count end
    return count
  end
  local count_ports = #P.get_layout(tower)
  local modes, ports = tower.port_modes, tower.ports
  tower.port_full = tower.port_full or {}
  for i=1,count_ports do
    local mode = modes[i]
    local inventory = W.buffer_inventory(tower, i)
    if inventory then
      if (mode == "input" or mode == "disconnected") and not inventory.is_empty() then
        if mode == "input" then
          for _, item in ipairs(inventory.get_contents()) do
            local index = W.index(tower,item)
            local target = index and W.inventory(tower,index)
            if target then
              local limit = R.storage_per_bank(tower.entity.force,tower) * W.stack_size(item.name)
              local room = math.max(0,limit - stock(item) + inventory.get_item_count(item))
              W.move(inventory,target,item,math.min(item.count,room))
            end
          end
        else
          for j=1,#inventory do if inventory[j].valid_for_read then W.restore(tower,inventory[j]) end end
        end
      elseif mode == "output" then
        local filter = tower.port_filters[i]
        if filter and not T.is_aircraft(filter.name) then
          local port = ports[i]
          local live = port and port.valid
          local stack = live and math.max(1, port.loader_belt_stack_size_override) or 1
          local limit = tower.enabled and (2 * stack + math.ceil(tower.port_speeds[i] * (tower.port_interval or P.interval) / 60)) or 0
          local buffered = inventory.get_item_count(filter)
          local refill = tower.enabled and not (live and port.disabled_by_script) and buffered < limit
          if buffered > limit or refill then
            local key = filter.name .. "/" .. (filter.quality or "normal")
            local entry = groups[key]
            local sources = entry and entry.sources or W.sources(tower,filter)
            if #sources > 0 then
              if buffered > limit then
                for _, source in ipairs(sources) do
                  if buffered <= limit then break end
                  buffered = buffered - W.move(inventory, source, filter, buffered - limit)
                end
              end
              if refill then
                if not entry then entry = {sources=sources, item=filter, need={}, held={}}; groups[key] = entry end
                entry.need[i], entry.held[i] = limit - buffered, inventory
              end
            end
          end
        end
      end
      if mode == "input" then
        local filter = tower.port_filters[i]
        local filters = filter and {filter} or {}
        local full = false
        for _, item in ipairs(filters) do
          local limit = R.storage_per_bank(tower.entity.force,tower) * W.stack_size(item.name)
          local index = W.index(tower,item)
          local target = index and W.inventory(tower,index,true)
          if target and (not target.can_insert(item) or stock(item) >= limit) then full = true; break end
        end
        local was_full = tower.port_full[i]
        tower.port_full[i] = full
        local port = ports[i]
        if port and port.valid then
          if full then port.disabled_by_script = true
          elseif was_full then P.update(tower,true) end
        end
      else tower.port_full[i] = nil end
    end
  end
  tower.port_output_cursor = tower.port_output_cursor or {}
  for key, entry in pairs(groups) do
    local need, held, item = entry.need, entry.held, entry.item
    local available = 0
    for _, source in ipairs(entry.sources) do available = available + source.get_item_count(item) end
    local start, last = tower.port_output_cursor[key] or 1
    local rounds = 0
    while available > 0 do
      rounds = rounds + 1
      if rounds > 200 then
        log("Air Logistics Tower: interface distribution stopped after 200 rounds on " .. item.name)
        break
      end
      local waiting = 0
      for _, want in pairs(need) do if want > 0 then waiting = waiting + 1 end end
      if waiting == 0 then break end
      local share, moved = math.max(1, math.floor(available / waiting)), 0
      for offset = 0, count_ports - 1 do
        local i = (start + offset - 1) % count_ports + 1
        local want = need[i]
        if want and want > 0 then
          local count, amount = 0, math.min(want, share, available)
          for _, source in ipairs(entry.sources) do
            count = count + W.move(source, held[i], item, amount - count)
            if count >= amount then break end
          end
          need[i], available, moved = want - count, available - count, moved + count
          if count > 0 then last = i else need[i] = 0 end
          if available == 0 then break end
        end
      end
      if moved == 0 then break end
    end
    if last then tower.port_output_cursor[key] = last % count_ports + 1 end
  end
end

function P.configure(id, filters)
  local tower = storage.towers[id]
  if not tower or not tower.entity.valid or type(filters)~="table" then return false end
  local clean = {}
  for i=1,#P.get_layout(tower) do
    local filter = filters[i]
    if filter then
      if type(filter)~="table" or type(filter.name)~="string" or not prototypes.item[filter.name]
        or (filter.quality and type(filter.quality)~="string") or not prototypes.quality[filter.quality or "normal"] then return false end
      clean[i] = {name=filter.name, quality=filter.quality or "normal"}
    end
  end
  tower.port_filters = clean
  P.update(tower)
  return true
end

function P.remove(tower, buffer, discard)
  if discard then
    for _, port in ipairs(tower.ports or {}) do if port.valid then port.destroy() end end
    for _, bin in ipairs(tower.port_buffers or {}) do if bin.valid then bin.destroy() end end
    tower.ports, tower.port_buffers = nil, nil
    return
  end
  W.preserve(tower,game.tick,true)
  for _, port in ipairs(tower.ports or {}) do
    if port.valid then
      for lane=1,2 do
        local line = port.get_transport_line(lane)
        local rounds = 0
        while #line>0 do
          rounds = rounds + 1
          if rounds > 400 then
            log("Air Logistics Tower: leftover cargo on a removed interface could not be recovered")
            break
          end
          local stack = line[1]
          if buffer and buffer.valid then W.transfer_from_stack(buffer, stack) end
          if stack.valid_for_read then
            local drops = port.surface.spill_item_stack{
              position=port.position, stack=stack, enable_looted=true, force=port.force,
              allow_belts=false, use_start_position_on_failure=true
            }
            assert(#drops>0, "Air Logistics Tower: could not recover belt cargo")
            stack.clear()
          end
        end
      end
      port.destroy()
    end
  end
  for _, bin in ipairs(tower.port_buffers or {}) do
    if bin.valid then
      local inventory = bin.get_inventory(defines.inventory.chest)
      for i=1,#inventory do if inventory[i].valid_for_read then W.restore(tower, inventory[i]) end end
      bin.destroy()
    end
  end
  tower.ports, tower.port_buffers = nil, nil
end

return P
