local W = {slots = 12, robot_modes = {off=1, requester=2, ["passive-provider"]=3, buffer=4}}
function W.slot_count(tower)
  if not tower then return 0 end
  return math.max(#(tower.slots or {}), #(tower.effective_slots or {}))
end
function W.stack_size(name)
  return name=="promethium-asteroid-chunk" and 50 or prototypes.item[name].stack_size
end
local R = require("scripts.research")
local T = require("scripts.tier")
local has_empty_slot_reader = script.active_mods.base:match('^2%.1%.') ~= nil
local output_networks_supported
function W.supports_output_networks(cb)
  if output_networks_supported == nil then
    output_networks_supported = pcall(function() return cb.output_networks end)
  end
  return output_networks_supported
end
local legacy_preservation = {}
local legacy_pages, legacy_schedule = {}, {}
local preserve_bank
local EMPTY_PAGES = {}
local EMPTY_LIST = {}
local count_filter, mapped_filter, move_filter = {}, {}, {}
local PENDING_SWEEP = 10
local function legacy_record(pages, index, tick)
  pages.preservation = pages.preservation or {}
  local record = pages.preservation[index]
  if not record then
    record = {tick=tick, next_tick=tick}
    pages.preservation[index] = record
  end
  legacy_preservation[pages[index]] = record
  legacy_pages[pages[index]] = pages
  return record
end
local colors = {defines.wire_connector_id.circuit_red, defines.wire_connector_id.circuit_green}

local function matches(stack, item)
  return stack.valid_for_read and item and stack.name == item.name
    and stack.quality.name == (item.quality or "normal")
end

local function slot_at(slots, name, quality)
  if not slots or not name then return nil end
  for i = 1, #slots do
    local slot = slots[i]
    if slot and slot.name == name and (slot.quality or "normal") == quality then return i end
  end
end

local function find_slot(slots, item)
  return item and slot_at(slots, item.name, item.quality or "normal")
end

local function legacy_index(pages)
  local index = pages.index
  if index then return index end
  index = {}
  for i = 1, #pages do
    local inventory = pages[i]
    if inventory.valid then
      for _, item in ipairs(inventory.get_contents()) do
        local key = item.name .. "/" .. item.quality
        local bucket = index[key]
        if bucket then bucket[#bucket + 1] = inventory else index[key] = {inventory} end
      end
    end
  end
  pages.index = index
  return index
end

local function legacy_index_add(pages, inventory, key)
  local index = pages.index
  if not index then return end
  local bucket = index[key]
  if not bucket then index[key] = {inventory}; return end
  for i = 1, #bucket do if bucket[i] == inventory then return end end
  bucket[#bucket + 1] = inventory
end

local function compact_pages(bucket)
  if not bucket then return 0 end
  local size = #bucket
  local live = 0
  for i = 1, size do
    local page = bucket[i]
    if page.valid then
      live = live + 1
      if live ~= i then bucket[live] = page end
    end
  end
  if live ~= size then
    for i = size, live + 1, -1 do bucket[i] = nil end
  end
  return live
end

local function legacy_count(bucket, filter)
  if not bucket then return 0 end
  local size = #bucket
  local live, total = 0, 0
  for i = 1, size do
    local page = bucket[i]
    if page.valid then
      local amount = page.get_item_count(filter)
      if amount > 0 then
        live = live + 1
        if live ~= i then bucket[live] = page end
        total = total + amount
      end
    end
  end
  if live ~= size then
    for i = size, live + 1, -1 do bucket[i] = nil end
  end
  return total
end

local function resize(entity, inventory, target)
  for i = #inventory, target + 1, -1 do
    if inventory[i].valid_for_read then target = i; break end
  end
  if #inventory == target then return inventory end
  local bar = inventory.supports_bar() and inventory.get_bar()
  local unrestricted = bar == #inventory + 1
  entity.set_inventory_size_override(defines.inventory.chest, target)
  inventory = entity.get_inventory(defines.inventory.chest)
  if bar then
    if unrestricted then inventory.set_bar() else inventory.set_bar(math.min(bar, target + 1)) end
  end
  return inventory
end

function W.robot_mode(tower, index)
  local options = tower.options or {}
  if options["robot_mode_"..index] then return options["robot_mode_"..index] end
  local legacy = options["robot_delivery_"..index]
  local slot = (tower.effective_slots or tower.slots or {})[index]
  if legacy ~= nil and slot then
    if slot.mode ~= "request" then return "passive-provider" end
    if legacy then return "requester" end
  end
  return "off"
end

local function bin_prototype(tower, index)
  local mode = W.robot_mode(tower, index)
  local name=mode == "off" and "air-logistics-storage-bin" or "air-logistics-robot-"..mode
  local rule=(tower.effective_slots or tower.slots or {})[index]
  if rule and rule.name=="promethium-asteroid-chunk" and prototypes.entity[name.."-promethium"] then return name.."-promethium" end
  return name
end

local bin_read_contents_support = {}
local function bin_supports_read_contents(bin, reader)
  local name = bin and bin.name or ""
  local cached = bin_read_contents_support[name]
  if cached == nil then
    cached = pcall(function() reader.read_contents = reader.read_contents end)
    bin_read_contents_support[name] = cached
  end
  return cached
end

local function create_bin(tower, index)
  local bin = tower.entity.surface.create_entity{
    name = bin_prototype(tower, index), position = tower.entity.position, force = tower.entity.force
  }
  assert(bin, "Air Logistics Tower: could not create isolated storage section")
  bin.destructible, bin.operable, bin.rotatable = false, false, false
  for _, color in ipairs(colors) do
    bin.get_wire_connector(color, true).connect_to(
      tower.entity.get_wire_connector(color, true), false, defines.wire_origin.script)
  end
  local cb=tower.entity.get_or_create_control_behavior()
  local reader=bin.get_or_create_control_behavior()
  if bin_supports_read_contents(bin, reader) then reader.read_contents=cb.read_contents end
  if W.supports_output_networks(cb) then reader.output_networks=cb.output_networks end
  if has_empty_slot_reader then
    reader.read_empty_slots=cb.read_empty_slots
    reader.empty_slots_signal=cb.empty_slots_signal
  end
  tower.storage_bins[index] = bin
  if tower.bank_inventories then tower.bank_inventories[index] = nil end
  tower.warehouse_filter_signature = nil
  tower.robot_requests=nil
  return bin
end

local function bank_entity(tower, index)
  local bin = tower.storage_bins and tower.storage_bins[index]
  if bin and bin.valid then return bin end
end

local function legacy_spoilable(pages, index)
  pages.spoilable = pages.spoilable or {}
  local record = pages.preservation and pages.preservation[index]
  if record and record.dirty then pages.spoilable[index], record.dirty = nil, nil end
  if pages.spoilable[index] == nil then
    local inventory = pages[index]
    local spoilable = false
    for _, item in ipairs(inventory.valid and inventory.get_contents() or {}) do
      if prototypes.item[item.name].get_spoil_ticks(item.quality or "normal") > 0 then spoilable = true; break end
    end
    pages.spoilable[index] = spoilable
  end
  return pages.spoilable[index]
end

local is_spoilable

local OVERFLOW_STALL_LIMIT = 3
local OVERFLOW_ROUND_LIMIT = 200

local function overflow_store(pages, stack)
  local stalls, rounds = 0, 0
  while stack.valid_for_read do
    rounds = rounds + 1
    if rounds > OVERFLOW_ROUND_LIMIT then
      log("Air Logistics Tower: recovery storage stopped after " .. OVERFLOW_ROUND_LIMIT
        .. " rounds on " .. stack.name .. ", discarding the remainder")
      stack.clear()
      return
    end
    local page = pages[#pages]
    if not page or not page.valid or not page.can_insert{name=stack.name, quality=stack.quality.name} then
      page = game.create_inventory(50)
      pages[#pages + 1] = page
    end
    legacy_schedule[pages] = nil
    if is_spoilable(stack.name, stack.quality.name) then pages.spoilable_any = true end
    local record = legacy_record(pages,#pages,game.tick)
    preserve_bank(page,game.tick)
    if pages.spoilable then pages.spoilable[#pages] = nil end
    local item_name, item_quality = stack.name, stack.quality.name
    local before = stack.count
    W.transfer_from_stack(page, stack)
    legacy_index_add(pages,page,item_name.."/"..item_quality)
    record.next_tick = game.tick + 1
    if stack.valid_for_read and stack.count >= before then
      stalls = stalls + 1
      if stalls >= OVERFLOW_STALL_LIMIT then
        log("Air Logistics Tower: recovery storage could not accept " .. item_name
          .. " after " .. stalls .. " attempts, discarding the remainder")
        stack.clear()
        return
      end
    else stalls = 0 end
  end
end

local function route_inventory(tower, source, banks, slots, overflow)
  for i = 1, #source do
    local stack = source[i]
    if stack.valid_for_read and not T.is_aircraft(stack.name) then
      local index = find_slot(slots, {name=stack.name, quality=stack.quality.name})
      if index then W.transfer_from_stack(banks[index], stack) end
      if stack.valid_for_read then overflow_store(overflow, stack) end
    elseif stack.valid_for_read then
      overflow_store(overflow, stack)
    end
  end
end

function W.inventory(tower, index, read_only)
  local cached = tower.bank_inventories
  if not cached then cached = {}; tower.bank_inventories = cached end
  local inventory = cached[index]
  if not (inventory and inventory.valid) then
    local entity = bank_entity(tower, index)
    inventory = entity and entity.get_inventory(defines.inventory.chest)
    cached[index] = inventory
  end
  if inventory and not read_only then preserve_bank(inventory,game.tick) end
  return inventory
end

local function buffer_inventory(tower, index)
  local cached = tower.port_buffer_inventories
  if not cached then cached = {}; tower.port_buffer_inventories = cached end
  local inventory = cached[index]
  if inventory and inventory.valid then return inventory end
  local bin = tower.port_buffers and tower.port_buffers[index]
  inventory = bin and bin.valid and bin.get_inventory(defines.inventory.chest)
  cached[index] = inventory
  return inventory
end

W.buffer_inventory = buffer_inventory

function W.inventories(tower, read_only, names)
  local inventories = {}
  for i = 1, W.slot_count(tower) do
    local inventory = W.inventory(tower, i, read_only)
    if inventory and inventory.valid then inventories[#inventories + 1] = inventory end
  end
  local buffers = tower.port_buffers
  for i = 1, buffers and #buffers or 0 do
    local inventory = buffer_inventory(tower, i)
    if inventory then inventories[#inventories + 1] = inventory end
  end
  local pages = tower.legacy_warehouse or {}
  local selected
  if names and #pages > 0 then
    selected = {}
    for key, bucket in pairs(legacy_index(pages)) do
      if names[key:match("^([^/]+)/")] then
        for _, inventory in ipairs(bucket) do selected[inventory] = true end
      end
    end
  end
  for i, inventory in ipairs(pages) do
    if (not selected or selected[inventory]) and inventory.valid then
      legacy_record(pages,i,game.tick)
      inventories[#inventories + 1] = inventory
    end
  end
  return inventories
end

function W.index(tower, item)
  return find_slot(tower.effective_slots or tower.slots, item)
end

function W.compatible(tower, slots)
  local current = tower.effective_slots or tower.slots or {}
  for i = 1, math.max(W.slot_count(tower), #(slots or {})) do
    local inventory = W.inventory(tower, i)
    local slot, old = slots[i], current[i]
    local unchanged = old and slot and old.name == slot.name and (old.quality or "normal") == (slot.quality or "normal")
    if slot and not unchanged and inventory and not inventory.is_empty() then
      local products = old and prototypes.item[old.name] and prototypes.item[old.name].spoil_result
        and inventory.get_item_count{name=old.name,quality=old.quality or "normal"} == 0
      if not products and (not slot or inventory.get_item_count()
        ~= inventory.get_item_count{name=slot.name,quality=slot.quality or "normal"}) then return false end
    end
    local new = slot
    if slot and not unchanged and (old or new) then
      if old and (W.robot_count(tower,old,"deliver")>0 or W.robot_count(tower,old,"pickup")>0) then return false end
      for _, flight in pairs(storage.flights or {}) do
        local id = tower.entity.unit_number
        if (flight.home == id or flight.target == id or flight.source == id or flight.receiver == id)
          and (not flight.item or matches({valid_for_read=true, name=flight.item.name,
            quality={name=flight.item.quality or "normal"}}, old)
            or matches({valid_for_read=true, name=flight.item.name,
              quality={name=flight.item.quality or "normal"}}, new)) then return false end
      end
    end
  end
  for _, bin in ipairs(tower.port_buffers or {}) do
    if bin and bin.valid then
      local inventory = bin.get_inventory(defines.inventory.chest)
      for i = 1, #inventory do
        local stack = inventory[i]
        if stack.valid_for_read then
          local item = {name=stack.name, quality=stack.quality.name}
          local old_index, new_index = find_slot(current, item), find_slot(slots, item)
          if old_index and new_index and old_index ~= new_index then return false end
        end
      end
    end
  end
  return true
end

function W.reassign_products(tower, slots)
  W.preserve(tower,game.tick,true)
  tower.route_signature = nil
  local current = tower.effective_slots or tower.slots or {}
  for i, old in pairs(current) do
    local slot = slots[i]
    if not slot or old.name ~= slot.name or (old.quality or "normal") ~= (slot.quality or "normal") then
      local inventory = W.inventory(tower,i)
      for j = 1, inventory and #inventory or 0 do
        local stack = inventory[j]
        if stack.valid_for_read and not matches(stack,slot) then
          tower.legacy_warehouse = tower.legacy_warehouse or {}
          overflow_store(tower.legacy_warehouse,stack)
        end
      end
    end
  end
  for _,bin in ipairs(tower.port_buffers or {}) do
    if bin and bin.valid then
      local inventory=bin.get_inventory(defines.inventory.chest)
      for i=1,#inventory do
        local stack=inventory[i]
        if stack.valid_for_read and slot_at(current,stack.name,stack.quality.name)
          and not slot_at(slots,stack.name,stack.quality.name) then
          tower.legacy_warehouse=tower.legacy_warehouse or {}
          overflow_store(tower.legacy_warehouse,stack)
        end
      end
    end
  end
end

local function open_section(inventory)
  if inventory and inventory.valid and inventory.supports_bar() and inventory.get_bar() ~= #inventory + 1 then
    inventory.set_bar()
  end
end

local function real_bar(bar, size)
  return bar and bar > 2 and bar <= size and bar or nil
end

function W.set_filters(tower, slots)
  local modes = {}
  for i=1,W.slot_count(tower) do modes[i] = W.robot_mode(tower,i) end
  local robot_signature = table.concat(modes,":")
  tower.robot_mode_snapshot, tower.robot_mode_options = modes, tower.options
  if tower.warehouse_rules == slots and tower.warehouse_robot_signature == robot_signature
    and tower.warehouse_filter_signature and tower.spoilage_sources and tower.preservation_slots then return end
  storage.preservation = storage.preservation or {}
  tower.warehouse_bars, tower.warehouse_closed = tower.warehouse_bars or {}, tower.warehouse_closed or {}
  local signature, waiting = {}, false
  for i = 1, W.slot_count(tower) do
    local inventory = W.inventory(tower, i)
    local slot = slots and slots[i]
    local previous = bank_entity(tower,i)
    local prototype = bin_prototype(tower,i)
    if previous and previous.name ~= prototype
      and not (modes[i] == "off" and previous.prototype.logistic_mode == "passive-provider") and slot
      and (W.robot_count(tower,slot,"deliver")>0 or W.robot_count(tower,slot,"pickup")>0) then
      local sections=previous.get_logistic_sections()
      local section=sections and sections.get_section(1)
      if section then section.active=false end
      waiting = true
      tower.robot_requests=nil
    elseif previous and previous.name ~= prototype then
      local old = previous.get_inventory(defines.inventory.chest)
      local bar = old.get_bar()
      local bin = create_bin(tower,i)
      local target = resize(bin,bin.get_inventory(defines.inventory.chest),#old)
      for j=1,#old do if old[j].valid_for_read then W.transfer_from_stack(target, old[j]) end end
      assert(old.is_empty(),"Air Logistics Tower: native logistics migration lost cargo")
      storage.preservation[previous.unit_number] = nil
      previous.destroy()
      local carried = real_bar(bar, #target)
      if carried then target.set_bar(carried) end
      inventory=target
    end
    if inventory and tower.warehouse_bars[i] and not real_bar(tower.warehouse_bars[i], #inventory) then
      tower.warehouse_bars[i], tower.warehouse_filter_signature = nil, nil
      if slot and not tower.warehouse_closed[i] then open_section(inventory) end
    end
    local bin=bank_entity(tower,i)
    if bin and slot and prototypes.item[slot.name].get_spoil_ticks(slot.quality or "normal") > 0 then
      storage.preservation[bin.unit_number] = storage.preservation[bin.unit_number] or {tick=game.tick,next_tick=game.tick+1}
    elseif bin then storage.preservation[bin.unit_number] = nil end
    signature[#signature + 1] = table.concat({slot and slot.name or "", slot and slot.quality or "normal", inventory and #inventory or 0}, "/")
  end
  signature = table.concat(signature, ":")
  tower.warehouse_rules, tower.warehouse_robot_signature = slots, not waiting and robot_signature or nil
  if tower.warehouse_filter_signature == signature and tower.spoilage_sources and tower.preservation_slots then return end
  tower.spoilage_sources, tower.preservation_slots = {}, {}
  for i = 1, W.slot_count(tower) do
    local inventory = W.inventory(tower, i)
    local slot = slots and slots[i]
    if slot and prototypes.item[slot.name].spoil_result then tower.spoilage_sources[#tower.spoilage_sources+1] = i end
    if slot and prototypes.item[slot.name].get_spoil_ticks(slot.quality or "normal") > 0 then tower.preservation_slots[#tower.preservation_slots+1] = i end
    if inventory then
      local filter = slot and {name=slot.name, quality=slot.quality or "normal", comparator="="} or nil
      if inventory.supports_filters() then
        for j = 1, #inventory do inventory.set_filter(j, filter) end
      end
      if slot and tower.warehouse_closed[i] then
        local bar = real_bar(tower.warehouse_bars[i], #inventory)
        if bar then inventory.set_bar(bar) else inventory.set_bar() end
        tower.warehouse_closed[i] = nil
      elseif not slot and not tower.warehouse_closed[i] then
        local bar = inventory.get_bar()
        if bar ~= 1 then tower.warehouse_bars[i] = real_bar(bar, #inventory) end
        tower.warehouse_closed[i] = true
        inventory.set_bar(1)
      end
    end
  end
  tower.warehouse_filter_signature = signature
  tower.route_signature = nil
  W.route_products(tower)
end

function W.repair_bars(tower)
  local bars = tower.warehouse_bars
  if not bars then return end
  local slots = tower.effective_slots or tower.slots or {}
  for i = 1, W.slot_count(tower) do
    local inventory = W.inventory(tower, i, true)
    if inventory then
      if bars[i] and not real_bar(bars[i], #inventory) then bars[i] = nil end
      if slots[i] and not (tower.warehouse_closed and tower.warehouse_closed[i]) then
        open_section(inventory)
      end
    end
  end
end

local function migrate(tower)
  local entity = tower.entity
  local native = entity.get_inventory(defines.inventory.chest)
  local old_bar = #native > 1 and native.supports_bar() and native.get_bar()
  if old_bar and (old_bar <= 2 or old_bar > #native) then old_bar = nil end
  local staged = game.create_inventory(math.max(1, #native))
  for i = 1, #native do
    if native[i].valid_for_read then
      W.transfer_from_stack(staged, native[i])
      assert(not native[i].valid_for_read, "Air Logistics Tower: could not stage old warehouse cargo")
    end
  end
  local old_pages = {}
  for _, inventory in pairs(tower.warehouse or {}) do
    if inventory and inventory.valid then old_pages[#old_pages + 1] = inventory end
  end
  tower.storage_bins = tower.storage_bins or {}
  for i = 1, W.slot_count(tower) do if not bank_entity(tower, i) then create_bin(tower, i) end end
  entity.set_inventory_size_override(defines.inventory.chest, 1)
  native = entity.get_inventory(defines.inventory.chest)
  native.set_bar(1)
  local banks = {}
  tower.warehouse_bars, tower.warehouse_closed = {}, {}
  for i = 1, W.slot_count(tower) do
    local bin = bank_entity(tower, i)
    local inventory = bin.get_inventory(defines.inventory.chest)
    banks[i] = resize(bin, inventory, R.storage_per_bank(entity.force, tower))
    tower.warehouse_bars[i] = i == 1 and old_bar or nil
    tower.warehouse_closed[i] = true
    banks[i].set_bar(1)
  end
  local previous_rules = tower.effective_slots or tower.slots
  tower.warehouse_filter_signature = nil
  W.set_filters(tower, previous_rules)
  local overflow = {}
  route_inventory(tower, staged, banks, previous_rules, overflow)
  for _, inventory in ipairs(old_pages) do route_inventory(tower, inventory, banks, previous_rules, overflow) end
  if not staged.is_empty() then overflow[#overflow + 1] = staged else staged.destroy() end
  for _, inventory in ipairs(old_pages) do if inventory.is_empty() then legacy_preservation[inventory],legacy_pages[inventory]=nil,nil; inventory.destroy() end end
  if tower.legacy_warehouse then legacy_schedule[tower.legacy_warehouse] = nil end
  tower.warehouse, tower.legacy_warehouse = nil, overflow
  tower.warehouse_layout = 1
  tower.warehouse_surface, tower.warehouse_position, tower.warehouse_force = entity.surface.index, entity.position, entity.force.index
  local tower_cb = tower.entity.get_or_create_control_behavior()
  if tower_cb.read_contents ~= nil then
    local ok = pcall(function() tower_cb.read_contents = true end)
    if ok then tower_cb.read_contents = true end
  end
  W.set_filters(tower, previous_rules)
end

local function reader_signature(cb, capacity, force_index)
  local signal = has_empty_slot_reader and cb.empty_slots_signal or nil
  local networks = W.supports_output_networks(cb) and cb.output_networks or nil
  return {capacity, force_index, cb.read_contents, has_empty_slot_reader and cb.read_empty_slots or false,
    signal and signal.name or "", signal and signal.type or "", signal and (signal.quality or "normal") or "",
    networks and networks.red or false, networks and networks.green or false}
end

local function reader_signature_matches(stored, current)
  if not stored then return false end
  for i = 1, 9 do if stored[i] ~= current[i] then return false end end
  return true
end

local WAREHOUSE_VERIFY_INTERVAL = 60

local MAX_VISIBLE_SLOTS = 8192
local function network_capacity(tower, index, capacity)
  local mode = W.robot_mode(tower,index)
  if mode ~= "passive-provider" and mode ~= "buffer" then return capacity end
  local slot=(tower.effective_slots or tower.slots or {})[index]
  local pages=tower.legacy_warehouse
  if not slot or not pages or #pages==0 then return capacity end
  local inventory=W.inventory(tower,index,true)
  if not inventory then return capacity end
  local total=W.count(tower,slot)
  if total<=inventory.get_item_count{name=slot.name,quality=slot.quality or "normal"} then return capacity end
  return math.max(capacity, math.min(MAX_VISIBLE_SLOTS,
    math.ceil(total/W.stack_size(slot.name))+16))
end

function W.ensure(tower, force)
  tower.preservation_tick = tower.preservation_tick or game.tick
  if tower.warehouse_layout ~= 1 then migrate(tower); return end
  tower.storage_bins = tower.storage_bins or {}
  if not force and tower.warehouse_ready and game.tick < (tower.warehouse_verify_tick or 0) then
    W.route_products(tower)
    return
  end
  tower.warehouse_verify_tick = game.tick + WAREHOUSE_VERIFY_INTERVAL
  local cb = tower.entity.get_or_create_control_behavior()
  local capacity = R.storage_per_bank(tower.entity.force, tower)
  local signature = reader_signature(cb, capacity, tower.entity.force.index)
  local intact = true
  if #(tower.storage_bins or {}) ~= W.slot_count(tower) then intact = false end
  for i=1,W.slot_count(tower) do if not bank_entity(tower,i) then intact = false; break end end
  if intact and reader_signature_matches(tower.warehouse_reader_signature, signature) then
    local resize_needed=false
    for i=1,W.slot_count(tower) do
      local inventory=W.inventory(tower,i,true)
      if inventory then
        local target=network_capacity(tower,i,capacity)
        if target>#inventory
          or (#inventory>capacity and inventory.is_empty() and target<=capacity) then
          resize_needed=true;break
        end
      end
    end
    if not resize_needed then
      tower.warehouse_ready=true
      W.route_products(tower)
      return
    end
  end
  local resized = false
  for i = 1, W.slot_count(tower) do
    local bin = bank_entity(tower, i) or create_bin(tower, i)
    if bin.force~=tower.entity.force then bin.force = tower.entity.force end
    local inventory = bin.get_inventory(defines.inventory.chest)
    local size = #inventory
    if tower.warehouse_closed and tower.warehouse_closed[i] and tower.warehouse_bars[i] == size + 1 then
      tower.warehouse_bars[i] = nil
    end
    inventory = resize(bin, inventory, network_capacity(tower,i,capacity))
    if size ~= #inventory and tower.bank_inventories then tower.bank_inventories[i]=nil end
    resized = resized or size ~= #inventory
    local reader = bin.get_or_create_control_behavior()
    if bin_supports_read_contents(bin, reader) then reader.read_contents = cb.read_contents end
    if W.supports_output_networks(cb) then reader.output_networks = cb.output_networks end
    if has_empty_slot_reader then
      reader.read_empty_slots, reader.empty_slots_signal = cb.read_empty_slots, cb.empty_slots_signal
    end
  end
  for i = W.slot_count(tower) + 1, #(tower.storage_bins or {}) do
    local bin = tower.storage_bins[i]
    if bin and bin.valid and bin.get_inventory(defines.inventory.chest).is_empty() then
      if storage.preservation then storage.preservation[bin.unit_number] = nil end
      bin.destroy()
      tower.storage_bins[i] = nil
      if tower.bank_inventories then tower.bank_inventories[i] = nil end
    end
  end
  local native = resize(tower.entity, tower.entity.get_inventory(defines.inventory.chest), 1)
  native.set_bar(1)
  tower.warehouse_surface, tower.warehouse_position, tower.warehouse_force = tower.entity.surface.index, tower.entity.position, tower.entity.force.index
  if resized then tower.warehouse_filter_signature = nil end
  if not tower.warehouse_filter_signature then W.set_filters(tower, tower.effective_slots or tower.slots) end
  tower.warehouse_reader_signature = signature
  tower.warehouse_ready = true
  W.route_products(tower)
end

local spoilable_cache = {}
is_spoilable = function(name, quality)
  local key = name .. "/" .. quality
  local value = spoilable_cache[key]
  if value == nil then
    value = prototypes.item[name].get_spoil_ticks(quality) > 0
    spoilable_cache[key] = value
  end
  return value
end

local function preserve_inventory(inventory, elapsed)
  if not inventory or not inventory.valid then return 15 end
  local contents = inventory.get_contents()
  local remaining, spoilable, interval, first = 0, false, 60, 1
  for _, item in ipairs(contents) do
    remaining = remaining + item.count
    if is_spoilable(item.name, item.quality or "normal") then spoilable = true end
  end
  if not spoilable then return interval end
  if remaining > 0 and #inventory > 128 then
    first = #inventory + 1
    for _, item in ipairs(contents) do
      local _, index = inventory.find_item_stack(item)
      if index then first = math.min(first,index) end
    end
  end
  for i = first, #inventory do
    if remaining == 0 then break end
    local stack = inventory[i]
    if stack.valid_for_read then
      remaining = remaining - stack.count
      local expires = stack.spoil_tick
      if expires > 0 then
        stack.spoil_tick = expires + elapsed
        interval = math.min(interval,math.max(1,math.floor((expires+elapsed-game.tick)/2)))
      end
    end
  end
  return interval
end

local function preservation_record(inventory)
  local owner = inventory and inventory.entity_owner
  return owner and storage.preservation and storage.preservation[owner.unit_number] or legacy_preservation[inventory]
end

preserve_bank = function(inventory,tick,record)
  record = record or preservation_record(inventory)
  if record and tick > record.tick then
    local interval = preserve_inventory(inventory,tick-record.tick)
    record.tick,record.next_tick = tick,tick+interval
  end
end

function W.preserve(tower, tick, force)
  local elapsed = tick - (tower.preservation_tick or tick)
  tower.preservation_tick = tick
  local slots, ports = tower.preservation_slots, tower.preservation_ports
  local pages = tower.legacy_warehouse or EMPTY_PAGES
  if not (slots and #slots > 0) and not (ports and #ports > 0) and #pages == 0 then return end
  for _, i in ipairs(slots or EMPTY_LIST) do
    local bin = bank_entity(tower,i)
    local record = bin and storage.preservation and storage.preservation[bin.unit_number]
    if record then
      local logistic = bin.type == "logistic-container"
      if logistic or force or tick >= record.next_tick then
        local inventory = W.inventory(tower,i,true)
        local items = inventory.get_item_count()
        if force or tick >= record.next_tick or items ~= record.items
          or tick >= (record.poll_tick or 0) then
          record.poll_tick = tick + PENDING_SWEEP
          local pending = false
          if logistic then
            local point = bin.get_logistic_point(defines.logistic_member_index.logistic_container)
            pending = #point.targeted_items_deliver > 0 or #point.targeted_items_pickup > 0
          end
          if force or tick >= record.next_tick or (pending and items ~= record.items) then
            preserve_bank(inventory,tick,record)
            record.items = items
          end
          if force or pending then record.next_tick=math.min(record.next_tick,tick+PENDING_SWEEP) end
        end
      end
    end
  end
  if elapsed <= 0 and not force then return end
  for _, i in ipairs(ports or EMPTY_LIST) do
    local bin = tower.port_buffers and tower.port_buffers[i]
    if bin and bin.valid then preserve_inventory(buffer_inventory(tower,i),elapsed) end
  end
  if #pages == 0 then return end
  if not force and legacy_schedule[pages] and tick < legacy_schedule[pages] then return end
  if not force and pages.spoilable_any == false and pages.spoilable_count == #pages then
    legacy_schedule[pages] = tick + 60
    return
  end
  local next_tick = tick + 60
  local any = false
  for i, inventory in ipairs(pages) do
    if legacy_spoilable(pages,i) then
      any = true
      local record = legacy_record(pages,i,tick-elapsed)
      if force or tick >= record.next_tick then
        preserve_bank(inventory,tick)
        pages.spoilable[i] = nil
      end
      next_tick = math.min(next_tick,record.next_tick)
    end
  end
  pages.spoilable_any, pages.spoilable_count = any, #pages
  legacy_schedule[pages] = next_tick
end

function W.robot_count(tower,item,kind)
  if item.type=="fluid" then return 0 end
  local index=W.index(tower,item)
  local bin=index and bank_entity(tower,index)
  if not bin or bin.type~="logistic-container" then return 0 end
  local point=bin.get_logistic_point(defines.logistic_member_index.logistic_container)
  if not point then return 0 end
  local count=0
  local quality=item.quality or "normal"
  for _,entry in ipairs(point[kind=="deliver" and "targeted_items_deliver" or "targeted_items_pickup"]) do
    if entry.name==item.name and entry.quality==quality then count=count+entry.count end
  end
  return count
end

function W.request(tower,index,target)
  local bin=bank_entity(tower,index)
  if not bin or (bin.name~="air-logistics-robot-requester" and bin.name~="air-logistics-robot-buffer") then return end
  if bin.name=="air-logistics-robot-requester" and not bin.request_from_buffers then bin.request_from_buffers=true end
  local slot=(tower.effective_slots or tower.slots)[index]
  local enabled=tower.enabled ~= false and bin.name==bin_prototype(tower,index)
  local name=slot and slot.name
  local quality=slot and (slot.quality or "normal")
  tower.robot_requests=tower.robot_requests or {}
  local previous=tower.robot_requests[index]
  if previous and previous.name==name and previous.quality==quality
    and previous.target==target and previous.enabled==enabled then return end
  local sections=bin.get_logistic_sections()
  local section=sections.get_section(1) or sections.add_section()
  section.active=enabled
  if slot and target>0 then
    section.set_slot(1,{value={type="item",name=slot.name,quality=slot.quality or "normal",comparator="="},min=target,max=target})
  else section.clear_slot(1) end
  tower.robot_requests[index]={name=name,quality=quality,target=target,enabled=enabled}
end

function W.sources(tower, item)
  local sources, index = {}, item and W.index(tower, item)
  local inventory = index and W.inventory(tower, index, true)
  if inventory then sources[#sources+1] = inventory end
  for _, i in ipairs(tower.spoilage_sources or EMPTY_LIST) do
    local inventory = i ~= index and W.inventory(tower, i, true)
    if inventory then sources[#sources+1] = inventory end
  end
  local pages = tower.legacy_warehouse
  if pages then
    if item then
      local bucket = legacy_index(pages)[item.name .. "/" .. (item.quality or "normal")]
      local live = compact_pages(bucket)
      for i = 1, live do sources[#sources+1] = bucket[i] end
    else
      for i, inventory in ipairs(pages) do
        if inventory.valid then legacy_record(pages,i,game.tick); sources[#sources+1] = inventory end
      end
    end
  end
  return sources
end

function W.count(tower, item)
  local quality = item.quality or "normal"
  local filter = count_filter
  filter.name, filter.quality = item.name, quality
  local index = W.index(tower, item)
  local count, bank = 0, 0
  local inventory = index and W.inventory(tower, index, true)
  if inventory then
    bank = inventory.get_item_count(filter)
    count = bank
  end
  local sources = tower.spoilage_sources
  if sources then
    for _, i in ipairs(sources) do
      if i ~= index then
        local extra = W.inventory(tower, i, true)
        if extra then count = count + extra.get_item_count(filter) end
      end
    end
  end
  local pages = tower.legacy_warehouse
  if pages then
    count = count + legacy_count(legacy_index(pages)[item.name .. "/" .. quality], filter)
  end
  local buffers = tower.port_buffers
  for i = 1, buffers and #buffers or 0 do
    local inventory = buffer_inventory(tower, i)
    if inventory then count = count + inventory.get_item_count(filter) end
  end
  return count, bank
end

function W.stock_map(tower)
  local banks, buffers = {}, {}
  for i = 1, W.slot_count(tower) do
    local inventory = W.inventory(tower, i, true)
    if inventory then
      local map = {}
      for _, item in ipairs(inventory.get_contents()) do
        local key = item.name .. "/" .. item.quality
        map[key] = (map[key] or 0) + item.count
      end
      banks[i] = map
    end
  end
  local list = tower.port_buffers
  for i = 1, list and #list or 0 do
    local inventory = buffer_inventory(tower, i)
    if inventory then
      for _, item in ipairs(inventory.get_contents()) do
        local key = item.name .. "/" .. item.quality
        buffers[key] = (buffers[key] or 0) + item.count
      end
    end
  end
  local pages = tower.legacy_warehouse
  return {banks = banks, buffers = buffers, index = pages and legacy_index(pages) or nil}
end

function W.mapped_count(tower, map, name, quality)
  local key = name .. "/" .. quality
  local total = map.buffers[key] or 0
  local index = slot_at(tower.effective_slots or tower.slots, name, quality)
  local bank = index and map.banks[index]
  if bank then total = total + (bank[key] or 0) end
  local sources = tower.spoilage_sources
  if sources then
    for _, i in ipairs(sources) do
      if i ~= index then
        local extra = map.banks[i]
        if extra then total = total + (extra[key] or 0) end
      end
    end
  end
  local bucket = map.index and map.index[key]
  if bucket then
    local filter = mapped_filter
    filter.name, filter.quality = name, quality
    total = total + legacy_count(bucket, filter)
  end
  return total
end

local MOVE_ROUND_LIMIT = 200

local inventory_transfer_from_stack
local function has_transfer_from_stack(inventory)
  if inventory_transfer_from_stack == nil then
    inventory_transfer_from_stack = pcall(function() return inventory.transfer_from_stack end)
  end
  return inventory_transfer_from_stack
end

function W.transfer_from_stack(inventory, stack)
  if has_transfer_from_stack(inventory) then return inventory.transfer_from_stack(stack) end
  if not stack or not stack.valid_for_read then return 0 end
  local count = stack.count
  local moved = inventory.insert{name=stack.name, quality=stack.quality.name, count=count}
  if moved and moved > 0 then
    local left = count - moved
    if left > 0 then stack.count = left else stack.clear() end
  end
  return moved or 0
end

function W.move(source, target, item, amount)
  amount = math.floor(amount)
  if not (amount >= 1) or source.is_empty() then return 0 end
  local filter = move_filter
  filter.name, filter.quality = item.name, item.quality or "normal"
  if not target.can_insert(filter) then return 0 end
  preserve_bank(source,game.tick); preserve_bank(target,game.tick)
  local loaded, rounds = 0, 0
  while loaded < amount do
    rounds = rounds + 1
    if rounds > MOVE_ROUND_LIMIT then
      log("Air Logistics Tower: transfer of " .. filter.name .. " stopped after "
        .. MOVE_ROUND_LIMIT .. " rounds, " .. (amount - loaded) .. " items left behind")
      break
    end
    local stack = source.find_item_stack(filter)
    if not stack then break end
    local portion, moved = math.min(stack.count, amount - loaded)
    if portion == stack.count then
      moved = W.transfer_from_stack(target, stack)
    else
      storage.cargo_transfer = storage.cargo_transfer or game.create_inventory(1)
      local staged = storage.cargo_transfer[1]
      staged.transfer_stack(stack, portion)
      portion=staged.count
      moved = W.transfer_from_stack(target, staged)
      if staged.valid_for_read then stack.transfer_stack(staged) end
      assert(not staged.valid_for_read, "Air Logistics Tower: could not restore partial cargo transfer")
    end
    loaded = loaded + moved
    if portion <= 0 or moved < portion then break end
  end
  local record = loaded > 0 and preservation_record(target)
  if record then
    record.next_tick=game.tick+1
    if legacy_preservation[target] then
      record.dirty=true
      local pages = legacy_pages[target]
      legacy_schedule[pages]=nil
      if is_spoilable(filter.name, filter.quality) then pages.spoilable_any=true end
      legacy_index_add(pages,target,filter.name.."/"..filter.quality)
    end
  end
  return loaded
end

local function route_signature(tower)
  local parts, n = {}, 0
  for i = 1, W.slot_count(tower) do
    local inventory = W.inventory(tower, i, true)
    if inventory then
      n = n + 1; parts[n] = inventory.get_item_count()
      n = n + 1; parts[n] = inventory.count_empty_stacks()
    end
  end
  local pages = tower.legacy_warehouse
  n = n + 1; parts[n] = pages and #pages or 0
  n = n + 1; parts[n] = #(tower.spoilage_sources or {})
  return table.concat(parts, ",")
end

function W.route_products(tower)
  local pages = tower.legacy_warehouse
  local spoilage = tower.spoilage_sources
  if (not pages or #pages == 0) and (not spoilage or #spoilage == 0) then return end
  local forced = pages ~= nil and pages.dirty == true
  if not forced and tower.route_signature and game.tick < (tower.route_gate or 0) then return end
  tower.route_gate = game.tick + 45
  local signature = route_signature(tower)
  if not forced and tower.route_signature == signature then return end
  tower.route_signature = signature
  if pages then pages.dirty = nil end
  local targets = {}
  for _, source in ipairs(W.sources(tower)) do
    for _, item in ipairs(source.get_contents()) do
      local key = item.name .. "/" .. item.quality
      local target = targets[key]
      if target == nil then
        local index = W.index(tower,item)
        target = index and W.inventory(tower,index)
        target = target and target.can_insert(item) and target or false
        targets[key] = target
      end
      if target and target ~= source then
        W.move(source,target,item,item.count)
        if not target.can_insert(item) then targets[key] = false end
      end
    end
  end
  local page_list = pages or {}
  for i = #page_list, 1, -1 do
    local inventory = page_list[i]
    if not inventory.valid or inventory.is_empty() then
      legacy_preservation[inventory],legacy_pages[inventory] = nil,nil
      legacy_schedule[page_list] = nil
      if inventory.valid then inventory.destroy() end
      if page_list.preservation then
        for j=i,#page_list do page_list.preservation[j]=page_list.preservation[j+1] end
      end
      table.remove(page_list, i)
      page_list.spoilable = nil
    end
  end
end

function W.capacity(tower)
  local count = 0
  for i = 1, W.slot_count(tower) do local inventory = W.inventory(tower, i, true); if inventory then count = count + #inventory end end
  return count
end

function W.can_insert(tower, item)
  local index = W.index(tower, item)
  local inventory = index and W.inventory(tower, index, true)
  return inventory and inventory.can_insert{name=item.name, quality=item.quality or "normal"} or false
end

function W.transfer(tower, stack)
  local index = W.index(tower, {name=stack.name, quality=stack.quality.name})
  local inventory = index and W.inventory(tower, index)
  if inventory then
    W.transfer_from_stack(inventory, stack)
    local record=preservation_record(inventory)
    if record then record.next_tick=game.tick+1 end
  end
end

function W.restore(tower, stack)
  W.transfer(tower, stack)
  if stack.valid_for_read then
    tower.legacy_warehouse = tower.legacy_warehouse or {}
    overflow_store(tower.legacy_warehouse, stack)
  end
end

local function copy_inventory(source, target, tower)
  local temporary = game.create_inventory(1)
  for i = 1, #source do
    if source[i].valid_for_read then
      local remaining=source[i].count
      while remaining>0 do
        temporary[1].set_stack(source[i])
        temporary[1].count=math.min(remaining,temporary[1].count)
        remaining=remaining-temporary[1].count
        W.transfer_from_stack(target, temporary[1])
        if temporary[1].valid_for_read then
          tower.legacy_warehouse = tower.legacy_warehouse or {}
          overflow_store(tower.legacy_warehouse, temporary[1])
        end
      end
    end
  end
  temporary.destroy()
end

function W.copy(source, target)
  W.preserve(source,game.tick,true)
  for i = 1, W.slot_count(source) do
    local from, to = W.inventory(source, i), W.inventory(target, i)
    if from and to then
      copy_inventory(from, to, target)
      local record=preservation_record(to)
      if record then record.next_tick=game.tick+1 end
    end
  end
  for _, from in ipairs(source.legacy_warehouse or {}) do
    if from.valid then
      local page = game.create_inventory(50)
      copy_inventory(from, page, target)
      if not page.is_empty() then
        target.legacy_warehouse = target.legacy_warehouse or {}
        target.legacy_warehouse[#target.legacy_warehouse + 1] = page
        target.legacy_warehouse.index = nil
        legacy_schedule[target.legacy_warehouse] = nil
        target.legacy_warehouse.spoilable_any = nil
        legacy_record(target.legacy_warehouse,#target.legacy_warehouse,game.tick)
        target.route_signature = nil
      else page.destroy() end
    end
  end
  for i, from in ipairs(source.port_buffers or {}) do
    local to = target.port_buffers and target.port_buffers[i]
    if from.valid and to and to.valid then
      copy_inventory(from.get_inventory(defines.inventory.chest), to.get_inventory(defines.inventory.chest), target)
    end
  end
end

local function recover(tower, inventory, buffer)
  for i = 1, #inventory do
    local stack = inventory[i]
    if stack.valid_for_read then
      if buffer and buffer.valid then W.transfer_from_stack(buffer, stack) end
      if stack.valid_for_read then
        local surface = game.surfaces[tower.warehouse_surface]
        if surface then
          local drops = surface.spill_item_stack{position=tower.warehouse_position, stack=stack,
            enable_looted=true, force=game.forces[tower.warehouse_force], allow_belts=false,
            use_start_position_on_failure=true}
          assert(#drops > 0, "Air Logistics Tower: could not recover isolated warehouse cargo")
          stack.clear()
        end
      end
    end
  end
end

function W.remove(tower, buffer, discard)
  if not discard then W.preserve(tower,game.tick,true) end
  for i = 1, W.slot_count(tower) do
    local bin = bank_entity(tower, i)
    if bin then
      if not discard then recover(tower, bin.get_inventory(defines.inventory.chest), buffer) end
      if storage.preservation then storage.preservation[bin.unit_number]=nil end
      bin.destroy()
    end
  end
  for _, inventory in ipairs(tower.legacy_warehouse or {}) do
    legacy_preservation[inventory],legacy_pages[inventory] = nil,nil
    if inventory.valid then
      if not discard then recover(tower, inventory, buffer) end
      inventory.destroy()
    end
  end
  for _, inventory in pairs(tower.warehouse or {}) do
    legacy_preservation[inventory],legacy_pages[inventory] = nil,nil
    if inventory.valid then
      if not discard then recover(tower, inventory, buffer) end
      inventory.destroy()
    end
  end
  if tower.legacy_warehouse then legacy_schedule[tower.legacy_warehouse] = nil end
  tower.storage_bins, tower.legacy_warehouse, tower.warehouse = nil, nil, nil
end

return W
