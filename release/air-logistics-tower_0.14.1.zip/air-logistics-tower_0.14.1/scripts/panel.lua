local N = require("scripts.network")
local W = require("scripts.warehouse")
local T = require("scripts.tier")
local B = require("scripts.robots")
local M = require("scripts.mining")
local Part = require("scripts.partitions")
local util = require("util")
local deepcopy = util.table.deepcopy

local Panel = {}
local gui_name = "air_logistics_config"
local sides = {"north", "east", "south", "west"}
local mode_names = {"request", "supply"}
local mode_index = {request = 1, supply = 2}
local has_empty_slot_reader = script.active_mods.base:match("^2%.1%.") ~= nil
local has_gui_inventory = defines.events.on_gui_inventory_action ~= nil
local gui_inventory_options = {handle_cursor_transfer = true, handle_cursor_split = true, empty_slot_info = true}

local state_colors = {
  unpowered = {r = 0.95, g = 0.45, b = 0.35},
  idle = {r = 0.68, g = 0.72, b = 0.78},
  charging = {r = 0.95, g = 0.80, b = 0.35},
  launching = {r = 0.50, g = 0.90, b = 0.50},
}

local function create_inventory_element(parent, params)
  local ok, element = pcall(function() return parent.add(params) end)
  if ok then return element end
  local minimal = {}
  for key, value in pairs(params) do
    if not gui_inventory_options[key] then minimal[key] = value end
  end
  local ok2, element2 = pcall(function() return parent.add(minimal) end)
  if ok2 then return element2 end
end

local function gui_inventory(parent, params, inventory)
  local element = create_inventory_element(parent, params)
  if not element then return nil end
  if inventory then
    local ok = pcall(function() element.inventory = inventory end)
    if not ok or element.inventory ~= inventory then
      if element.valid then element.destroy() end
      return nil
    end
  end
  return element
end

local function interface_text(kind, index)
  local limit = kind == "item" and Part.item_interfaces or Part.fluid_interfaces
  if index > limit then return {"air-logistics.internal-partition"} end
  local per = kind == "item" and Part.item_per_side or Part.fluid_per_side
  local side = sides[math.floor((index - 1) / per) + 1]
  return {"air-logistics.port-" .. side, (index - 1) % per + 1}
end

local tab_keys = {"storage", "logistics", "circuit"}
local function tab(root, name)
  return root.pages["page_" .. name].content
end

local function refresh_tabs(root)
  local active = root.tags.tab or "storage"
  for _, key in ipairs(tab_keys) do
    local bar = root.tabbar["tab_button_" .. key]
    if bar then bar.toggled = key == active end
    local page = root.pages["page_" .. key]
    if page then page.visible = key == active end
  end
end

local function storage_body(root) return tab(root, "storage").body end
local function storage_editor(root) return tab(root, "storage").body.editor end
local function storage_message(root) return tab(root, "storage").toolbar.message end

local function header(parent, caption)
  local label = parent.add{type = "label", caption = caption, style = "heading_2_label"}
  label.style.top_margin = 6
  label.style.bottom_margin = 2
  return label
end

local function panel_frame(parent, name, width)
  local frame = parent.add{type = "frame", name = name, direction = "vertical", style = "shallow_frame"}
  frame.style.padding = 8
  if width then frame.style.minimal_width = width end
  return frame
end

local function refresh_recovery(root, tower)
  local recovery = tab(root, "storage").recovery
  local totals, keys, page_counts = {}, {}, {}
  local pages = tower.legacy_warehouse or {}
  for i, inv in ipairs(pages) do
    if inv.valid then
      page_counts[i] = inv.get_item_count()
      for _, item in ipairs(inv.get_contents()) do
        local key = item.name .. "/" .. (item.quality or "normal")
        if not totals[key] then
          totals[key] = {name = item.name, quality = item.quality or "normal", count = 0}
          keys[#keys + 1] = key
        end
        totals[key].count = totals[key].count + item.count
      end
    end
  end
  table.sort(keys)
  local signature = {#pages}
  for i = 1, #pages do signature[#signature + 1] = page_counts[i] or 0 end
  for _, key in ipairs(keys) do signature[#signature + 1] = key .. ":" .. totals[key].count end
  local code = table.concat(signature, "|")
  if recovery.tags.signature == code then return end
  recovery.clear()
  recovery.visible = #keys > 0
  recovery.tags = {signature = code}
  if #keys == 0 then return end
  header(recovery, {"air-logistics.recovery-title"})
  for _, key in ipairs(keys) do
    local item = totals[key]
    recovery.add{type = "label", caption = {"", {"item-name." .. item.name}, "  ",
      util.format_number(item.count, true)}}
  end
  local row = recovery.add{type = "flow", name = "recovery_buttons", direction = "horizontal"}
  for i, inv in ipairs(pages) do
    if inv.valid and (page_counts[i] or 0) > 0 then
      row.add{type = "button", name = "legacy_take_" .. i,
        caption = {"air-logistics.legacy-take", util.format_number(page_counts[i], true)}}
    end
  end
end

local function partition_signature(info)
  local parts = {#(info.slots or {}), #(info.fluid_rules or {})}
  for i, slot in ipairs(info.slots or {}) do
    parts[#parts + 1] = "i" .. i .. slot.name .. "/" .. (slot.quality or "normal") .. "/" .. slot.mode
  end
  for i, rule in ipairs(info.fluid_rules or {}) do
    parts[#parts + 1] = "f" .. i .. rule.name .. "/" .. rule.mode
  end
  return table.concat(parts, "|")
end

local function add_partition_row(table_element, kind, index, entry)
  local row = table_element.add{type = "flow", name = "partition_row_" .. kind .. "_" .. index, direction = "horizontal"}
  row.style.vertical_align = "center"
  row.style.horizontal_spacing = 6
  if kind == "item" then
    local icon = row.add{type = "sprite-button", name = "stock_item_icon_" .. index, style = "slot_button",
      sprite = "item/" .. entry.name, tooltip = {"air-logistics.stock-icon-help"}}
    icon.style.size = 30
  else
    local icon = row.add{type = "sprite", sprite = "fluid/" .. entry.name}
    icon.style.size = 26
    icon.style.width = 30
  end
  local name = row.add{type = "label", name = "partition_name_" .. kind .. "_" .. index,
    caption = kind == "item" and {"item-name." .. entry.name} or {"fluid-name." .. entry.name}}
  name.style.width = 118
  name.style.single_line = true
  local port = row.add{type = "label", name = "partition_port_" .. kind .. "_" .. index, caption = interface_text(kind, index)}
  port.style.width = 78
  local mode = row.add{type = "label", name = "partition_mode_" .. kind .. "_" .. index,
    caption = entry.mode == "request" and {"air-logistics.request"} or {"air-logistics.supply"}}
  mode.style.width = 52
  local amount = row.add{type = "label", name = "partition_amount_" .. kind .. "_" .. index,
    caption = entry.mode == "request" and util.format_number(entry.count, true) or "-"}
  amount.style.width = 70
  amount.style.horizontal_align = "right"
  local stock = row.add{type = "label", name = "partition_stock_" .. kind .. "_" .. index, caption = ""}
  stock.style.width = 92
  stock.style.horizontal_align = "right"
  local edit = row.add{type = "button", name = "partition_edit_" .. kind .. "_" .. index,
    caption = {"air-logistics.row-edit"}, tooltip = {"air-logistics.partition-help"}}
  edit.style.width = 54
end

local function refresh_partitions(root, info)
  local content = tab(root, "storage")
  local frame = storage_body(root).partition_frame
  local list = frame.partition_scroll.partition_table
  local code = partition_signature(info)
  if list.tags.code ~= code then
    list.clear()
    list.tags = {code = code}
    local items, fluids = info.slots or {}, info.fluid_rules or {}
    if #items == 0 and #fluids == 0 then
      frame.partition_scroll.partition_empty.visible = true
    else
      frame.partition_scroll.partition_empty.visible = false
      for i, slot in ipairs(items) do add_partition_row(list, "item", i, slot) end
      for i, rule in ipairs(fluids) do add_partition_row(list, "fluid", i, rule) end
    end
    local kind = root.tags.selected_kind or "item"
    local index = root.tags.selected_index
    for i = 1, #items do
      local row = list["partition_row_item_" .. i]
      local label = row and row["partition_name_item_" .. i]
      if label then label.style.font_color = (kind == "item" and index == i) and {r = 1, g = 0.9, b = 0.45} or nil end
    end
    for i = 1, #fluids do
      local row = list["partition_row_fluid_" .. i]
      local label = row and row["partition_name_fluid_" .. i]
      if label then label.style.font_color = (kind == "fluid" and index == i) and {r = 1, g = 0.9, b = 0.45} or nil end
    end
  end
  local counts, incoming = info.counts or {}, info.incoming or {}
  local base = #(info.slots or {})
  for i = 1, #(info.slots or {}) do
    local row = list["partition_row_item_" .. i]
    local label = row and row["partition_stock_item_" .. i]
    if label then
      label.caption = {"", util.format_number(counts[i] or 0, true), " / ",
        util.format_number(incoming[i] or 0, true)}
    end
  end
  for i = 1, #(info.fluid_rules or {}) do
    local j = base + i
    local row = list["partition_row_fluid_" .. i]
    local label = row and row["partition_stock_fluid_" .. i]
    if label then
      label.caption = {"", util.format_number(counts[j] or 0, true), " / ",
        util.format_number(incoming[j] or 0, true)}
    end
  end
end

local function refresh_editor(root, info)
  local editor = storage_editor(root)
  local kind = root.tags.selected_kind or "item"
  local index = root.tags.selected_index
  local draft = root.tags.draft == true
  local items, fluids = info.slots or {}, info.fluid_rules or {}
  local slot = kind == "item" and index and items[index] or (kind == "fluid" and index and fluids[index]) or nil
  local active = draft or slot ~= nil
  editor.title.caption = draft and {"air-logistics.new-partition"} or {"air-logistics.partition", index or 0}
  editor.title.visible = active
  editor.interface.caption = active and interface_text(kind, index or 1) or ""
  editor.interface.visible = active
  editor.empty.visible = not active
  editor.form.visible = active
  if not active then return end
  local signature = table.concat({kind, index or 0, draft and 1 or 0, slot and slot.name or "",
    slot and slot.mode or "", slot and tostring(slot.count) or ""}, "/")
  if editor.tags.signature ~= signature then
    editor.tags = {signature = signature}
    if kind == "item" then
      editor.form.cargo.editor_item.visible = true
      editor.form.cargo.editor_fluid.visible = false
      editor.form.cargo.editor_item.elem_value = slot and {name = slot.name, quality = slot.quality or "normal"} or nil
    else
      editor.form.cargo.editor_item.visible = false
      editor.form.cargo.editor_fluid.visible = true
      editor.form.cargo.editor_fluid.elem_value = slot and slot.name or nil
    end
    editor.form.mode_row.editor_mode.selected_index = slot and mode_index[slot.mode] or 1
    editor.form.count_row.editor_count.text = tostring(slot and slot.count or (kind == "fluid" and 10000 or 1000))
  end
  local supply = editor.form.mode_row.editor_mode.selected_index == mode_index.supply
  editor.form.count_row.editor_count.enabled = not supply
  if supply then editor.form.count_row.editor_count.text = "0" end
  editor.form.buttons.editor_delete.visible = not draft
end

local function refresh_logistics(root, info, tower, player, sync_fields)
  local content = tab(root, "logistics")
  content.info_frame.energy.caption = {"air-logistics.energy", string.format("%.1f", info.energy / 1000000),
    info.max_energy / 1000000, info.power_input}
  content.info_frame.planes.caption = {"air-logistics." .. (info.interstellar and "ships" or "planes"),
    info.planes, info.active, info.max_planes}
  if content.info_frame.airplanes then
    content.info_frame.airplanes.caption = {"air-logistics.star-airplanes", info.aircraft_counts[T.planet.plane],
      info.aircraft_counts[T.space.plane], info.airplane_cargo, string.format("%.1f", info.airplane_speed)}
  end
  local options = content.info_frame.panel_options
  options.option_enabled.state = info.options.enabled
  if sync_fields then
    options.option_min_load.text = tostring(info.options.min_load)
    options.option_priority.text = tostring(info.options.priority)
  end
  local requests = content.hangar_frame.panel_hangar_requests
  if sync_fields then
    requests.panel_hangar_plane_request.text = tostring(info.options.plane_request)
    if requests.panel_hangar_ship_request then
      requests.panel_hangar_ship_request.text = tostring(info.options.ship_request)
    end
  end
  if content.hangar_frame.hangar_fallback then
    for _, child in ipairs(content.hangar_frame.hangar_fallback.children) do
      local name = child.name:match("^hangar_count_(.+)$")
      if name then child.caption = tostring(tower.hangar.get_item_count_filtered{name = name}) end
    end
  end
  local mining = info.mining
  local panel = content.mining_frame.panel_mining
  panel.visible = mining.enabled
  panel.mining_state.caption = {"air-logistics.mining-" .. (not mining.enabled and "off" or mining.scanning and "scan"
    or #mining.groups == 0 and "none" or "on")}
  if #panel.rows.children ~= #mining.groups * 4 then
    panel.rows.clear()
    for i = 1, #mining.groups do
      panel.rows.add{type = "checkbox", name = "panel_mining_enabled_" .. i, state = false, caption = "",
        tooltip = {"air-logistics.mining-toggle-help"}}
      panel.rows.add{type = "label", name = "resource_" .. i}
      panel.rows.add{type = "label", name = "rate_" .. i}
      panel.rows.add{type = "label", name = "state_" .. i}
    end
  end
  for i, group in ipairs(mining.groups) do
    local toggle = panel.rows["panel_mining_enabled_" .. i]
    toggle.state = group.enabled
    toggle.tags = {kind = group.kind, resource = group.name}
    local product = group.product
    panel.rows["resource_" .. i].caption = {"", "[" .. product.type .. "=" .. product.name .. "] ",
      prototypes[product.type][product.name].localised_name}
    panel.rows["rate_" .. i].caption = {"air-logistics.mining-rate-" .. group.kind,
      util.format_number(group.kind == "spring" and group.n or group.area, true), util.format_number(group.rate, true)}
    panel.rows["state_" .. i].caption = group.status == "fluid"
      and {"air-logistics.mining-fluid", {"fluid-name." .. group.required}}
      or {"air-logistics.mining-status-" .. (mining.enabled and group.status or "off")}
  end
  local nearby = player.controller_type ~= defines.controllers.remote and player.can_reach_entity(tower.entity)
  content.hangar_frame.visible = nearby
  if content.robots_frame then content.robots_frame.visible = nearby end
end

local function refresh_circuit(root, info, tower)
  local circuit = tab(root, "circuit").panel_circuit
  local cb = tower.entity.get_or_create_control_behavior()
  circuit.panel_circuit_red.state = not (W.supports_output_networks(cb) and cb.output_networks
    and cb.output_networks.red == false)
  circuit.panel_circuit_green.state = not (W.supports_output_networks(cb) and cb.output_networks
    and cb.output_networks.green == false)
  circuit.panel_circuit_contents.state = cb.read_contents
  local message
  if info.storage_conflict then message = {"air-logistics.storage-conflict"}
  elseif info.rules_blocked then message = {"air-logistics.circuit-storage-blocked"}
  else message = "" end
  local label = tab(root, "circuit").message
  if label then label.caption = message end
  local settings_message = storage_message(root)
  if settings_message then settings_message.caption = message end
end

local function refresh_status(root, info)
  local pill = root.titlebar.status
  local state = info.visual_state or "idle"
  pill.caption = {"air-logistics.state-" .. state}
  pill.style.font_color = state_colors[state] or state_colors.idle
end

function Panel.refresh(player, sync_fields)
  local root = player.gui.screen[gui_name]
  if not root then return end
  local info = N.inspect(root.tags.tower)
  if not info then root.destroy(); return end
  local tower = storage.towers[root.tags.tower]
  if not tower or not tower.entity.valid then root.destroy(); return end
  refresh_tabs(root)
  refresh_status(root, info)
  refresh_recovery(root, tower)
  refresh_partitions(root, info)
  refresh_editor(root, info)
  refresh_logistics(root, info, tower, player, sync_fields == true)
  refresh_circuit(root, info, tower)
end

local function build_titlebar(root, entity)
  local titlebar = root.add{type = "flow", name = "titlebar", direction = "horizontal"}
  titlebar.style.vertical_align = "center"
  local title = titlebar.add{type = "label", caption = {"entity-name." .. entity.name}, style = "frame_title"}
  title.style.left_margin = 6
  local drag = titlebar.add{type = "empty-widget", style = "draggable_space_header"}
  drag.style.horizontally_stretchable = true
  drag.style.height = 24
  drag.drag_target = root
  local status = titlebar.add{type = "label", name = "status", caption = ""}
  status.style.font = "default-bold"
  status.style.right_margin = 8
  titlebar.add{type = "sprite-button", name = "air_logistics_close", sprite = "utility/close",
    style = "frame_action_button", tooltip = {"gui.close-instruction"}}
end

local function build_storage_tab(root, tower, player)
  local content = tab(root, "storage")
  local toolbar = content.add{type = "flow", name = "toolbar", direction = "horizontal"}
  toolbar.style.vertical_align = "center"
  toolbar.add{type = "button", name = "add_item_partition", caption = {"air-logistics.add-item"}}
  if tower.interstellar then
    toolbar.add{type = "button", name = "add_fluid_partition", caption = {"air-logistics.add-fluid"}}
  end
  toolbar.add{type = "label", name = "message", caption = ""}
  toolbar.message.style.left_margin = 10

  local body = content.add{type = "flow", name = "body", direction = "horizontal"}
  body.style.vertical_align = "top"
  local frame = panel_frame(body, "partition_frame", 660)
  header(frame, {"air-logistics.partition-config"})
  local header_row = frame.add{type = "flow", name = "partition_header", direction = "horizontal"}
  header_row.style.horizontal_spacing = 6
  header_row.style.top_margin = 2
  local function head(caption, width, align)
    local label = header_row.add{type = "label", caption = caption}
    label.style.font = "default-small"
    label.style.font_color = {r = 0.62, g = 0.66, b = 0.72}
    label.style.width = width
    label.style.horizontal_align = align or "left"
  end
  head("", 30)
  head({"air-logistics.col-cargo"}, 118)
  head({"air-logistics.col-side"}, 78)
  head({"air-logistics.col-mode"}, 52)
  head({"air-logistics.col-amount"}, 70, "right")
  head({"air-logistics.col-stock"}, 92, "right")
  head("", 54)
  local scroll = frame.add{type = "scroll-pane", name = "partition_scroll", horizontal_scroll_policy = "never"}
  scroll.style.maximal_height = 300
  local table_element = scroll.add{type = "flow", name = "partition_table", direction = "vertical"}
  table_element.style.vertical_spacing = 3
  scroll.add{type = "label", name = "partition_empty", caption = {"air-logistics.no-partition"}}

  local editor = panel_frame(body, "editor", 380)
  header(editor, {"air-logistics.partition-settings"})
  local title = editor.add{type = "label", name = "title", caption = {"air-logistics.new-partition"}}
  title.style.font = "default-bold"
  editor.add{type = "label", name = "interface", caption = ""}
  editor.add{type = "label", name = "empty", caption = {"air-logistics.select-partition"},
    tooltip = {"air-logistics.partition-help"}}
  local form = editor.add{type = "flow", name = "form", direction = "vertical"}
  local cargo = form.add{type = "flow", name = "cargo", direction = "horizontal"}
  cargo.style.vertical_align = "center"
  cargo.add{type = "label", caption = {"air-logistics.cargo"}}
  cargo.add{type = "choose-elem-button", name = "editor_item", elem_type = "item-with-quality"}
  cargo.add{type = "choose-elem-button", name = "editor_fluid", elem_type = "fluid"}
  local mode = form.add{type = "flow", name = "mode_row", direction = "horizontal"}
  mode.style.vertical_align = "center"
  mode.add{type = "label", caption = {"air-logistics.editor-mode"}}
  mode.add{type = "drop-down", name = "editor_mode", items = {{"air-logistics.request"}, {"air-logistics.supply"}}}
  local amount = form.add{type = "flow", name = "count_row", direction = "horizontal"}
  amount.style.vertical_align = "center"
  amount.add{type = "label", caption = {"air-logistics.editor-amount"}}
  local count = amount.add{type = "textfield", name = "editor_count", text = "1000", numeric = true,
    allow_decimal = false, allow_negative = false}
  count.style.width = 110
  local buttons = form.add{type = "flow", name = "buttons", direction = "horizontal"}
  buttons.add{type = "button", name = "editor_save", caption = {"air-logistics.save"}}
  buttons.add{type = "button", name = "editor_delete", caption = {"air-logistics.delete"}}

  local recovery = content.add{type = "flow", name = "recovery", direction = "vertical", visible = false}

  local bag = panel_frame(content, "bag_frame", 470)
  header(bag, {"air-logistics.player-inventory"})
  local bag_scroll = bag.add{type = "scroll-pane", name = "bag_scroll", horizontal_scroll_policy = "never"}
  bag_scroll.style.maximal_height = 116
  if not gui_inventory(bag_scroll, {type = "inventory", name = "player_inventory", slots_per_row = 9},
      player.get_main_inventory()) then
    bag_scroll.add{type = "label", caption = {"air-logistics.no-inventory-grid"},
      tooltip = {"air-logistics.no-inventory-grid-help"}}
  end
end

local function build_logistics_tab(root, tower)
  local content = tab(root, "logistics")

  local hangar = panel_frame(content, "hangar_frame", 640)
  header(hangar, {"air-logistics." .. (tower.interstellar and "ship-hangar" or "hangar")})
  local aircraft = hangar.add{type = "scroll-pane", name = "aircraft", horizontal_scroll_policy = "never"}
  aircraft.style.maximal_height = 76
  local grid = gui_inventory(aircraft, {type = "inventory", name = "hangar", slots_per_row = 10,
    handle_cursor_transfer = false, handle_cursor_split = false,
    empty_slot_info = {sprite = "item/" .. T.get(tower).plane, text = {"air-logistics.hangar-help"}}}, tower.hangar)
  if not grid then
    local fallback = hangar.add{type = "flow", name = "hangar_fallback", direction = "horizontal"}
    fallback.style.vertical_align = "center"
    fallback.style.horizontal_spacing = 6
    for _, name in ipairs(tower.interstellar and {T.planet.plane, T.space.plane} or {T.planet.plane}) do
      if T.accepts(tower, name) then
        local icon = fallback.add{type = "sprite-button", name = "hangar_take_" .. name, sprite = "item/" .. name,
          style = "slot_button", tooltip = {"air-logistics.hangar-take"}}
        icon.style.size = 32
        fallback.add{type = "label", name = "hangar_count_" .. name, caption = "0"}
        fallback.add{type = "button", name = "hangar_store_" .. name, caption = "+",
          tooltip = {"air-logistics.hangar-store"}}
      end
    end
  end
  local requests = hangar.add{type = "table", name = "panel_hangar_requests", column_count = 4}
  requests.style.vertical_spacing = 2
  for _, key in ipairs(tower.interstellar and {"plane_request", "ship_request"} or {"plane_request"}) do
    requests.add{type = "label", caption = {"air-logistics." .. key}}
    local field = requests.add{type = "textfield", name = "panel_hangar_" .. key, text = tostring(tower.options[key]),
      numeric = true, allow_decimal = false, allow_negative = false, tooltip = {"air-logistics.hangar-request-help"}}
    field.style.width = 80
    requests.add{type = "empty-widget"}
    requests.add{type = "empty-widget"}
  end

  local info = panel_frame(content, "info_frame", 640)
  header(info, {"air-logistics.settings"})
  info.add{type = "label", name = "energy", caption = ""}
  info.add{type = "label", name = "planes", caption = ""}
  if tower.interstellar then info.add{type = "label", name = "airplanes", caption = ""} end
  local options = info.add{type = "table", name = "panel_options", column_count = 2}
  options.add{type = "checkbox", name = "option_enabled", state = tower.options.enabled,
    caption = {"air-logistics.enabled"}}
  options.add{type = "empty-widget"}
  for _, key in ipairs({"min_load", "priority"}) do
    options.add{type = "label", caption = {"air-logistics." .. (tower.interstellar and key == "min_load"
      and "ship-min-load" or "option-" .. key)}}
    local field = options.add{type = "textfield", name = "option_" .. key, text = tostring(tower.options[key]),
      numeric = true, allow_decimal = false, allow_negative = false}
    field.style.width = 80
  end

  local robots = panel_frame(content, "robots_frame", 640)
  header(robots, {"air-logistics.robot-platform"})
  local robot_grid = gui_inventory(robots, {type = "inventory", name = "robots", slots_per_row = 10,
    handle_cursor_transfer = false, handle_cursor_split = false}, B.inventory(tower))
  local material_grid = gui_inventory(robots, {type = "inventory", name = "robot_material", slots_per_row = 10,
    handle_cursor_transfer = false, handle_cursor_split = false}, B.inventory(tower, true))
  if not (robot_grid or material_grid) then robots.destroy() end

  local mining = panel_frame(content, "mining_frame", 640)
  local panel = mining.add{type = "flow", name = "panel_mining", direction = "vertical"}
  header(panel, {"air-logistics.mining-title"})
  panel.add{type = "label", name = "mining_state", caption = ""}
  panel.add{type = "table", name = "rows", column_count = 4}
end

local function build_circuit_tab(root)
  local content = tab(root, "circuit")
  local circuit = panel_frame(content, "panel_circuit", 640)
  header(circuit, {"gui-control-behavior.circuit-connection"})
  circuit.add{type = "checkbox", name = "panel_circuit_red", state = true, caption = {"air-logistics.red-wire"}}
  circuit.add{type = "checkbox", name = "panel_circuit_green", state = true, caption = {"air-logistics.green-wire"}}
  circuit.add{type = "checkbox", name = "panel_circuit_contents", state = false,
    caption = {"gui-control-behavior-modes.read-contents"}}
  content.add{type = "label", name = "message", caption = ""}
end

function Panel.open(player, entity)
  local root_old = player.gui.screen[gui_name]
  if root_old then root_old.destroy() end
  local tower = N.register(entity)
  if not tower then return end
  player.opened = nil
  local root = player.gui.screen.add{type = "frame", name = gui_name, direction = "vertical",
    tags = {tower = entity.unit_number, panel = true, selected_kind = "item", center_after = game.tick + 2}}
  build_titlebar(root, entity)
  local width = math.max(920, math.min(1300, player.display_resolution.width / player.display_scale - 120))
  local height = math.max(260, math.min(700, player.display_resolution.height / player.display_scale - 200))
  local tabbar = root.add{type = "flow", name = "tabbar", direction = "horizontal"}
  tabbar.style.horizontal_spacing = 4
  for _, spec in ipairs({{"storage", "tab-storage"}, {"logistics", "tab-logistics"},
      {"circuit", "tab-circuit"}}) do
    local button = tabbar.add{type = "button", name = "tab_button_" .. spec[1],
      caption = {"air-logistics." .. spec[2]}, style = "button"}
    button.style.minimal_width = 118
  end
  local pages = root.add{type = "flow", name = "pages", direction = "vertical"}
  pages.style.minimal_width = width - 24
  for _, key in ipairs(tab_keys) do
    local page = pages.add{type = "frame", name = "page_" .. key, direction = "vertical"}
    page.style.minimal_width = width - 28
    local content = page.add{type = "scroll-pane", name = "content", horizontal_scroll_policy = "never"}
    content.style.maximal_height = height
    content.style.minimal_width = width - 44
  end
  build_storage_tab(root, tower, player)
  build_logistics_tab(root, tower)
  build_circuit_tab(root)
  local tags = root.tags
  tags.tab = "storage"
  root.tags = tags
  refresh_tabs(root)
  Panel.refresh(player, true)
  root.force_auto_center()
  player.opened = root
end

local function select(root, kind, index)
  local tags = root.tags
  tags.selected_kind, tags.selected_index, tags.draft = kind, index, nil
  root.tags = tags
  storage_editor(root).tags = {}
end

local function refresh_options(root, tower)
  local options = deepcopy(tower.options or {})
  local info = tab(root, "logistics")
  local options_panel = info.info_frame.panel_options
  options.enabled = options_panel.option_enabled.state
  options.min_load = options_panel.option_min_load.text
  options.priority = options_panel.option_priority.text
  local requests = info.hangar_frame.panel_hangar_requests
  options.plane_request = requests.panel_hangar_plane_request.text
  if requests.panel_hangar_ship_request then options.ship_request = requests.panel_hangar_ship_request.text end
  local valid = N.configure_options(root.tags.tower, options)
  local message = storage_message(root)
  if message then message.caption = valid and {"air-logistics.saved"} or {"air-logistics.invalid"} end
  return valid
end

local function apply_circuit(root, tower)
  local circuit = tab(root, "circuit").panel_circuit
  local cb = tower.entity.get_or_create_control_behavior()
  if W.supports_output_networks(cb) then
    cb.output_networks = {red = circuit.panel_circuit_red.state, green = circuit.panel_circuit_green.state}
  end
  cb.read_contents = circuit.panel_circuit_contents.state
  W.ensure(tower, true)
end

local function save_editor(player, root)
  local tower = storage.towers[root.tags.tower]
  if not tower or not tower.entity.valid then return end
  local editor = storage_editor(root)
  local form = editor.form
  local kind = root.tags.selected_kind or "item"
  local index = root.tags.selected_index or 1
  local draft = root.tags.draft == true
  local mode = mode_names[form.mode_row.editor_mode.selected_index] or "request"
  local count = mode == "supply" and "0" or form.count_row.editor_count.text
  local valid, new_index
  if kind == "item" then
    local value = form.cargo.editor_item.elem_value
    if not value or not value.name then storage_message(root).caption = {"air-logistics.invalid-cargo"}; return end
    local slots = deepcopy(tower.slots or {})
    local entry = {name = value.name, quality = value.quality or "normal", mode = mode, count = count}
    if draft then slots[#slots + 1], new_index = entry, #slots + 1 else slots[index], new_index = entry, index end
    valid = N.configure(root.tags.tower, slots)
  else
    local name = form.cargo.editor_fluid.elem_value
    if not name then storage_message(root).caption = {"air-logistics.invalid-cargo"}; return end
    local rules = deepcopy(tower.fluid_rules or {})
    local entry = {name = name, type = "fluid", quality = "normal", mode = mode, count = count}
    if draft then rules[#rules + 1], new_index = entry, #rules + 1 else rules[index], new_index = entry, index end
    valid = N.configure_fluids(root.tags.tower, rules)
  end
  local message = storage_message(root)
  if valid then
    local tags = root.tags
    tags.draft, tags.selected_kind, tags.selected_index = nil, kind, new_index
    root.tags = tags
    editor.tags = {}
    message.caption = {"air-logistics.saved"}
    Panel.refresh(player, true)
  else
    message.caption = kind == "fluid" and {"air-logistics.invalid-fluid"} or {"air-logistics.invalid"}
  end
end

local function delete_editor(player, root)
  local tower = storage.towers[root.tags.tower]
  if not tower or not tower.entity.valid then return end
  local editor = storage_editor(root)
  local message = storage_message(root)
  local kind = root.tags.selected_kind or "item"
  local index = root.tags.selected_index or 1
  if root.tags.draft then
    local tags = root.tags
    tags.draft, tags.selected_index = nil, nil
    root.tags = tags
    editor.tags = {}
    Panel.refresh(player)
    return
  end
  local valid
  if kind == "item" then
    local slots = deepcopy(tower.slots or {})
    table.remove(slots, index)
    valid = N.configure(root.tags.tower, slots)
  else
    local rules = deepcopy(tower.fluid_rules or {})
    table.remove(rules, index)
    valid = N.configure_fluids(root.tags.tower, rules)
  end
  if valid then
    local tags = root.tags
    tags.selected_index = index > 1 and (index - 1) or 1
    root.tags = tags
    editor.tags = {}
    message.caption = {"air-logistics.saved"}
    Panel.refresh(player)
  else
    message.caption = {"air-logistics.storage-conflict"}
  end
end

local function cargo_click(player, root, index)
  local tower = storage.towers[root.tags.tower]
  if not tower or not tower.entity.valid or tower.entity.force ~= player.force then return end
  if player.controller_type == defines.controllers.remote or not player.can_reach_entity(tower.entity) then return end
  local rule = tower.effective_slots and tower.effective_slots[index]
  if not rule then return end
  W.preserve(tower, game.tick, true)
  local cursor = player.cursor_stack
  if cursor.valid_for_read then
    if cursor.name ~= rule.name or cursor.quality.name ~= (rule.quality or "normal") then return end
    W.transfer(tower, cursor)
  else
    local target = player.get_main_inventory()
    local amount = math.min(W.count(tower, rule), prototypes.item[rule.name].stack_size)
    for _, inventory in ipairs(W.inventories(tower)) do
      amount = amount - W.move(inventory, target, rule, amount)
      if amount <= 0 then break end
    end
  end
  Panel.refresh(player)
end

function Panel.click(event)
  local player = game.get_player(event.player_index)
  local root = player.gui.screen[gui_name]
  if not root then return end
  local name = event.element.name
  local tab_key = name:match("^tab_button_(%a+)$")
  local row_kind, row_index = name:match("^partition_edit_(%a+)_(%d+)$")
  local stock = tonumber(name:match("^stock_item_icon_(%d+)$"))
  local legacy_take = tonumber(name:match("^legacy_take_(%d+)$"))
  if tab_key then
    local tags = root.tags
    tags.tab = tab_key
    root.tags = tags
    refresh_tabs(root)
  elseif row_kind then
    select(root, row_kind, tonumber(row_index)); Panel.refresh(player)
  elseif stock then cargo_click(player, root, stock)
  elseif legacy_take then
    local tower = storage.towers[root.tags.tower]
    local inventory = tower and tower.legacy_warehouse and tower.legacy_warehouse[legacy_take]
    local bag = player.get_main_inventory()
    if inventory and inventory.valid and bag and tower.entity.valid
      and player.controller_type ~= defines.controllers.remote and player.can_reach_entity(tower.entity) then
      W.preserve(tower, game.tick, true)
      for i = 1, #inventory do
        if inventory[i].valid_for_read then W.transfer_from_stack(bag, inventory[i]) end
      end
      Panel.refresh(player)
    end
  elseif name == "add_item_partition" then
    local tower = storage.towers[root.tags.tower]
    local tags = root.tags
    tags.selected_kind, tags.selected_index, tags.draft = "item", #(tower.slots or {}) + 1, true
    root.tags = tags
    storage_editor(root).tags = {}
    Panel.refresh(player)
  elseif name == "add_fluid_partition" then
    local tower = storage.towers[root.tags.tower]
    if not tower.interstellar then return end
    local tags = root.tags
    tags.selected_kind, tags.selected_index, tags.draft = "fluid", #(tower.fluid_rules or {}) + 1, true
    root.tags = tags
    storage_editor(root).tags = {}
    Panel.refresh(player)
  elseif name == "editor_save" then save_editor(player, root)
  elseif name == "editor_delete" then delete_editor(player, root)
  elseif name:match("^panel_mining_enabled_%d+$") then
    local tower = storage.towers[root.tags.tower]
    local tags = event.element.tags
    if tower and tags then
      local valid = M.set_enabled(root.tags.tower, tags.kind, tags.resource, event.element.state)
      local message = storage_message(root)
      if message then message.caption = valid and {"air-logistics.saved"} or {"air-logistics.invalid"} end
      Panel.refresh(player)
    end
  elseif name == "panel_circuit_red" or name == "panel_circuit_green" or name == "panel_circuit_contents" then
    local tower = storage.towers[root.tags.tower]
    if tower then apply_circuit(root, tower); Panel.refresh(player) end
  end
end

function Panel.changed(event)
  local player = game.get_player(event.player_index)
  local root = player.gui.screen[gui_name]
  if not root then return end
  local name = event.element.name
  local tower = storage.towers[root.tags.tower]
  if not tower then return end
  if name == "editor_mode" then
    local supply = event.element.selected_index == mode_index.supply
    local count = storage_editor(root).form.count_row.editor_count
    count.enabled = not supply
    if supply then count.text = "0" end
  elseif name == "editor_item" or name == "editor_fluid" then
    local message = storage_message(root)
    if message then message.caption = "" end
  elseif name:match("^panel_option_") or name:match("^panel_hangar_") then
    refresh_options(root, tower)
  end
end

script.on_event(defines.events.on_gui_click, Panel.click)
script.on_event({defines.events.on_gui_elem_changed, defines.events.on_gui_text_changed,
  defines.events.on_gui_selection_state_changed, defines.events.on_gui_checked_state_changed}, Panel.changed)

return Panel
