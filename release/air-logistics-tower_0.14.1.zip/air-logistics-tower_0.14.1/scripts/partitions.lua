local T = require("scripts.tier")
local P = {item_interfaces = 12, fluid_interfaces = 8,
  item_per_side = 3, fluid_per_side = 2,
  sides = {"north", "east", "south", "west"}}

function P.item_count(tower)
  return #((tower and (tower.effective_slots or tower.slots)) or {})
end

function P.fluid_count(tower)
  return #((tower and tower.fluid_rules) or {})
end

function P.clean_items(slots)
  if type(slots) ~= "table" then return nil end
  local clean, seen = {}, {}
  for i = 1, #slots do
    local slot = slots[i]
    if slot ~= nil then
      if type(slot) ~= "table" or type(slot.name) ~= "string" then return nil end
      local quality = slot.quality or "normal"
      if not prototypes.item[slot.name] or not prototypes.quality[quality] or T.is_aircraft(slot.name) then return nil end
      local mode = slot.mode == "storage" and "supply" or slot.mode
      if mode ~= "supply" and mode ~= "request" then return nil end
      local count = mode == "supply" and 0 or tonumber(slot.count)
      if not count or count ~= count or count < 0 or count > 1000000 then return nil end
      local key = slot.name .. "/" .. quality
      if seen[key] then return nil end
      seen[key] = true
      clean[#clean + 1] = {name = slot.name, quality = quality, mode = mode, count = math.floor(count)}
    end
  end
  return clean
end

function P.clean_fluids(rules)
  if type(rules) ~= "table" then return nil end
  local clean, seen = {}, {}
  for i = 1, #rules do
    local rule = rules[i]
    if rule ~= nil then
      if type(rule) ~= "table" or type(rule.name) ~= "string" or not prototypes.fluid[rule.name] then return nil end
      local mode = rule.mode == "storage" and "supply" or rule.mode
      if mode ~= "supply" and mode ~= "request" then return nil end
      local count = mode == "supply" and 0 or tonumber(rule.count)
      if not count or count ~= count or count < 0 or count > 1000000 then return nil end
      if seen[rule.name] then return nil end
      seen[rule.name] = true
      clean[#clean + 1] = {name = rule.name, type = "fluid", quality = "normal",
        mode = mode, count = math.floor(count)}
      if #clean > P.fluid_interfaces then return nil end
    end
  end
  return clean
end

function P.migrate(tower)
  if tower.partition_layout == 2 then return false end
  tower.slots = P.clean_items(tower.slots) or {}
  tower.fluid_rules = P.clean_fluids(tower.fluid_rules) or {}
  tower.partition_layout = 2
  tower.merged_rules = nil
  tower.port_filters = nil
  tower.effective_port_filters = nil
  tower.port_auto = nil
  tower.port_input_filters = nil
  tower.warehouse_filter_signature = nil
  tower.port_ensure_signature = nil
  return true
end

return P
