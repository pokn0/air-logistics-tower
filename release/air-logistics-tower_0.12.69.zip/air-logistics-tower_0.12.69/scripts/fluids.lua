local F = {}
local T = require("scripts.tier")
F.layout = {{x=1.5,y=-4.5,direction=0},{x=4.5,y=1.5,direction=4},
  {x=1.5,y=4.5,direction=8},{x=-4.5,y=1.5,direction=12}}
local planet_layout={{x=0.5,y=-2.5,direction=0},{x=2.5,y=0.5,direction=4},
  {x=0.5,y=2.5,direction=8},{x=-2.5,y=0.5,direction=12}}

local fluid_id_api
local function uses_fluid_id()
  if fluid_id_api == nil then
    local base = script.active_mods and script.active_mods["base"]
    local major, minor, patch = 0, 0, 0
    if type(base) == "string" then
      major, minor, patch = base:match("^(%d+)%.(%d+)%.(%d+)")
    end
    major, minor, patch = tonumber(major) or 0, tonumber(minor) or 0, tonumber(patch) or 0
    fluid_id_api = major > 2 or (major == 2 and minor > 1) or (major == 2 and minor == 1 and patch >= 22)
  end
  return fluid_id_api
end

local function write_filter(tank, name)
  if uses_fluid_id() then return tank.set_fluid_filter(1, name) end
  return tank.set_fluid_filter(1, name and {name=name} or nil)
end

local function read_filter_name(tank)
  local filter = tank.get_fluid_filter(1)
  return type(filter) == "string" and filter or (filter and filter.name)
end

function F.index(tower, item)
  for i, rule in pairs(tower.fluid_rules or {}) do if rule.name == item.name then return i end end
end

function F.rules(tower)
  local result,grouped={},{}
  for i=1,4 do
    local rule=tower.fluid_rules and tower.fluid_rules[i]
    if rule then
      local mode=rule.mode
      local key=rule.name.."/"..mode
      local combined=grouped[key]
      if not combined then
        combined={name=rule.name,type="fluid",quality="normal",mode=mode,count=0}
        grouped[key]=combined;result[#result+1]=combined
      end
      if mode=="request" then combined.count=combined.count+rule.count end
    end
  end
  return result
end

function F.count(tower,item)
  local count=0
  for i,rule in pairs(tower.fluid_rules or {}) do
    local tank=tower.fluid_ports[i]
    if rule.name==item.name and rule.mode=="request" and tank.valid then count=count+tank.get_fluid_count(item.name) end
  end
  return count
end

function F.available(tower,item)
  local count=0
  for i,rule in pairs(tower.fluid_rules or {}) do
    local tank=tower.fluid_ports[i]
    if rule.name==item.name and rule.mode~="request" and tank.valid then
      count=count+math.max(0,tank.get_fluid_count(item.name)-(rule.mode=="supply" and rule.count or 0))
    end
  end
  return count
end

function F.can_insert(tower,item)
  for i,rule in pairs(tower.fluid_rules or {}) do
    local tank=tower.fluid_ports[i]
    if rule.name==item.name and rule.mode=="request" and tank.valid
      and tank.get_fluid_count() < math.min(rule.count,tank.get_fluid_capacity(1))-0.001 then return true end
  end
  return false
end

function F.configure(id, rules)
  local tower = storage.towers[id]
  if not tower or not tower.entity.valid or type(rules) ~= "table" then return false end
  local clean = {}
  for i=1,4 do
    local rule, old = rules[i], (tower.fluid_rules or {})[i]
    if rule then
      if type(rule) ~= "table" or type(rule.name) ~= "string" or not prototypes.fluid[rule.name]
        or (rule.mode ~= "supply" and rule.mode ~= "request" and rule.mode ~= "storage") then return false end
      local count = rule.mode == "supply" and 0 or tonumber(rule.count)
      if not count or count ~= count or count < 0 or count > 1000000 then return false end
      clean[i] = {name=rule.name, type="fluid", quality="normal", mode=rule.mode, count=math.floor(count)}
    end
    local tank = tower.fluid_ports and tower.fluid_ports[i]
    local contents = tank and tank.valid and tank.get_fluid(1)
    if contents and contents.amount > 0.001 and (not rule or contents.name ~= rule.name) then return false end
    if old and (not rule or old.name ~= rule.name) then
      for _, flight in pairs(storage.flights or {}) do
        if flight.item.type == "fluid" and flight.item.name == old.name
          and (flight.home == id or flight.source == id or flight.receiver == id) then return false end
      end
    end
  end
  tower.fluid_rules = clean
  tower.merged_rules = nil
  F.ensure(tower)
  return true
end

function F.ensure(tower)
  if T.get(tower) ~= T.space and not tower.fluid_rules then return end
  tower.fluid_rules, tower.fluid_ports = tower.fluid_rules or {}, tower.fluid_ports or {}
  local changed = false
  for i, spec in ipairs(tower.interstellar and F.layout or planet_layout) do
    local tank = tower.fluid_ports[i]
    if not tank or not tank.valid then
      tank = tower.entity.surface.create_entity{name="interstellar-logistics-fluid-port",
        position={tower.entity.position.x+spec.x, tower.entity.position.y+spec.y},
        direction=spec.direction, force=tower.entity.force}
      assert(tank, "Air Logistics Tower: could not create fluid interface")
      tank.destructible, tank.operable, tank.rotatable = false, false, false
      tower.fluid_ports[i] = tank
    end
    if tank.force ~= tower.entity.force then tank.force = tower.entity.force end
    local rule, contents = tower.fluid_rules[i], tank.get_fluid(1)
    if rule and not prototypes.fluid[rule.name] then tower.fluid_rules[i],rule,changed=nil,nil,true end
    if not rule and contents and contents.amount > 0.001 then
      rule = {name=contents.name, type="fluid", quality="normal", mode="storage", count=0}
      tower.fluid_rules[i],changed = rule,true
    end
    if rule and rule.mode=="supply" and rule.count ~= 0 then rule.count,changed=0,true end
    if read_filter_name(tank) ~= (rule and rule.name) then
      assert(write_filter(tank,rule and rule.name or nil),"Air Logistics Tower: could not set fluid filter")
    end
  end
  if changed then tower.request_map_cache, tower.request_revision = nil, (tower.request_revision or 0) + 1 end
end

function F.load(tower,item,amount)
  local cargo
  for i=1,4 do
    local rule,tank=tower.fluid_rules[i],tower.fluid_ports[i]
    if rule and rule.name==item.name and rule.mode~="request" and tank.valid then
      local reserve=rule.mode=="supply" and rule.count or 0
      local portion=math.min(amount-(cargo and cargo.amount or 0),math.max(0,tank.get_fluid_count(item.name)-reserve))
      local fluid=portion>0.001 and tank.remove_fluid(1,portion)
      if fluid then
        if not cargo then cargo=fluid
        else
          cargo.temperature=(cargo.temperature*cargo.amount+fluid.temperature*fluid.amount)/(cargo.amount+fluid.amount)
          cargo.amount=cargo.amount+fluid.amount
        end
      end
    end
  end
  return cargo
end

function F.unload(tower,fluid,amount,restoring)
  if not fluid or fluid.amount <= 0.001 then return 0 end
  local delivered=0
  for i=1,4 do
    local rule,tank=tower.fluid_rules[i],tower.fluid_ports[i]
    if rule and rule.name==fluid.name and (restoring or rule.mode=="request") and tank.valid then
      local missing=restoring and fluid.amount or math.max(0,rule.count-tank.get_fluid_count(fluid.name))
      local portion=math.min(amount-delivered,fluid.amount,missing)
      if portion>0.001 then
        local inserted=tank.add_fluid(1,{name=fluid.name,amount=portion,temperature=fluid.temperature})
        fluid.amount,delivered=math.max(0,fluid.amount-inserted),delivered+inserted
      end
    end
  end
  return delivered
end

function F.restore(tower, fluid)
  if not fluid or fluid.amount <= 0.001 then return end
  if not F.index(tower, fluid) then
    for i=1,4 do
      if not tower.fluid_rules[i] and tower.fluid_ports[i].get_fluid_count() < 0.001 then
        tower.fluid_rules[i] = {name=fluid.name,type="fluid",quality="normal",mode="storage",count=0}
        F.ensure(tower)
        break
      end
    end
  end
  F.unload(tower, fluid, fluid.amount,true)
end

function F.snapshot(tower)
  local fluids = {}
  for i,tank in ipairs(tower.fluid_ports or {}) do if tank.valid then fluids[i] = tank.get_fluid(1) end end
  return fluids
end

function F.restore_snapshot(tower, fluids)
  for i,fluid in pairs(fluids or {}) do
    if tower.fluid_ports and tower.fluid_ports[i] then
      local added = tower.fluid_ports[i].add_fluid(1,fluid)
      assert(math.abs(added-fluid.amount)<0.01, "Air Logistics Tower: could not restore stored fluid")
    end
  end
end

function F.remove(tower)
  for _,tank in ipairs(tower.fluid_ports or {}) do if tank.valid then tank.destroy() end end
  tower.fluid_ports = nil
end
return F
