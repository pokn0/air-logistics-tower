local root = "__air-logistics-tower__/graphics/"
local tower = table.deepcopy(data.raw.container["air-logistics-tower"])
tower.name, tower.icon = "interstellar-logistics-tower", root.."interstellar-tower-icon.png"
tower.minable = {mining_time=2,result=tower.name}
tower.max_health, tower.inventory_size = 3000, 500
tower.collision_box, tower.selection_box = {{-4.8,-4.8},{4.8,4.8}}, {{-5,-5},{5,5}}
tower.circuit_wire_max_distance = 24
tower.picture = {filename=root.."interstellar-tower.png",width=640,height=704,scale=0.52,shift={0,-0.35}}
local power = table.deepcopy(data.raw["electric-energy-interface"]["air-logistics-power"])
power.name, power.collision_box = "interstellar-logistics-power", tower.collision_box
power.energy_source.buffer_capacity, power.energy_source.input_flow_limit, power.energy_source.drain = "200MJ", "10MW", "200kW"
local tank = table.deepcopy(data.raw["storage-tank"]["storage-tank"])
tank.name, tank.hidden = "interstellar-logistics-fluid-port", true
tank.flags = {"placeable-off-grid","not-on-map","not-blueprintable","not-deconstructable"}
tank.minable, tank.corpse, tank.fast_replaceable_group = nil,nil,nil
tank.selectable_in_game, tank.draw_circuit_wires, tank.show_fluid_icon = false,false,false
tank.collision_mask = {layers={}}
tank.collision_box, tank.selection_box = {{-0.4,-0.4},{0.4,0.4}},{{-0.5,-0.5},{0.5,0.5}}
tank.two_direction_only = false
tank.fluid_box.volume = 100000
tank.fluid_box.pipe_connections = {{direction=defines.direction.north,position={0,0},flow_direction="input-output"}}
local pipe_picture = {filename="__base__/graphics/entity/pipe/pipe-straight-vertical.png",width=128,height=128,scale=0.25}
tank.pictures = {picture={north=pipe_picture,east=pipe_picture,south=pipe_picture,west=pipe_picture}}
tank.window_bounding_box = {{0,0},{0,0}}
data:extend{tower,power,tank,
  {type="item-with-tags",name=tower.name,icon=tower.icon,icon_size=64,subgroup="logistic-network",order="z[air-logistics]-c",stack_size=5,place_result=tower.name},
  {type="item",name="interstellar-cargo-ship",icon=root.."interstellar-ship-icon.png",icon_size=64,subgroup="logistic-network",order="z[air-logistics]-d",stack_size=10},
  {type="recipe",name=tower.name,enabled=false,energy_required=30,ingredients={
    {type="item",name="air-logistics-tower",amount=1},{type="item",name="steel-plate",amount=100},
    {type="item",name="advanced-circuit",amount=40},{type="item",name="engine-unit",amount=20},
    {type="item",name="storage-tank",amount=4}},results={{type="item",name=tower.name,amount=1}}},
  {type="recipe",name="interstellar-cargo-ship",enabled=false,energy_required=20,ingredients={
    {type="item",name="steel-plate",amount=40},{type="item",name="advanced-circuit",amount=10},
    {type="item",name="engine-unit",amount=10},{type="item",name="plastic-bar",amount=20}},
    results={{type="item",name="interstellar-cargo-ship",amount=1}}},
  {type="technology",name="interstellar-logistics",icon=tower.icon,icon_size=64,
    prerequisites={"air-logistics","chemical-science-pack","fluid-handling","advanced-circuit"},
    effects={{type="unlock-recipe",recipe=tower.name},{type="unlock-recipe",recipe="interstellar-cargo-ship"}},
    unit={count=200,time=30,ingredients={{"automation-science-pack",1},{"logistic-science-pack",1},{"chemical-science-pack",1}}},order="c-k-e-b"},
  {type="sprite",name="interstellar-logistics-tower-preview",filename=root.."interstellar-tower.png",width=640,height=704},
  {type="sprite",name="interstellar-logistics-platform",filename=root.."interstellar-platform.png",width=640,height=640,scale=0.5},
  {type="sprite",name="interstellar-cargo-ship-shadow",filename=root.."interstellar-ship-shadow.png",width=384,height=384,scale=0.25},
  {type="animation",name="interstellar-cargo-ship-animated",layers={
    {filename=root.."interstellar-ship.png",width=384,height=384,scale=0.25,repeat_count=32},
    {filename=root.."interstellar-ship-effects.png",width=384,height=384,scale=0.25,line_length=8,frame_count=32,animation_speed=0.8}}}}
for _,state in ipairs({"idle","charging","launching","unpowered"}) do
  data:extend{{type="animation",name="interstellar-logistics-"..state,filename=root.."interstellar-tower-"..state..".png",
    width=640,height=704,line_length=8,frame_count=32,scale=0.52,shift={0,-0.35},animation_speed=0.2}}
end
