local empty = {filename="__core__/graphics/empty.png",width=1,height=1}
for _, mode in ipairs({"passive-provider","requester","buffer"}) do
  local bank=table.deepcopy(data.raw.container["air-logistics-storage-bin"])
  bank.type,bank.name="logistic-container","air-logistics-robot-"..mode
  bank.logistic_mode,bank.max_logistic_slots=mode,1
  bank.render_not_in_network_icon,bank.use_exact_mode=false,true
  data:extend{bank}
end
local hangar=table.deepcopy(data.raw["logistic-container"]["air-logistics-robot-requester"])
hangar.name,hangar.inventory_size,hangar.max_logistic_slots="air-logistics-hangar-requester",2,2
data:extend{hangar}
for _, tier in ipairs({{"air-logistics",25,55,7},{"interstellar-logistics",40,80,14}}) do
  local port=table.deepcopy(data.raw.roboport.roboport)
  port.name,port.hidden=tier[1].."-roboport",true
  port.flags={"player-creation","not-on-map","not-blueprintable","not-deconstructable"}
  port.minable,port.corpse,port.dying_explosion=nil,nil,nil
  port.collision_box=table.deepcopy(data.raw.container[tier[1]=="air-logistics" and "air-logistics-tower" or "interstellar-logistics-tower"].collision_box)
  port.collision_mask={layers={}}
  port.selectable_in_game=false
  port.base,port.base_patch,port.base_animation=empty,nil,nil
  port.door_animation_up,port.door_animation_down=nil,nil
  port.draw_circuit_wires,port.circuit_connector=false,nil
  port.logistics_radius,port.construction_radius=tier[2],tier[3]
  port.robot_slots_count,port.material_slots_count=tier[4],tier[4]
  port.stationing_offset={0,1}
  port.charging_offsets={{-2,-1},{2,-1},{-2,1},{2,1}}
  if tier[4]==14 then
    port.energy_source.input_flow_limit="10MW"
    port.charging_offsets={{-3,-2},{0,-2},{3,-2},{-3,0},{3,0},{-3,2},{0,2},{3,2}}
  end
  data:extend{port}
end
