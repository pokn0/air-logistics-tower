local root = "__air-logistics-tower__/graphics/"
local tower = table.deepcopy(data.raw.container["steel-chest"])
tower.name = "air-logistics-tower"
tower.flags = {"placeable-neutral", "player-creation", "no-automated-item-insertion", "no-automated-item-removal"}
tower.icon = root .. "tower-icon.png"
tower.icon_size = 64
tower.minable = {mining_time = 1, result = tower.name}
tower.max_health = 1500
tower.inventory_size = 150
tower.quality_affects_inventory_size = false
tower.collision_box = {{-2.8, -2.8}, {2.8, 2.8}}
tower.selection_box = {{-3, -3}, {3, 3}}
tower.circuit_wire_max_distance = 18
tower.fast_replaceable_group = nil
tower.next_upgrade = nil
tower.picture = {
  filename = root .. "tower.png", width = 512, height = 576,
  scale = 0.405, shift = {0, 0.35}
}
local storage_bin = table.deepcopy(data.raw.container["steel-chest"])
storage_bin.name = "air-logistics-storage-bin"
storage_bin.hidden = true
storage_bin.flags = {"player-creation", "not-on-map", "not-blueprintable", "not-deconstructable"}
storage_bin.minable, storage_bin.corpse = nil, nil
storage_bin.inventory_size = 50
storage_bin.inventory_type = "with_filters_and_bar"
storage_bin.collision_mask = {layers = {}}
storage_bin.selectable_in_game, storage_bin.draw_circuit_wires = false, false
storage_bin.picture = {filename = "__core__/graphics/empty.png", width = 1, height = 1}
storage_bin.circuit_wire_max_distance = 18
storage_bin.fast_replaceable_group, storage_bin.next_upgrade = nil, nil
data:extend({
  tower,
  storage_bin,
  {
    type = "item-with-tags", name = tower.name,
    icon = root .. "tower-icon.png", icon_size = 64,
    subgroup = "logistic-network", order = "z[air-logistics]-a", stack_size = 10,
    place_result = tower.name
  },
  {
    type = "item", name = "air-cargo-plane",
    icon = root .. "plane-icon.png", icon_size = 64,
    subgroup = "logistic-network", order = "z[air-logistics]-b", stack_size = 20
  },
  {
    type = "recipe", name = tower.name, enabled = false, energy_required = 10,
    ingredients = {
      {type = "item", name = "iron-plate", amount = 100},
      {type = "item", name = "copper-plate", amount = 50},
      {type = "item", name = "iron-gear-wheel", amount = 50},
      {type = "item", name = "electronic-circuit", amount = 20}
    },
    results = {{type = "item", name = tower.name, amount = 1}}
  },
  {
    type = "recipe", name = "air-cargo-plane", enabled = false, energy_required = 5,
    ingredients = {
      {type = "item", name = "iron-plate", amount = 20},
      {type = "item", name = "copper-plate", amount = 10},
      {type = "item", name = "iron-gear-wheel", amount = 10},
      {type = "item", name = "electronic-circuit", amount = 5}
    },
    results = {{type = "item", name = "air-cargo-plane", amount = 1}}
  },
  {
    type = "technology", name = "air-logistics",
    icon = root .. "tower-icon.png", icon_size = 64,
    prerequisites = {"automation", "logistics"},
    effects = {
      {type = "unlock-recipe", recipe = tower.name},
      {type = "unlock-recipe", recipe = "air-cargo-plane"}
    },
    unit = {count = 100, time = 20, ingredients = {{"automation-science-pack", 1}}}, order = "c-k-e"
  },
  {
    type = "electric-energy-interface", name = "air-logistics-power",
    hidden = true, flags = {"not-on-map", "not-blueprintable", "not-deconstructable"},
    max_health = 1500, collision_box = {{-2.8, -2.8}, {2.8, 2.8}},
    collision_mask = {layers = {}}, selectable_in_game = false,
    energy_source = {
      type = "electric", buffer_capacity = "50MJ", usage_priority = "secondary-input",
      input_flow_limit = "2MW", output_flow_limit = "0W", drain = "100kW"
    }, energy_production = "0W", energy_usage = "0W",
    picture = {filename = "__core__/graphics/empty.png", width = 1, height = 1}
  },
  {
    type = "sprite", name = "air-cargo-plane-flight",
    filename = root .. "plane.png", width = 384, height = 384, scale = 0.1875
  },
  {
    type = "sprite", name = "air-cargo-plane-shadow",
    filename = root .. "plane-shadow.png", width = 384, height = 384, scale = 0.1875
  }
})

for _, state in ipairs({"idle", "charging", "launching", "unpowered"}) do
  data:extend{{
    type = "animation", name = "air-logistics-" .. state,
    filename = root .. "tower-" .. state .. ".png", width = 512, height = 576,
    line_length = 8, frame_count = 32, scale = 0.405, shift = {0, 0.35},
    animation_speed = state == "launching" and 0.6 or 0.2
  }}
end
data:extend{{
  type = "animation", name = "air-cargo-plane-animated",
  layers = {
    {filename = root .. "plane.png", width = 384, height = 384, scale = 0.1875, repeat_count = 32},
    {filename = root .. "plane-effects.png", width = 384, height = 384, scale = 0.1875,
      line_length = 8, frame_count = 32, animation_speed = 0.8}
  }
}, {
  type = "animation", name = "air-cargo-downwash",
  filename = root .. "downwash.png", width = 192, height = 192, scale = 0.25,
  line_length = 8, frame_count = 32, animation_speed = 0.6
}}

local port = table.deepcopy(data.raw["loader-1x1"]["loader-1x1"])
port.type = "loader-1x1"
port.name = "air-logistics-belt-port"
port.flags = {"placeable-off-grid", "not-on-map", "not-blueprintable", "not-deconstructable"}
port.minable = nil
port.corpse = nil
port.selectable_in_game = false
port.collision_box = {{-0.4, -0.4}, {0.4, 0.4}}
port.selection_box = port.collision_box
port.container_distance = 2
port.belt_length = 0.5
port.allow_rail_interaction = false
port.fast_replaceable_group = "air-logistics-port"
port.structure_render_layer = "higher-object-above"
port.structure = {
  direction_in = {sheet = {filename = root .. "port-structure.png", width = 64, height = 64, scale = 0.5}},
  direction_out = {sheet = {filename = root .. "port-structure.png", width = 64, height = 64, y = 64, scale = 0.5}}
}
data:extend{port}
data:extend{{type="sprite",name="air-logistics-platform",filename=root.."tower-platform.png",width=512,height=512,scale=0.375}}
data:extend{{type="sprite",name="air-logistics-tower-preview",filename=root.."tower.png",width=512,height=576}}

local output = table.deepcopy(data.raw["constant-combinator"]["constant-combinator"])
output.name = "air-logistics-output"
output.hidden = true
output.flags = {"not-on-map", "not-blueprintable", "not-deconstructable"}
output.minable, output.sprites, output.activity_led_sprites, output.activity_led_light = nil, nil, nil, nil
output.collision_mask = {layers = {}}
output.selectable_in_game, output.draw_circuit_wires = false, false
data:extend{output}

for _, upgrade in ipairs({{"storage", "+50"}, {"speed", "+20%"}, {"cargo", "+1"}, {"fleet", "+1"}}) do
  data:extend{{type = "technology", name = "air-logistics-" .. upgrade[1],
    icon = root .. "tower-icon.png", icon_size = 64, prerequisites = {"air-logistics", "space-science-pack"},
    max_level = "infinite", upgrade = true,
    effects = {{type = "nothing", effect_description = {"air-logistics.upgrade-" .. upgrade[1]}}},
    unit = {count_formula = "1000*2^(L-1)", time = 60, ingredients = {
      {"automation-science-pack", 1}, {"logistic-science-pack", 1}, {"chemical-science-pack", 1},
      {"production-science-pack", 1}, {"utility-science-pack", 1}, {"space-science-pack", 1}
    }}, order = "c-k-f-" .. upgrade[1]
  }}
end

for _, signal in ipairs({{"enable", "E"}, {"min-load", "L"}, {"priority", "P"}, {"state", "S"},
  {"parked", "H"}, {"active", "A"}, {"charge", "C"}, {"set-rules", "R"}, {"set-filters", "F"}, {"read-status", "S"}}) do
  local prototype = table.deepcopy(data.raw["virtual-signal"]["signal-" .. signal[2]])
  prototype.name, prototype.order = "air-logistics-" .. signal[1], "z[air-logistics]-" .. signal[1]
  data:extend{prototype}
end

require("prototypes.interstellar")

require("prototypes.robots")
