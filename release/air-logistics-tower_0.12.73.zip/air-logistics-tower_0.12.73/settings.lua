data:extend{
  {type="bool-setting",name="air-logistics-mining-enabled",setting_type="runtime-global",default_value=true,order="a"},
  {type="int-setting",name="air-logistics-solid-gap",setting_type="runtime-global",default_value=5,minimum_value=1,maximum_value=10,order="b"},
  {type="int-setting",name="air-logistics-spring-gap",setting_type="runtime-global",default_value=30,minimum_value=1,maximum_value=60,order="c"},
  {type="string-setting",name="air-logistics-flight-render-mode",setting_type="runtime-global",
    default_value="adaptive",allowed_values={"full","adaptive","performance"},order="d"}
}
