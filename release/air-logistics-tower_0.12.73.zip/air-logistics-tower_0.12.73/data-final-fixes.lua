local template = data.raw["loader-1x1"]["air-logistics-belt-port"]
local masks=require("collision-mask-util")
for _,name in ipairs({"air-logistics-tower","interstellar-logistics-tower"}) do
  local tower=data.raw.container[name]
  tower.collision_mask=table.deepcopy(masks.get_mask(tower))
  tower.collision_mask.layers.water_tile=nil
  tower.collision_mask.layers.item=nil
  tower.collision_mask.layers.player=nil
end
if feature_flags.space_travel then
  template.max_belt_stack_size = data.raw["utility-constants"].default.max_belt_stack_size
  template.adjustable_belt_stack_size = true
end
for _, kind in ipairs({"transport-belt", "underground-belt", "splitter", "lane-splitter", "linked-belt"}) do
  for _, belt in pairs(data.raw[kind] or {}) do
    local port = table.deepcopy(template)
    port.name = template.name.."-"..belt.name
    port.speed = belt.speed
    port.belt_animation_set = table.deepcopy(belt.belt_animation_set or template.belt_animation_set)
    port.animation_speed_coefficient = belt.animation_speed_coefficient or template.animation_speed_coefficient
    data:extend{port}
  end
end
if data.raw.item["promethium-asteroid-chunk"] then
  for _,name in ipairs({"air-logistics-storage-bin","air-logistics-robot-passive-provider","air-logistics-robot-requester","air-logistics-robot-buffer"}) do
    local bank=table.deepcopy(data.raw.container[name] or data.raw["logistic-container"][name])
    bank.name=name.."-promethium"
    bank.inventory_type="with_custom_stack_size"
    bank.inventory_properties={with_bar=true,stack_size_override={["promethium-asteroid-chunk"]=50}}
    data:extend{bank}
  end
end
