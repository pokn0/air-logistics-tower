local R = {}
local T = require("scripts.tier")

function R.level(force, name)
  local tech = force.technologies["air-logistics-" .. name]
  return tech and math.max(0, tech.level - (tech.researched and 0 or 1)) or 0
end

function R.storage_per_bank(force, tower) return math.min(65535, T.get(tower).bank + 10 * R.level(force, "storage")) end
function R.cargo(force, tower) return math.min(65535, T.get(tower).cargo + R.level(force, "cargo")) end
function R.speed(force, tower) return T.get(tower).speed * (1 + 0.2 * R.level(force, "speed")) end
function R.planes(force, tower) return T.get(tower).fleet + R.level(force, "fleet") end

function R.fluid_cargo(force) return 10000 + 2000 * R.level(force, "cargo") end

return R
