local T = {}
T.planet = {name="air-logistics-tower", plane="air-cargo-plane", power="air-logistics-power",
  bank=50, cargo=6, speed=0.3, fleet=8, energy=50000000, input=2, ports_per_side=2, prefix="air-logistics"}
T.space = {name="interstellar-logistics-tower", plane="interstellar-cargo-ship", power="interstellar-logistics-power",
  bank=100, cargo=12, speed=0.6, fleet=16, energy=200000000, input=10, ports_per_side=3, prefix="interstellar-logistics"}
function T.get(tower)
  return (tower==T.space) and T.space or tower and (tower.interstellar or tower.entity and tower.entity.name == T.space.name) and T.space or T.planet
end
function T.is_tower(entity) return entity and entity.valid and (entity.name == T.planet.name or entity.name == T.space.name) end
function T.is_aircraft(name) return name == T.planet.plane or name == T.space.plane end
function T.accepts(tower, name)
  return name == T.planet.plane or tower.interstellar and name == T.space.plane
end
function T.group(tower, craft)
  local force = tower.entity.force.index
  if T.get(craft or tower) == T.space then
    if tower.group_space_key and tower.group_space_force == force then return tower.group_space_key end
    local key = force .. "/space"
    tower.group_space_force, tower.group_space_key = force, key
    return key
  end
  local surface = tower.entity.surface.index
  if tower.group_planet_key and tower.group_planet_force == force and tower.group_planet_surface == surface then
    return tower.group_planet_key
  end
  local key = force .. "/" .. surface
  tower.group_planet_force, tower.group_planet_surface, tower.group_planet_key = force, surface, key
  return key
end
return T
