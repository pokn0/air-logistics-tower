local C = {}
local deepcopy = require("util").table.deepcopy
local W = require("scripts.warehouse")
local T = require("scripts.tier")
local F = require("scripts.fluids")
C.defaults = {enabled = true, min_load = 100, priority = 0, circuit_enable = false,
  circuit_parameters = false, circuit_rules = false, circuit_filters = false, plane_request = 0, ship_request = 0}

for i = 1, W.slots do
  C.defaults["robot_mode_" .. i] = "off"
  C.defaults["robot_request_" .. i] = 1000
end

local function legacy_robot_request(tower, index)
  local slot = (tower.effective_slots or tower.slots or {})[index]
  if slot and (slot.mode=="request" or slot.count>0) then return slot.count end
  return 1000
end

function C.ensure(tower)
  if tower.options_ready then return end
  tower.options = tower.options or deepcopy(C.defaults)
  if tower.options.robot_mode_1 == nil then
    for i = 1, W.slots do
      tower.options["robot_mode_"..i] = W.robot_mode(tower,i)
      tower.options["robot_delivery_"..i] = nil
    end
  end
  if tower.options.robot_request_1 == nil then
    for i = 1, W.slots do tower.options["robot_request_"..i] = legacy_robot_request(tower,i) end
  end
  for key, value in pairs(C.defaults) do if tower.options[key] == nil then tower.options[key] = value end end
  if tower.circuit_version ~= 2 then
    if tower.output and tower.output.valid then
      tower.legacy_read_status = true
      local cb = tower.entity.get_or_create_control_behavior()
      cb.read_contents = true
      if W.supports_output_networks(cb) then cb.output_networks = {red = false, green = true} end
      tower.output.destroy()
      tower.output = nil
    end
    tower.output_signature, tower.circuit_version = nil, 2
  end
  tower.options_ready = true
end

function C.configure(id, options, from_tags)
  local tower = storage.towers[id]
  if not tower or not tower.entity.valid or type(options) ~= "table" then return false end
  C.ensure(tower)
  local clean = {}
  for key, default in pairs(C.defaults) do
    local value = options[key]
    local index = tonumber(key:match("^robot_mode_(%d)$"))
    local request_index = tonumber(key:match("^robot_request_(%d)$"))
    if request_index and value == nil and from_tags then
      value = legacy_robot_request(tower,request_index)
    end
    if index and value == nil and options["robot_delivery_"..index] ~= nil then
      if type(options["robot_delivery_"..index]) ~= "boolean" then return false end
      value = W.robot_mode({options=options, slots=tower.slots, effective_slots=tower.effective_slots},index)
    end
    if value == nil then value = tower.options and tower.options[key] end
    if value == nil then value = default end
    if index then
      if type(value) ~= "string" or not W.robot_modes[value] then return false end
    elseif type(default) == "boolean" then
      if type(value) ~= "boolean" then return false end
    else
      value = tonumber(value)
      local limit = request_index and 1000000 or (key == "plane_request" or key == "ship_request") and 10000 or 100
      if not value or value ~= value or value < 0 or value > limit or value % 1 ~= 0 then return false end
    end
    if key=="ship_request" and not tower.interstellar and value>0 then return false end
    clean[key] = value
  end
  tower.options = clean
  tower.options_ready = true
  C.update(tower)
  return true
end

local function filter_copy(source)
  local copy = {}
  for i, value in pairs(source or {}) do copy[i] = value end
  return copy
end

local function filters_differ(before, after, count)
  for i = 1, count do
    local x, y = before and before[i], after and after[i]
    if (x == nil) ~= (y == nil) then return true end
    if x and (x.name ~= y.name or (x.quality or "normal") ~= (y.quality or "normal")) then return true end
  end
  return false
end

function C.update(tower)
  C.ensure(tower)
  local options = tower.options
  local red = tower.entity.get_circuit_network(defines.wire_connector_id.circuit_red)
  local green = tower.entity.get_circuit_network(defines.wire_connector_id.circuit_green)
  if red == nil and green == nil then
    if tower.enabled ~= options.enabled then tower.port_scan_dirty = true end
    tower.enabled = options.enabled
    tower.effective_min_load, tower.effective_priority = options.min_load, options.priority
    tower.rules_controlled, tower.filters_controlled = false, false
    tower.read_status = tower.legacy_read_status == true
    local effective_slots = tower.slots
    tower.effective_port_filters = filter_copy(tower.port_filters)
    if effective_slots == tower.effective_slots or W.compatible(tower, effective_slots) then
      if effective_slots ~= tower.effective_slots then W.reassign_products(tower,effective_slots) end
      tower.effective_slots, tower.rules_blocked = effective_slots, false
      tower.storage_conflict = nil
      W.set_filters(tower, effective_slots)
    else
      tower.rules_blocked = true
    end
    return
  end
  local virtual, items = {}, {}
  local red_signals, green_signals = red and red.signals, green and green.signals
  local function collect(signals)
    for _, entry in pairs(signals or {}) do
      if entry.signal.type == "virtual" then
        local name = entry.signal.name
        virtual[name] = (virtual[name] or 0) + entry.count
      end
    end
  end
  collect(red_signals)
  collect(green_signals)
  for name, count in pairs(virtual) do if count == 0 then virtual[name] = nil end end
  local enable = virtual["air-logistics-enable"]
  local enabled = options.enabled and (enable == nil and not (options.circuit_enable and red ~= nil)
    or enable ~= nil and enable > 0)
  if tower.enabled ~= enabled then tower.port_scan_dirty = true end
  tower.enabled = enabled
  tower.effective_min_load, tower.effective_priority = options.min_load, options.priority
  for _, key in ipairs({"min_load", "priority"}) do
    local count = virtual[key == "min_load" and "air-logistics-min-load" or "air-logistics-priority"]
    if count then tower["effective_" .. key] = math.max(0, math.min(100, count)) end
  end
  local rules, filters = virtual["air-logistics-set-rules"], virtual["air-logistics-set-filters"]
  tower.rules_controlled = rules ~= nil and rules > 0 or rules == nil and options.circuit_rules and red ~= nil
  local filters_controlled = filters ~= nil and filters > 0 or filters == nil and options.circuit_filters and red ~= nil
  if tower.filters_controlled ~= filters_controlled then tower.port_scan_dirty = true end
  local previous_filters = tower.effective_port_filters
  tower.filters_controlled = filters_controlled
  local status = virtual["air-logistics-read-status"]
  tower.read_status = status ~= nil and status > 0 or status == nil and tower.legacy_read_status == true
  if tower.rules_controlled or tower.filters_controlled then
    local counts = {}
    local function collect_items(signals)
      for _, entry in pairs(signals or {}) do
        local signal = entry.signal
        if (not signal.type or signal.type == "item") and prototypes.item[signal.name] then
          local quality = signal.quality or "normal"
          local key = signal.name .. "/" .. quality
          local item = counts[key]
          if item then item.count = item.count + entry.count
          else counts[key] = {name=signal.name, quality=quality, count=entry.count} end
        end
      end
    end
    collect_items(red_signals)
    collect_items(green_signals)
    for _, item in pairs(counts) do if item.count ~= 0 then items[#items + 1] = item end end
    table.sort(items, function(a, b)
      if math.abs(a.count) ~= math.abs(b.count) then return math.abs(a.count) > math.abs(b.count) end
      if a.name ~= b.name then return a.name < b.name end
      return a.quality < b.quality
    end)
  end
  local effective_slots = tower.rules_controlled and {} or tower.slots
  tower.effective_port_filters = tower.filters_controlled and {} or deepcopy(tower.port_filters)
  local rule = 1
  for i, item in ipairs(items) do
    if tower.filters_controlled and i <= T.get(tower).ports_per_side*4 then
      tower.effective_port_filters[i] = {name = item.name, quality = item.quality}
    end
    if tower.rules_controlled and rule <= 5 and not T.is_aircraft(item.name) then
      effective_slots[rule] = {name = item.name, quality = item.quality,
        mode = item.count > 0 and "request" or "supply", count = item.count > 0 and math.min(1000000, item.count) or 0}
      rule = rule + 1
    end
  end
  if tower.filters_controlled and filters_differ(previous_filters, tower.effective_port_filters,
      T.get(tower).ports_per_side*4) then
    tower.port_scan_dirty = true
  end
  if effective_slots == tower.effective_slots or W.compatible(tower, effective_slots) then
    if effective_slots ~= tower.effective_slots then
      W.reassign_products(tower,effective_slots)
      tower.merged_rules = nil
    end
    tower.effective_slots, tower.rules_blocked = effective_slots, false
    tower.storage_conflict = nil
    W.set_filters(tower, effective_slots)
  else
    tower.rules_blocked = true
  end
end

function C.publish(tower, active)
  local cb = tower.entity.get_or_create_control_behavior()
  local read_fluids = tower.fluid_ports and cb.read_contents
  if not tower.read_status and not read_fluids then C.remove(tower); return end
  if not tower.output or not tower.output.valid then
    tower.output = tower.entity.surface.create_entity{name = "air-logistics-output",
      position = tower.entity.position, force = tower.entity.force}
    assert(tower.output, "Air Logistics Tower: could not create status output")
    tower.output.destructible, tower.output.operable = false, false
    tower.output_signature = nil
  end
  if tower.output.force ~= tower.entity.force then tower.output.force = tower.entity.force end
  for _, color in ipairs({"red", "green"}) do
    local id = defines.wire_connector_id["circuit_" .. color]
    local connector, target = tower.output.get_wire_connector(id, true), tower.entity.get_wire_connector(id, true)
    if not connector.is_connected_to(target, defines.wire_origin.script) then connector.connect_to(target, false, defines.wire_origin.script) end
  end
  local output_cb = tower.output.get_or_create_control_behavior()
  if W.supports_output_networks(cb) then
    output_cb.output_networks = cb.output_networks or {red = true, green = true}
  end
  local state, parked, charge
  if tower.read_status then
    parked = tower.hangar.get_item_count_filtered{name=T.planet.plane}+tower.hangar.get_item_count_filtered{name=T.space.plane}
    state, charge = tower.enabled and 1 or 0, math.floor(tower.power.energy / T.get(tower).energy * 100)
  end
  local fluid_names, fluid_amounts
  if read_fluids then
    local amounts = {}
    for _,fluid in pairs(F.snapshot(tower)) do amounts[fluid.name]=(amounts[fluid.name] or 0)+fluid.amount end
    fluid_names, fluid_amounts = {}, {}
    for name in pairs(amounts) do fluid_names[#fluid_names+1]=name end
    table.sort(fluid_names)
    for i,name in ipairs(fluid_names) do fluid_amounts[i]=math.floor(amounts[name]) end
  end
  local parts = {}
  if state then parts[#parts+1] = table.concat({state,parked,active,charge},"/") end
  if fluid_names then
    local names = {}
    for i,name in ipairs(fluid_names) do names[i]=name.."="..fluid_amounts[i] end
    parts[#parts+1] = table.concat(names,",")
  end
  local signature = table.concat(parts,"|")
  if signature == tower.output_signature then return end
  tower.output_signature = signature
  local filters = {}
  if state then
    for _, status in ipairs({{"state", state}, {"parked", parked}, {"active", active}, {"charge", charge}}) do
      filters[#filters + 1] = {value = {type = "virtual", name = "air-logistics-" .. status[1], quality = "normal", comparator = "="}, min = status[2]}
    end
  end
  if fluid_names then
    for i,name in ipairs(fluid_names) do
      filters[#filters+1]={value={type="fluid",name=name,quality="normal",comparator="="},min=fluid_amounts[i]}
    end
  end
  local rounds = 0
  while output_cb.sections_count > 1 do
    rounds = rounds + 1
    if rounds > 20 then
      log("Air Logistics Tower: output sections could not be cleared down to one")
      break
    end
    output_cb.remove_section(output_cb.sections_count)
  end
  local section = output_cb.get_section(1) or output_cb.add_section()
  section.filters = filters
end

function C.remove(tower)
  if tower.output and tower.output.valid then tower.output.destroy() end
  tower.output, tower.output_signature = nil, nil
end

return C
