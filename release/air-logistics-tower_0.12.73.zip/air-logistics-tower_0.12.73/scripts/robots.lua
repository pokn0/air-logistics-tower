local B={}
local T=require("scripts.tier")
local W=require("scripts.warehouse")

function B.inventory(tower,material)
  local port=tower.roboport
  return port and port.valid and port.get_inventory(material and defines.inventory.roboport_material or defines.inventory.roboport_robot)
end

function B.transfer(tower,stack)
  if not stack.valid_for_read then return end
  local type=stack.prototype.type
  if type=="item" and (stack.name=="logistic-robot" or stack.name=="construction-robot") then
    W.transfer_from_stack(B.inventory(tower), stack)
  elseif stack.name=="repair-pack" then W.transfer_from_stack(B.inventory(tower,true), stack) end
end

function B.ensure(tower)
  if not tower.roboport or not tower.roboport.valid then
    tower.roboport=tower.entity.surface.create_entity{name=T.get(tower).prefix.."-roboport",
      position=tower.entity.position,force=tower.entity.force,quality=tower.entity.quality}
    assert(tower.roboport,"Air Logistics Tower: could not create native roboport")
    tower.roboport.destructible,tower.roboport.operable=false,false
  end
  if tower.roboport.force~=tower.entity.force then tower.roboport.force=tower.entity.force end
end

local ROBOT_CARGO = {["logistic-robot"]=true, ["construction-robot"]=true, ["repair-pack"]=true}

function B.import(tower)
  for _,inv in ipairs(W.inventories(tower, true, ROBOT_CARGO)) do
    if not inv.is_empty() and (inv.get_item_count_filtered{name="logistic-robot"}>0 or inv.get_item_count_filtered{name="construction-robot"}>0
      or inv.get_item_count_filtered{name="repair-pack"}>0) then
      for i=1,#inv do if inv[i].valid_for_read and not W.index(tower,{name=inv[i].name,quality=inv[i].quality.name}) then B.transfer(tower,inv[i]) end end
    end
  end
end

function B.copy(source,target)
  local temp=game.create_inventory(1)
  for _,material in ipairs({false,true}) do
    local from,to=B.inventory(source,material),B.inventory(target,material)
    for i=1,#from do
      if from[i].valid_for_read then
        temp[1].set_stack(from[i]);W.transfer_from_stack(to, temp[1])
        assert(not temp[1].valid_for_read,"Air Logistics Tower: robot clone overflow")
      end
    end
  end
  temp.destroy()
end

function B.remove(tower,buffer,discard)
  local port=tower.roboport
  if not port or not port.valid then return end
  if discard then port.destroy(); tower.roboport=nil; return end
  for _,material in ipairs({false,true}) do
    local inv=B.inventory(tower,material)
    for i=1,#inv do
      local stack=inv[i]
      if stack.valid_for_read then
        if buffer and buffer.valid then W.transfer_from_stack(buffer, stack) end
        if stack.valid_for_read then
          local drops=port.surface.spill_item_stack{position=port.position,stack=stack,enable_looted=true,force=port.force,allow_belts=false,use_start_position_on_failure=true}
          assert(#drops>0,"Air Logistics Tower: could not recover robots")
          stack.clear()
        end
      end
    end
  end
  port.destroy();tower.roboport=nil
end

return B
