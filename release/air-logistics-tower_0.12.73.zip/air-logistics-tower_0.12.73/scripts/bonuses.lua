local R = require("scripts.research")
local T = require("scripts.tier")
local B = {}
local name = "air_logistics_bonuses"

function B.refresh(player, create)
  local frame = player.gui.relative[name]
  if not frame and not create then return end
  if not frame then
    frame = player.gui.relative.add{type="frame", name=name, direction="vertical",
      caption={"air-logistics.bonuses-title"},
      anchor={gui=defines.relative_gui_type.bonus_gui, position=defines.relative_gui_position.right}}
    frame.style.width = 360
    local body = frame.add{type="frame", name="body", direction="vertical", style="inside_deep_frame"}
    body.style.horizontally_stretchable = true
    body.style.vertically_stretchable = true
    local scroll = body.add{type="scroll-pane", name="scroll", direction="vertical",
      horizontal_scroll_policy="never", vertical_scroll_policy="auto"}
    scroll.style.horizontally_stretchable = true
    scroll.style.vertically_stretchable = true
    scroll.style.padding = 4
    local cards = scroll.add{type="table", name="cards", column_count=1}
    cards.style.horizontally_stretchable = true
    cards.style.vertical_spacing = 8
    for _, upgrade in ipairs({"storage", "speed", "cargo", "fleet"}) do
      local card = cards.add{type="frame", name=upgrade, direction="vertical", style="bonus_card_frame"}
      card.style.horizontally_stretchable = true
      local icons = card.add{type="table", name="icons", column_count=3}
      icons.add{type="sprite-button", name="technology", style="transparent_slot",
        game_controller_interaction=defines.game_controller_interaction.never,
        sprite="technology/air-logistics-"..upgrade,
        elem_tooltip={type="technology", name="air-logistics-"..upgrade}}
      for _, tier in ipairs({"planet", "space"}) do
        local item = upgrade == "storage" and T[tier].name or T[tier].plane
        icons.add{type="sprite-button", name=tier, style="transparent_slot",
          game_controller_interaction=defines.game_controller_interaction.never,
          sprite="item/"..item, elem_tooltip={type="item", name=item}}
      end
      local title = card.add{type="flow", name="title", direction="horizontal"}
      title.style.vertical_align = "center"
      title.add{type="label", caption={"technology-name.air-logistics-"..upgrade}, style="bold_label"}
      title.add{type="label", name="level"}
      for _, tier in ipairs({"planet", "space"}) do
        local label = card.add{type="label", name=tier}
        label.style.single_line = false
        label.style.maximal_width = 324
      end
      if upgrade == "cargo" then card.add{type="label", name="fluid"} end
    end
  end
  frame.style.height = math.max(180, math.min(650, player.display_resolution.height / player.display_scale - 150))
  local cards = frame.body.scroll.cards
  local force = player.force
  for _, upgrade in ipairs({"storage", "speed", "cargo", "fleet"}) do
    local card = cards[upgrade]
    local level = R.level(force, upgrade)
    card.title.level.caption = {"air-logistics.bonus-level", level}
    for _, tier in ipairs({"planet", "space"}) do
      local base = T[tier]
      local bonus, current
      if upgrade == "storage" then
        current = R.storage_per_bank(force, base)
        bonus = current - base.bank
      elseif upgrade == "speed" then
        current = string.format("%.1f", R.speed(force, base) * 60)
        bonus = level * 20
      elseif upgrade == "cargo" then
        current = R.cargo(force, base)
        bonus = current - base.cargo
      else
        current = R.planes(force, base)
        bonus = current - base.fleet
      end
      card[tier].caption = {"air-logistics.bonus-"..upgrade, {"entity-name."..base.name}, bonus, current}
    end
    if upgrade == "cargo" then
      card.fluid.caption = {"air-logistics.bonus-fluid", R.fluid_cargo(force)-10000, R.fluid_cargo(force)}
    end
  end
end

return B
