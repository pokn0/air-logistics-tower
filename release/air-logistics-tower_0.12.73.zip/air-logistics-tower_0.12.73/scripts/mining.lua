local M = {}
local W = require("scripts.warehouse")
local F = require("scripts.fluids")
local R = require("scripts.research")
local C = require("scripts.circuit")
local P = require("scripts.ports")
local meta_cache, names_cache = {}, nil
local function group_key(kind,name) return kind.."/"..name end
local function selected(m,g) return m and m.selected and m.selected[group_key(g.kind,g.name)] == true end
local function option(name,default)
  local value=settings.global["air-logistics-"..name]
  if value then return value.value end
  return default
end
function M.enabled() return option("mining-enabled",true) end

local function meta(name)
  local value=meta_cache[name]
  if value~=nil then return value or nil end
  local p=prototypes.entity[name]
  local mine=p and p.mineable_properties
  if not mine or not mine.minable or not mine.products or #mine.products==0 then meta_cache[name]=false;return end
  local products={}
  for _,v in ipairs(mine.products) do
    local amount=(v.amount or ((v.amount_min or 0)+(v.amount_max or 0))/2)*(v.independent_probability or v.probability or 1)+(v.extra_count_fraction or 0)
    if amount>0 then products[#products+1]={type=v.type,name=v.name,amount=amount,temperature=v.temperature,ignored=v.ignored_by_productivity or 0} end
  end
  if #products==0 then meta_cache[name]=false;return end
  value={products=products,kind=products[1].type=="fluid" and "spring" or "solid",
    required=mine.required_fluid,fluid=(mine.fluid_amount or 0)/10,infinite=p.infinite_resource,
    minimum=p.minimum_resource_amount or 0,depletion=p.infinite_depletion_resource_amount or 1}
  local box=p.selection_box
  value.area=value.kind=="solid" and math.max(1,(box.right_bottom.x-box.left_top.x)*(box.right_bottom.y-box.left_top.y)) or 1
  meta_cache[name]=value
  return value
end
local function names()
  if not names_cache then
    names_cache={solid={},spring={}}
    for name,p in pairs(prototypes.get_entity_filtered{{filter="type",type="resource"}}) do
      if p.type=="resource" then local v=meta(name);if v then table.insert(names_cache[v.kind],name) end end
    end
    table.sort(names_cache.solid);table.sort(names_cache.spring)
  end
  return names_cache
end
local function key(e)
  local p=e.position
  return e.name.."/"..p.x.."/"..p.y
end
local function drop(group,node)
  if node.live then node.live=false;group.n=group.n-1;group.area=group.area-node.area end
end
local function enqueue(tower)
  local m=tower.mining
  if m.queued then return end
  local jobs=storage.mining_jobs
  jobs.ids[#jobs.ids+1]=tower.entity.unit_number;m.queued=true
end
function M.register(tower,tags)
  if not storage.mining_jobs then M.init() end
  tower.mining=tower.mining or {groups={},lookup={},revision=0}
  local m=tower.mining
  if type(tags)=="table" then
    if type(tags.selected)=="table" then m.selected=table.deepcopy(tags.selected) end
    if type(tags.auto_items)=="table" then m.auto_items=table.deepcopy(tags.auto_items) end
    if type(tags.auto_fluids)=="table" then m.auto_fluids=table.deepcopy(tags.auto_fluids) end
  end
  tower.mining.selected=tower.mining.selected or {}
  tower.mining.auto_items=tower.mining.auto_items or {}
  tower.mining.auto_fluids=tower.mining.auto_fluids or {}
  tower.mining.id=tower.entity.unit_number;tower.mining.surface=tower.entity.surface_index
  if M.enabled() then enqueue(tower) end
end
function M.init()
  storage.mining_jobs={ids={},head=1};storage.mining_buckets={};storage.mining_work={jobs={},head=1}
  storage.mining_owners={}
  for i=0,5 do storage.mining_buckets[i]={} end
  for _,tower in pairs(storage.towers) do
    if tower.entity.valid then
      tower.mining=tower.mining or {groups={},lookup={},revision=0}
      tower.mining.selected=tower.mining.selected or {}
      tower.mining.auto_items=tower.mining.auto_items or {}
      tower.mining.auto_fluids=tower.mining.auto_fluids or {}
      tower.mining.id=tower.entity.unit_number;tower.mining.surface=tower.entity.surface_index
      tower.mining.queued=false;tower.mining.scan=nil;tower.mining.rescan_after=false
      if M.enabled() then enqueue(tower) end
    end
  end
end
function M.tags(tower)
  local m=tower.mining or {}
  return {selected=table.deepcopy(m.selected or {}),
    auto_items=table.deepcopy(m.auto_items or {}),
    auto_fluids=table.deepcopy(m.auto_fluids or {})}
end

function M.remove(tower)
  local m=tower.mining
  if not m then return end
  local id=m.id or tower.entity.valid and tower.entity.unit_number
  local surface=m.surface or tower.entity.valid and tower.entity.surface_index
  if not id or not surface then return end
  if storage.mining_buckets then storage.mining_buckets[id%6][id]=nil end
  for _,lookup in ipairs({m and m.lookup or {},m and m.scan and m.scan.lookup or {}}) do
    for k in pairs(lookup) do
      local global_key=surface.."/"..k
      local owners=storage.mining_owners[global_key]
      if owners then owners[id]=nil;if not next(owners) then storage.mining_owners[global_key]=nil end end
    end
  end
end
local function group(scan,name,kind)
  local k=kind.."/"..name
  local g=scan.groups[k]
  if not g then g={name=name,kind=kind,nodes={},n=0,area=0,cursor=1,credit=0,carry={}};scan.groups[k]=g end
  return g
end
local function add(scan,e,k,p)
  if not e.valid then return end
  k=k or key(e)
  if scan.lookup[k] then return end
  local data=meta(e.name)
  if not data then return end
  p=p or e.position
  local b=scan.bounds
  b.left_top.x=math.min(b.left_top.x,p.x);b.left_top.y=math.min(b.left_top.y,p.y)
  b.right_bottom.x=math.max(b.right_bottom.x,p.x);b.right_bottom.y=math.max(b.right_bottom.y,p.y)
  local g=group(scan,e.name,data.kind)
  local area=data.area
  local node={entity=e,position=p,area=area,live=true,group=g}
  scan.lookup[k]=node;g.nodes[#g.nodes+1]=node;g.n=g.n+1;g.area=g.area+area
  local global_key=scan.surface.."/"..k
  local owners=storage.mining_owners[global_key] or {};storage.mining_owners[global_key]=owners;owners[scan.owner]=true
  scan.frontier[#scan.frontier+1]=node
end
local function start(tower)
  local scan={groups={},lookup={},frontier={},head=1,cells={},owner=tower.entity.unit_number,surface=tower.entity.surface_index}
  tower.mining.scan=scan
  if tower.mining.groups and #tower.mining.groups>0 then
    scan.previous_groups=tower.mining.groups
    scan.previous_group=1
    scan.previous_node=1
  end
  local box=tower.entity.bounding_box
  scan.bounds=table.deepcopy(box)
  for _,e in ipairs(tower.entity.surface.find_entities_filtered{area=box,type="resource"}) do add(scan,e) end
  local s=tower.entity.surface
  for y=math.floor(box.left_top.y),math.ceil(box.right_bottom.y)-1 do
    for x=math.floor(box.left_top.x),math.ceil(box.right_bottom.x)-1 do
      local fluid=s.get_tile(x,y).prototype.fluid
      if fluid then local g=group(scan,fluid.name,"ocean");g.area=g.area+1 end
    end
  end
  return scan
end
local function scan_step(tower,quota)
  local m=tower.mining
  if not m.scan then
    if quota.starts==0 then return "wait" end
    quota.starts=quota.starts-1
    start(tower)
  end
  local scan=m.scan
  if scan.previous_groups then
    while scan.previous_groups and quota.seeds>0 do
      local previous=scan.previous_groups[scan.previous_group]
      if not previous then
        scan.previous_groups=nil
        scan.previous_group=nil
        scan.previous_node=nil
        break
      end
      local node=previous.nodes[scan.previous_node]
      if not node then
        scan.previous_group=scan.previous_group+1
        scan.previous_node=1
      else
        scan.previous_node=scan.previous_node+1
        quota.seeds=quota.seeds-1
        local e=node.entity
        if node.live and e and e.valid and e.surface_index==scan.surface then
          add(scan,e)
        end
      end
    end
    if scan.previous_groups then return "wait" end
  end
  if not scan.recovery_checked then
    scan.recovery_checked=true
    if not scan.frontier[1] and next(m.selected or {}) then
      local box=tower.entity.bounding_box
      local radius=math.max(option("solid-gap",5),option("spring-gap",30))
      scan.recovery=tower.entity.surface.find_entities_filtered{
        area={{box.left_top.x-radius,box.left_top.y-radius},
          {box.right_bottom.x+radius,box.right_bottom.y+radius}},
        type="resource"}
      scan.recovery_index=1
    end
  end
  if scan.recovery then
    local box=tower.entity.bounding_box
    while scan.recovery_index<=#scan.recovery and quota.seeds>0 do
      local e=scan.recovery[scan.recovery_index]
      scan.recovery_index=scan.recovery_index+1
      quota.seeds=quota.seeds-1
      if e.valid then
        local data=meta(e.name)
        if data and m.selected[group_key(data.kind,e.name)] then
          local p=e.position
          local dx=math.max(box.left_top.x-p.x,0,p.x-box.right_bottom.x)
          local dy=math.max(box.left_top.y-p.y,0,p.y-box.right_bottom.y)
          local gap=option(data.kind=="solid" and "solid-gap" or "spring-gap",data.kind=="solid" and 5 or 30)
          if dx*dx+dy*dy<=gap*gap then add(scan,e) end
        end
      end
    end
    if scan.recovery_index<=#scan.recovery then return "wait" end
    scan.recovery=nil
    scan.recovery_index=nil
  end
  local node=scan.frontier[scan.head]
  if node then
    if not node.entity.valid then drop(node.group,node);scan.head=scan.head+1;scan.cell=nil;return true end
    local kind=node.group.kind
    local gap=option(kind=="solid" and "solid-gap" or "spring-gap",kind=="solid" and 5 or 30)
    local size=math.min(gap,8)
    local cell=scan.cell
    if not cell then
      local p=node.position
      cell={left=math.floor((p.x-gap)/size),right=math.floor((p.x+gap)/size),
        top=math.floor((p.y-gap)/size),bottom=math.floor((p.y+gap)/size)}
      cell.x,cell.y=cell.left,cell.top;scan.cell=cell
    end
    local k=kind.."/"..cell.x.."/"..cell.y
    local candidates=scan.cells[k]
    if not candidates then
      if quota.cells==0 then return "wait" end
      quota.cells=quota.cells-1;candidates={};scan.cells[k]=candidates
      local x,y=cell.x*size,cell.y*size
      for _,e in ipairs(tower.entity.surface.find_entities_filtered{area={{x,y},{x+size,y+size}},type="resource",name=names()[kind]}) do
        local p=e.position
        if p.x>=x and p.x<x+size and p.y>=y and p.y<y+size then candidates[#candidates+1]={entity=e,position=p,key=key(e)} end
      end
    end
    for i=#candidates,1,-1 do
      local c=candidates[i]
      local dx,dy=c.position.x-node.position.x,c.position.y-node.position.y
      if scan.lookup[c.key] or not c.entity.valid then table.remove(candidates,i)
      elseif dx*dx+dy*dy<=gap*gap then add(scan,c.entity,c.key,c.position);table.remove(candidates,i) end
    end
    cell.x=cell.x+1
    if cell.x>cell.right then cell.x=cell.left;cell.y=cell.y+1 end
    if cell.y>cell.bottom then scan.head=scan.head+1;scan.cell=nil end
    return true
  end
  local groups={}
  for _,g in pairs(scan.groups) do
    if g.area>0 then
      for _,old in ipairs(m.groups) do
        if old.kind==g.kind and old.name==g.name then g.carry=old.carry;g.credit=old.credit;g.depletion_credit=old.depletion_credit;break end
      end
      groups[#groups+1]=g
    end
  end
  table.sort(groups,function(a,b) return a.kind==b.kind and a.name<b.name or a.kind<b.kind end)
  for k in pairs(m.lookup) do
    if not scan.lookup[k] then
      local global_key=scan.surface.."/"..k
      local owners=storage.mining_owners[global_key]
      if owners then owners[scan.owner]=nil;if not next(owners) then storage.mining_owners[global_key]=nil end end
    end
  end
  m.groups,m.lookup,m.scan=groups,scan.lookup,nil;m.revision=m.revision+1;m.bounds=scan.bounds
  storage.mining_buckets[tower.entity.unit_number%6][tower.entity.unit_number]=#groups>0 and true or nil
  return false
end

local function fluid_slot(tower,name,mode)
  if not tower.fluid_ports then tower.fluid_rules=tower.fluid_rules or {};F.ensure(tower) end
  local index=F.index(tower,{name=name})
  if index then return index end
  local rules=table.deepcopy(tower.fluid_rules)
  for i=1,4 do
    if not rules[i] and tower.fluid_ports[i].get_fluid_count()<0.001 then
      rules[i]={name=name,type="fluid",mode=mode,quality="normal",count=0}
      if F.configure(tower.entity.unit_number,rules) then
        if mode=="supply" then tower.mining.auto_fluids[name]=i end
        tower.mining.revision=tower.mining.revision+1;return i
      end
      return
    end
  end
end
local function item_slot(tower,name)
  local index=W.index(tower,{name=name,quality="normal"})
  if index then return index end
  if tower.rules_controlled then return end
  local rules=table.deepcopy(tower.slots)
  for i=1,5 do
    if not rules[i] and not tower.effective_slots[i] and W.inventory(tower,i).is_empty() then
      rules[i]={name=name,quality="normal",mode="supply",count=0}
      if M.configure(tower.entity.unit_number,rules) then
        tower.mining.auto_items[name]=i
        C.update(tower);tower.mining.revision=tower.mining.revision+1;return i
      end
      return
    end
  end
end
local function ocean_meta(name)
  return {products={{name=name,type="fluid",amount=1,ignored=0}}}
end
local function room(tower,p,index)
  if p.type=="fluid" then
    local tank=tower.fluid_ports[index]
    return math.max(0,F.capacity(tank,1)-tank.get_fluid_count())
  end
  return math.max(0,math.min(R.storage_per_bank(tower.entity.force,tower)*W.stack_size(p.name)-W.count(tower,p),
    W.inventory(tower,index).get_insertable_count{name=p.name,quality="normal"}))
end
local function consume(g,cycles,data,budget)
  if g.kind=="ocean" then return cycles,budget-1 end
  local consumed=0
  while consumed<cycles and budget>0 do
    budget=budget-1
    local node=g.nodes[g.cursor]
    if not node then break end
    local e=node.entity
    if not node.live or not e.valid then drop(g,node);g.cursor=g.cursor+1
    elseif data.infinite then
      local take=cycles-consumed
      local loss=take*data.depletion+(g.depletion_credit or 0)
      g.depletion_credit=loss-math.floor(loss)
      e.amount=math.max(data.minimum,e.amount-math.floor(loss))
      consumed=consumed+take
      break
    else
      local take=math.min(cycles-consumed,e.amount)
      consumed=consumed+take
      if take==e.amount then drop(g,node);e.deplete();g.cursor=g.cursor+1 else e.amount=e.amount-take end
    end
  end
  return consumed,budget
end
local function produce(tower,g,budget)
  local data=g.kind=="ocean" and ocean_meta(g.name) or meta(g.name)
  if not data then g.status="unsupported";g.pending=0;return budget-1 end
  if g.area<=0 then g.status="depleted";g.rate=0;g.pending=0;return budget-1 end
  local bonus=math.max(0,tower.entity.force.mining_drill_productivity_bonus)
  local rate=g.kind=="solid" and g.area*10 or g.kind=="spring" and g.n*1000 or g.area*1000
  g.rate=rate*(1+bonus);g.productivity=bonus
  local cycles=g.pending
  local continuous=g.kind=="ocean" or g.kind=="spring" and data.infinite
  local slots,amounts={},{}
  for i,p in ipairs(data.products) do
    local index
    if p.type=="fluid" then index=fluid_slot(tower,p.name,"supply") else index=item_slot(tower,p.name) end
    if not index then g.status="slots";g.pending=0;return budget-1 end
    local rule=p.type=="fluid" and tower.fluid_rules[index] or tower.effective_slots[index]
    if rule.mode~="supply" then g.status="mode";g.pending=0;return budget-1 end
    slots[i]=index
    amounts[i]=p.amount+math.max(0,p.amount-p.ignored)*bonus
    local space=room(tower,p,index)
    local fit=space/amounts[i]
    if p.type=="item" and space>0 then fit=(space+1-(g.carry[i] or 0)-0.000001)/amounts[i] end
    cycles=math.min(cycles,continuous and fit or math.floor(fit))
  end
  if cycles<(continuous and 0.000001 or 1) then g.status="full";g.pending=0;return budget-1 end
  local input
  if data.required and data.fluid>0 then
    input=fluid_slot(tower,data.required,"storage")
    local count=0
    for _,tank in ipairs(tower.fluid_ports or {}) do if tank.valid then count=count+tank.get_fluid_count(data.required) end end
    local fit=count/data.fluid
    cycles=math.min(cycles,continuous and fit or math.floor(fit))
    if cycles<(continuous and 0.000001 or 1) then g.status="fluid";g.required=data.required;g.pending=0;return budget-1 end
  end
  local planned=cycles
  cycles,budget=consume(g,cycles,data,budget)
  g.pending=cycles==planned and 0 or math.max(0,planned-cycles)
  if input and cycles>0 then
    local remaining=cycles*data.fluid
    for _,tank in ipairs(tower.fluid_ports) do
      if remaining<=0 then break end
      if tank.valid and tank.get_fluid_count(data.required)>0 then
        local removed=F.remove_fluid(tank,1,remaining)
        remaining=remaining-(removed and removed.amount or 0)
      end
    end
    assert(remaining<0.001,"Air Logistics Tower: required mining fluid disappeared")
    tower.entity.force.get_fluid_production_statistics(tower.entity.surface).on_flow(data.required,-cycles*data.fluid)
  end
  for i,p in ipairs(data.products) do
    local amount=cycles*amounts[i]+(g.carry[i] or 0)
    if p.type=="item" then g.carry[i]=amount-math.floor(amount);amount=math.floor(amount) end
    if amount>0 then
      local added
      if p.type=="fluid" then
        added=F.add_fluid(tower.fluid_ports[slots[i]],1,{name=p.name,amount=amount,temperature=p.temperature or prototypes.fluid[p.name].default_temperature})
        tower.entity.force.get_fluid_production_statistics(tower.entity.surface).on_flow(p.name,added)
      else
        added=W.inventory(tower,slots[i]).insert{name=p.name,count=amount,quality="normal"}
        tower.entity.force.get_item_production_statistics(tower.entity.surface).on_flow(p.name,added)
      end
      assert(math.abs(added-amount)<0.001,"Air Logistics Tower: mined output did not fit reserved storage")
    end
  end
  g.status=g.area>0 and "running" or "depleted"
  if g.area<=0 and selected(tower.mining,g) and not tower.mining.queued then
    enqueue(tower)
  end
  return budget
end
function M.set_enabled(id, kind, name, enabled)
  local tower=storage.towers[id]
  if not tower or not tower.entity.valid or not M.enabled() or type(enabled)~="boolean" then return false end
  local m=tower.mining
  if not m or not m.groups then return false end
  local target
  for _,g in ipairs(m.groups) do
    if g.kind==kind and g.name==name then target=g;break end
  end
  if not target then return false end
  m.selected=m.selected or {};m.auto_items=m.auto_items or {};m.auto_fluids=m.auto_fluids or {}
  local key=group_key(kind,name)
  if selected(m,target)==enabled then return true end
  m.selected[key]=enabled or nil
  m.revision=m.revision+1
  target.pending=0
  target.credit=0
  target.last_tick=game.tick
  target.status=enabled and "ready" or "off"
  if enabled then
    local data=kind=="ocean" and ocean_meta(name) or meta(name)
    for _,product in ipairs(data and data.products or {}) do
      local index=m.auto_fluids[product.name]
      local old=index and tower.fluid_rules and tower.fluid_rules[index]
      if product.type=="fluid" and old and old.name==product.name and old.mode=="storage" then
        local rules=table.deepcopy(tower.fluid_rules)
        rules[index].mode="supply"
        F.configure(id,rules)
      end
    end
    return true
  end

  local required={}
  for _,g in ipairs(m.groups) do
    if selected(m,g) then
      local data=g.kind=="ocean" and ocean_meta(g.name) or meta(g.name)
      for _,p in ipairs(data and data.products or {}) do required[p.type.."/"..p.name]=true end
    end
  end
  local data=kind=="ocean" and ocean_meta(name) or meta(name)
  local rules=table.deepcopy(tower.slots or {})
  local removed=false
  for _,product in ipairs(data and data.products or {}) do
    if not required[product.type.."/"..product.name] then
      if product.type=="item" then
        local index=m.auto_items[product.name]
        local rule=index and rules[index]
        if rule and rule.name==product.name and rule.quality=="normal" and not tower.rules_controlled then
          rules[index]=nil
          m.auto_items[product.name]=nil
          removed=true
        end
      else
        local index=m.auto_fluids[product.name]
        local rule=index and tower.fluid_rules and tower.fluid_rules[index]
        if rule and rule.name==product.name then
          local fluid_rules=table.deepcopy(tower.fluid_rules)
          if tower.fluid_ports[index].get_fluid_count() > 0.001 then
            fluid_rules[index].mode="storage"
          else
            fluid_rules[index]=nil
            m.auto_fluids[product.name]=nil
          end
          F.configure(id,fluid_rules)
        end
      end
    end
  end
  if removed then
    W.reassign_products(tower,rules)
    tower.slots=rules
    tower.effective_slots=rules
    tower.merged_rules=nil
    tower.storage_conflict=nil
    C.update(tower)
    P.update(tower)
  end
  return true
end

function M.update(tick)
  if not M.enabled() then return end
  local jobs=storage.mining_jobs
  local quota={cells=4,starts=2,seeds=64}
  for _=1,40 do
    local id=jobs.ids[jobs.head]
    if not id then break end
    jobs.head=jobs.head+1
    local t=storage.towers[id]
    local result=t and t.entity.valid and scan_step(t,quota)
    if result then jobs.ids[#jobs.ids+1]=id
    elseif t then
      t.mining.queued=false
      if t.mining.rescan_after then t.mining.rescan_after=false;enqueue(t) end
    end
    if result=="wait" then break end
  end
  if jobs.head>#jobs.ids then jobs.ids={};jobs.head=1 end
  if jobs.head>1024 then
    local pending={};for i=jobs.head,#jobs.ids do pending[#pending+1]=jobs.ids[i] end
    jobs.ids=pending;jobs.head=1
  end
  for id in pairs(storage.mining_buckets[tick%6]) do
    local t=storage.towers[id]
    if not t or not t.entity.valid then storage.mining_buckets[tick%6][id]=nil
    elseif not t.mining.queued then
      local powered=t.enabled and t.power.valid and t.power.energy>0 and not t.entity.to_be_deconstructed()
      for _,g in ipairs(t.mining.groups) do
        if not selected(t.mining,g) then
          g.status="off";g.pending=0;g.last_tick=tick
        elseif powered and not g.work_queued then
          local data=g.kind=="ocean" and ocean_meta(g.name) or meta(g.name)
          if data then
            local rate=g.kind=="solid" and g.area*10 or g.kind=="spring" and g.n*1000 or g.area*1000
            local elapsed=tick-(g.last_tick or tick-6)
            g.last_tick=tick
            g.credit=g.credit+rate/data.products[1].amount*elapsed/60
            g.pending=math.floor(g.credit);g.credit=g.credit-g.pending
            if g.pending>0 then
              local work=storage.mining_work;work.jobs[#work.jobs+1]={id=id,group=g};g.work_queued=true
            else g.status="depleted";g.rate=0 end
          end
        elseif not powered then g.status=t.enabled and "power" or "paused";g.last_tick=tick end
      end
    end
  end
  local work,budget=storage.mining_work,32
  while budget>0 and work.head<=#work.jobs do
    local job=work.jobs[work.head];work.head=work.head+1
    local t,g=storage.towers[job.id],job.group
    if t and t.entity.valid and selected(t.mining,g) and not t.mining.queued and t.enabled and t.power.valid and t.power.energy>0 and not t.entity.to_be_deconstructed() then
      budget=produce(t,g,budget)
      if g.pending>0 then work.jobs[#work.jobs+1]=job else g.work_queued=false end
    else g.work_queued=false;g.pending=0;budget=budget-1 end
  end
  if work.head>#work.jobs then work.jobs={};work.head=1 end
  if work.head>1024 then
    local pending={};for i=work.head,#work.jobs do pending[#pending+1]=work.jobs[i] end
    work.jobs=pending;work.head=1
  end
end
function M.depleted(event)
  local e=event.entity
  if not e or not e.valid then return end
  local k=key(e)
  local global_key=e.surface_index.."/"..k
  local owners=storage.mining_owners and storage.mining_owners[global_key] or {}
  for id in pairs(owners) do
    local t=storage.towers[id]
    if t then
    if t.entity.valid and t.entity.surface_index==e.surface_index and t.mining then
      local node=t.mining.lookup[k]
      if node and node.live then
        drop(node.group,node)
        if node.group.area<=0 and selected(t.mining,node.group) then
          if t.mining.queued then t.mining.rescan_after=true
          else enqueue(t) end
        end
      end
      local scan=t.mining.scan
      node=scan and scan.lookup[k]
      if node then drop(node.group,node) end
    end
    end
  end
  if storage.mining_owners then storage.mining_owners[global_key]=nil end
end
function M.changed(surface,area)
  if not M.enabled() then return end
  local gap=math.max(option("solid-gap",5),option("spring-gap",30))
  for _,t in pairs(storage.towers) do
    if t.entity.valid and t.entity.surface_index==surface.index then
      local m=t.mining
      local b=m and (m.scan and m.scan.bounds or m.bounds) or t.entity.bounding_box
      if b and area.left_top.x<=b.right_bottom.x+gap and area.right_bottom.x>=b.left_top.x-gap
        and area.left_top.y<=b.right_bottom.y+gap and area.right_bottom.y>=b.left_top.y-gap then
        if m.queued then m.rescan_after=true else enqueue(t) end
      end
    end
  end
end
function M.inspect(tower)
  local m=tower.mining
  local groups={}
  for _,g in ipairs(m and m.groups or {}) do
    local data=g.kind=="ocean" and ocean_meta(g.name) or meta(g.name)
    groups[#groups+1]={name=g.name,kind=g.kind,area=g.area,n=g.n,enabled=selected(m,g),rate=g.rate or 0,status=g.status or "ready",
      required=g.required,product=data and data.products[1],productivity=g.productivity or 0}
  end
  return {enabled=M.enabled(),scanning=m and m.queued or false,groups=groups,revision=m and m.revision or 0,
    solid_gap=option("solid-gap",5),spring_gap=option("spring-gap",30)}
end
return M
