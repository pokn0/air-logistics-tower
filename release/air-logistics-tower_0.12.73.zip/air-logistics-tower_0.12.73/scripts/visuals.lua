local V = {}
local T = require("scripts.tier")
local min, max, abs, sin, cos, atan2, sqrt, pi = math.min, math.max, math.abs, math.sin, math.cos, math.atan2, math.sqrt, math.pi
local render_stride=1
function V.set_fleet_size(count)
  local option=settings.global["air-logistics-flight-render-mode"]
  local mode=option and option.value or "adaptive"
  if mode=="full" then render_stride=1
  elseif mode=="performance" then
    render_stride=count>=1500 and 5 or count>=500 and 4 or count>=80 and 3 or 2
  else
    render_stride=count>=1500 and 4 or count>=500 and 3 or count>=80 and 2 or 1
  end
end

local function destroy(object)
  if object and object.valid then object.destroy() end
end

local function set_position(flight, x, y)
  local position = flight.position
  if position then position.x, position.y = x, y
  else flight.position = {x = x, y = y} end
end

function V.remove_tower(tower)
  if tower.visual then destroy(tower.visual.object); destroy(tower.visual.platform); tower.visual = nil end
end

function V.tower(tower, tick)
  if not tower.entity.valid or not tower.power.valid then return end
  local energy = tower.power.energy
  local previous = tower.last_energy or energy
  local charging = energy > previous + 100
  local state = "idle"
  if energy < 1000000 and not charging then state = "unpowered"
  elseif tick < (tower.launch_until or 0) then state = "launching"
  elseif charging and energy < T.get(tower).energy * 0.998 then state = "charging"
  end
  tower.last_energy = energy
  if not tower.visual or not tower.visual.object.valid then
    tower.visual = {object = rendering.draw_animation{
      animation = T.get(tower).prefix .. "-" .. state, target = tower.entity,
      surface = tower.entity.surface, render_layer = "object",
      animation_speed = state == "launching" and 0.6 or 0.2
    }}
  end
  if not tower.visual.platform or not tower.visual.platform.valid then
    tower.visual.platform = rendering.draw_sprite{sprite=T.get(tower).prefix .. "-platform",target=tower.entity,
      surface=tower.entity.surface,render_layer="floor"}
  end
  if tower.visual.state ~= state then
    tower.visual.object.animation = T.get(tower).prefix .. "-" .. state
    tower.visual.object.animation_speed = state == "launching" and 0.6 or 0.2
    tower.visual.object.animation_offset = -tick * tower.visual.object.animation_speed
    tower.visual.state = state
  end
end

function V.remove_flight(flight)
  destroy(flight.body); destroy(flight.shadow); destroy(flight.wash)
end

function V.create_flight(flight)
  if flight.body and flight.body.valid then
    flight.heading = flight.body.orientation
    flight.altitude = flight.altitude or 1.4
  end
  V.remove_flight(flight)
  flight.visual_altitude, flight.visual_heading, flight.visual_scale, flight.visual_wash = nil, nil, nil, nil
  flight.stationary_draw, flight.visual_phase = nil, nil
  flight.body_target, flight.shadow_target, flight.visual_wash_x, flight.visual_wash_y = nil, nil, nil, nil
  if flight.transit_until then return end
  local surface = game.surfaces[flight.surface]
  if not surface then return end
  flight.heading = flight.heading or 0
  flight.altitude = flight.altitude or 0.15
  flight.body = rendering.draw_animation{
    animation = T.get(flight).plane .. "-animated", target = flight.position, surface = surface,
    render_layer = "air-object", animation_speed = 0.8
  }
  flight.shadow = rendering.draw_sprite{
    sprite = T.get(flight).plane .. "-shadow", target = flight.position, surface = surface, render_layer = "object"
  }
  flight.wash = rendering.draw_animation{
    animation = "air-cargo-downwash", target = flight.position, surface = surface,
    render_layer = "object", animation_speed = 0.6
  }
  flight.visual_version = 2
end

local function draw_due(flight, tick)
  if render_stride==1 or
     (tick+(flight.home or 0)+(flight.receiver or 0))%render_stride==0 then return true end
  if flight.visual_phase~=flight.phase or flight.visual_force then return true end
  local route=flight.route
  if not route or not route.progress or route.progress>=1 then return true end
  local altitude=flight.altitude or 0.15
  if flight.visual_wash~=((altitude<1.2 and not flight.unload_tick) or false) then return true end
  local body, shadow, wash=flight.body,flight.shadow,flight.wash
  return not (body and body.valid and shadow and shadow.valid and wash and wash.valid)
end

function V.draw(flight, tick, bank)
  if flight.transit_until then return end
  if not flight.body or not flight.body.valid then
    V.create_flight(flight)
    if not flight.body or not flight.body.valid then return end
  end
  local altitude = flight.altitude or 0.15
  local bob = altitude > 1.5 and sin(tick * 0.055 + flight.home) * 0.025 or 0
  local body_target, shadow_target = flight.body_target, flight.shadow_target
  if not body_target then
    body_target, shadow_target = {}, {}
    flight.body_target, flight.shadow_target = body_target, shadow_target
  end
  local x, y = flight.position.x, flight.position.y
  local body_y, shadow_x, shadow_y = y - altitude + bob, x + altitude * 0.45, y + altitude * 0.25
  if body_target.x ~= x or body_target.y ~= body_y then
    body_target.x, body_target.y = x, body_y
    flight.body.target = body_target
  end
  if shadow_target.x ~= shadow_x or shadow_target.y ~= shadow_y then
    shadow_target.x, shadow_target.y = shadow_x, shadow_y
    flight.shadow.target = shadow_target
  end
  if flight.visual_heading ~= flight.heading then
    flight.body.orientation, flight.shadow.orientation = flight.heading, flight.heading
    flight.visual_heading = flight.heading
  end
  local scale = 1 + altitude * 0.025 - min(abs(bank or 0) * 5, 0.12)
  if flight.visual_scale ~= scale then flight.body.x_scale, flight.visual_scale = scale, scale end
  if flight.visual_altitude ~= altitude then
    flight.body.y_scale = 1 + altitude * 0.025
    flight.shadow.x_scale, flight.shadow.y_scale = 1 - altitude * 0.08, 1 - altitude * 0.08
    local shadow_color = flight.shadow_color
    if not shadow_color then shadow_color = {}; flight.shadow_color = shadow_color end
    shadow_color.r, shadow_color.g, shadow_color.b = 1, 1, 1
    shadow_color.a = 1 - altitude * 0.16
    flight.shadow.color = shadow_color
    local wash_color = flight.wash_color
    if not wash_color then wash_color = {}; flight.wash_color = wash_color end
    wash_color.r, wash_color.g, wash_color.b = 1, 1, 1
    wash_color.a = max(0, 1 - altitude / 1.2)
    flight.wash.color = wash_color
    flight.visual_altitude = altitude
  end
  local visible = altitude < 1.2 and not flight.unload_tick or false
  if flight.visual_wash ~= visible then flight.wash.visible, flight.visual_wash = visible, visible end
  if visible and (flight.visual_wash_x ~= x or flight.visual_wash_y ~= y) then
    flight.wash.target = flight.position
    flight.visual_wash_x, flight.visual_wash_y = x, y
  end
  flight.stationary_draw = bank == nil and flight.route ~= nil
    and flight.route.progress ~= nil and flight.route.progress >= 1
  flight.visual_phase=flight.phase
  flight.visual_tick=tick
  flight.visual_force=nil
end

local function smooth(value)
  if value <= 0 then return 0 elseif value >= 1 then return 1 end
  return value * value * (3 - 2 * value)
end

local INV_TWO_PI = 1 / (2 * pi)

V.steps = 1

function V.move(flight, destination, tick, speed)
  local route = flight.route
  if not route then
    route = {from = {}, to = {}}
    flight.route = route
    route.span = -1
  end
  if route.span < 0 or route.to.x ~= destination.x or route.to.y ~= destination.y
    or route.phase ~= flight.phase then
    route.from.x, route.from.y = flight.position.x, flight.position.y
    route.to.x, route.to.y = destination.x, destination.y
    local dx, dy = destination.x - route.from.x, destination.y - route.from.y
    route.span = sqrt(dx*dx + dy*dy)
    route.progress, route.age, route.phase = 0, 0, flight.phase
    route.start_altitude = flight.altitude or 0.15
    route.dx, route.dy, route.bend = nil, nil, nil
    route.heading_progress, route.heading_value = nil, nil
    flight.visual_force=true
  end
  if route.span < 0.001 or route.progress >= 1 then
    if flight.stationary_draw and flight.position.x == destination.x
      and flight.position.y == destination.y and flight.altitude == 0.15
      and flight.visual_heading == flight.heading
      and flight.body and flight.body.valid and flight.shadow and flight.shadow.valid
      and flight.wash and flight.wash.valid then
      return true
    end
    set_position(flight, destination.x, destination.y)
    flight.altitude = 0.15
    if draw_due(flight,tick) then V.draw(flight, tick) end
    return true
  end
  if not route.bend then
    route.dx, route.dy = route.to.x - route.from.x, route.to.y - route.from.y
    route.bend = min(8, route.span * 0.1)
  end
  local dx, dy, bend = route.dx, route.dy, route.bend
  local bend_over_span = route.bend_over_span
  if not bend_over_span then
    bend_over_span = bend / route.span
    route.bend_over_span = bend_over_span
  end
  local u = route.progress
  local desired_heading = route.heading_value
  if route.heading_progress ~= u or desired_heading == nil then
    local tangent = pi * cos(pi * u) * bend_over_span
    desired_heading = (atan2(dx - dy*tangent, -(dy + dx*tangent)) * INV_TWO_PI) % 1
    route.heading_progress, route.heading_value = u, desired_heading
  end
  local steps = V.steps or 1
  local delta = (desired_heading - flight.heading + 0.5) % 1 - 0.5
  local turn, turn_limit = delta, 0.012 * steps
  if turn < -turn_limit then turn = -turn_limit elseif turn > turn_limit then turn = turn_limit end
  flight.heading = (flight.heading + turn) % 1
  if tick >= (flight.turn_until or 0) then
    for _ = 1, steps do
      route.age = route.age + 1
      local remaining = route.span * (1-u)
      local velocity = min(speed, 0.05 + route.age * 0.015, 0.06 + remaining * 0.08)
      route.progress = min(1, u + velocity / route.span)
      u = route.progress
      if u >= 1 then break end
    end
    local offset = sin(pi * u) * bend_over_span
    set_position(flight, route.from.x + dx*u - dy*offset, route.from.y + dy*u + dx*offset)
    local start_altitude = route.start_altitude or 0.15
    local climb = start_altitude + (2 - start_altitude) * smooth(route.age / 30)
    local descent = 0.15 + 1.85 * smooth(route.span * (1-u) / 6)
    flight.altitude = min(climb, descent)
  end
  if draw_due(flight,tick) then V.draw(flight, tick, delta) end
  return route.progress >= 1
end

return V
