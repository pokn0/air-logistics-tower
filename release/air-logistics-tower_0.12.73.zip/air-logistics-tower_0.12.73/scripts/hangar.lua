local H = {}
local W = require("scripts.warehouse")
local T = require("scripts.tier")
H.plane_name = "air-cargo-plane"

function H.ensure(tower)
  if not tower.hangar or not tower.hangar.valid then
    tower.hangar = game.create_inventory(T.get(tower).fleet, {"air-logistics.hangar"})
  end
  if not tower.hangar_requester or not tower.hangar_requester.valid then
    local requester=tower.entity.surface.create_entity{name="air-logistics-hangar-requester",position=tower.entity.position,force=tower.entity.force}
    assert(requester,"Air Logistics Tower: could not create hangar requester")
    requester.destructible,requester.operable,requester.rotatable=false,false,false
    local inv=requester.get_inventory(defines.inventory.chest)
    inv.set_filter(1,{name=T.planet.plane,quality="normal"})
    inv.set_filter(2,{name=tower.interstellar and T.space.plane or T.planet.plane,quality="normal"})
    tower.hangar_requester=requester
    tower.hangar_request_signature=nil
  end
  if tower.hangar_requester.force~=tower.entity.force then
    tower.hangar_requester.force=tower.entity.force
    tower.hangar_request_signature=nil
  end
  tower.hangar_surface = tower.entity.surface.index
  tower.hangar_position = tower.entity.position
  tower.hangar_force = tower.entity.force.index
end

local function store(inv, stack)
  W.transfer_from_stack(inv, stack)
  if stack.valid_for_read then
    inv.resize(#inv + math.ceil(stack.count / stack.prototype.stack_size))
    W.transfer_from_stack(inv, stack)
    assert(not stack.valid_for_read, "Air Logistics Tower: aircraft storage transfer failed")
  end
end

local AIRCRAFT = {[T.planet.plane]=true, [T.space.plane]=true}

function H.import(tower, scan)
  H.ensure(tower)
  local incoming=tower.hangar_requester.get_inventory(defines.inventory.chest)
  local received=not incoming.is_empty()
  for i=1,#incoming do if incoming[i].valid_for_read then store(tower.hangar,incoming[i]) end end
  if received then H.request(tower) end
  if scan == false then return end
  for _, cargo in ipairs(W.inventories(tower, true, AIRCRAFT)) do
    if not cargo.is_empty() and (cargo.get_item_count_filtered{name = T.planet.plane} > 0
      or tower.interstellar and cargo.get_item_count_filtered{name = T.space.plane} > 0) then
      for i = 1, #cargo do
        local stack = cargo[i]
        if stack.valid_for_read and T.accepts(tower, stack.name) then store(tower.hangar, stack) end
      end
    end
  end
end

function H.request(tower)
  H.ensure(tower)
  local options=tower.options or {}
  local owned={}
  if (options.plane_request or 0)>0 or (options.ship_request or 0)>0 then
    for _,flight in ipairs(H.flights_by_home(tower.entity.unit_number)) do
      if flight.plane.valid then
        for i=1,#flight.plane do
          local stack=flight.plane[i]
          if stack.valid_for_read then owned[stack.name]=(owned[stack.name] or 0)+stack.count end
        end
      end
    end
  end
  local filters={}
  local platform=tower.entity.surface.platform
  local hub=platform and platform.hub
  local platform_inventory=hub and hub.valid and hub.force==tower.entity.force and hub.get_inventory(defines.inventory.hub_main)
  for i,name in ipairs({T.planet.plane,T.space.plane}) do
    local goal=options[i==1 and "plane_request" or "ship_request"] or 0
    local missing=math.max(0,goal-tower.hangar.get_item_count_filtered{name=name}-(owned[name] or 0))
    if missing>0 and T.accepts(tower,name) and tower.enabled~=false and platform_inventory then
      missing=math.max(0,missing-tower.hangar_requester.get_item_count{name=name,quality="normal"})
      missing=missing-W.move(platform_inventory,tower.hangar,{name=name,quality="normal"},missing)
    end
    if missing>0 and T.accepts(tower,name) then
      filters[#filters+1]={value={type="item",name=name,quality="normal",comparator="="},min=missing,max=missing}
    end
  end
  local enabled=tower.enabled~=false and #filters>0
  local parts={}
  for _,filter in ipairs(filters) do parts[#parts+1]=filter.value.name.."/"..filter.min end
  parts[#parts+1]=enabled and "1" or "0"
  local signature=table.concat(parts,",")
  if tower.hangar_request_signature==signature then return end
  local sections=tower.hangar_requester.get_logistic_sections()
  local section=sections.get_section(1) or sections.add_section()
  section.filters,section.active=filters,enabled
  tower.hangar_requester.request_from_buffers=true
  tower.hangar_request_signature=signature
end

function H.copy(source, target)
  H.import(source);H.import(target)
  local copy = game.create_inventory(1)
  for i = 1, #source.hangar do
    if source.hangar[i].valid_for_read then
      copy[1].set_stack(source.hangar[i])
      store(target.hangar, copy[1])
    end
  end
  copy.destroy()
end

function H.remove(tower, buffer, discard)
  local inv = tower.hangar
  if discard then
    if tower.hangar_requester and tower.hangar_requester.valid then tower.hangar_requester.destroy() end
    tower.hangar_requester = nil
    if inv and inv.valid then inv.destroy() end
    tower.hangar = nil
    return
  end
  if not inv or not inv.valid then return end
  local requester=tower.hangar_requester
  if requester and requester.valid then
    local incoming=requester.get_inventory(defines.inventory.chest)
    for i=1,#incoming do if incoming[i].valid_for_read then store(inv,incoming[i]) end end
    requester.destroy()
  end
  tower.hangar_requester=nil
  local surface = game.surfaces[tower.hangar_surface]
  for i = 1, #inv do
    local stack = inv[i]
    if stack.valid_for_read then
      if buffer and buffer.valid then W.transfer_from_stack(buffer, stack) end
      if stack.valid_for_read and surface then
        local drops = surface.spill_item_stack{
          position = tower.hangar_position, stack = stack, enable_looted = true,
          force = game.forces[tower.hangar_force], allow_belts = false, use_start_position_on_failure = true
        }
        assert(#drops > 0, "Air Logistics Tower: could not recover parked aircraft")
        stack.clear()
      end
    end
  end
  inv.destroy()
  tower.hangar = nil
end

return H
