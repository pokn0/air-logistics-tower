local N = require("scripts.network")
local W = require("scripts.warehouse")
local T = require("scripts.tier")
local B = require("scripts.robots")
local P = require("scripts.ports")
local M = require("scripts.mining")
local Bonuses = require("scripts.bonuses")
local util = require("util")
local deepcopy = util.table.deepcopy
local has_empty_slot_reader = script.active_mods.base:match('^2%.1%.') ~= nil
local has_gui_inventory = defines.events.on_gui_inventory_action ~= nil
local gui_inventory_options = {handle_cursor_transfer = true, handle_cursor_split = true, empty_slot_info = true}
local gui_inventory_reported = false
local function gui_inventory(parent, params)
  local ok, element = pcall(parent.add, parent, params)
  if ok then return element end
  local minimal = {}
  for key, value in pairs(params) do
    if not gui_inventory_options[key] then minimal[key] = value end
  end
  local ok2, element2 = pcall(parent.add, parent, minimal)
  if ok2 then return element2 end
  if not gui_inventory_reported then
    gui_inventory_reported = true
    log("Air Logistics Tower: script driven inventory grid is unavailable on this game version (" .. tostring(element2) .. "); falling back to clickable item slots")
  end
  return nil
end
local gui_name = "air_logistics_config"
local legacy_warehouse_gui_name = "air_logistics_warehouse"
local modes = {"storage", "supply", "request"}
local mode_index = {storage = 1, supply = 2, request = 3}
local robot_modes = {"off", "requester", "passive-provider", "buffer"}
local sides = {"north", "east", "south", "west"}

local function port_control(frame, i)
  return frame.ports[sides[math.ceil(i / (frame.tags.ports_per_side or 2))]]["dock_" .. i]
end

local function has_external_wire(entity)
  for _, color in ipairs({"red", "green"}) do
    local connector = entity.get_wire_connector(defines.wire_connector_id["circuit_" .. color], false)
    for _, wire in ipairs(connector and connector.real_connections or {}) do
      local name = wire.target.owner.name
      if name ~= "air-logistics-storage-bin" and name ~= "air-logistics-output" and not name:match("^air%-logistics%-robot%-") then return true end
    end
  end
  return false
end

local function close(player)
  for _, parent in ipairs({player.gui.screen, player.gui.relative}) do
    for _, name in ipairs({gui_name, legacy_warehouse_gui_name}) do
      local frame = parent[name]
      if frame then
        if player.opened == frame then player.opened = nil end
        if frame.valid then frame.destroy() end
      end
    end
  end
end

local function refresh_recovery(root,tower)
  local recovery=root.viewport.content.warehouse.bank_scroll.recovery
  if not recovery then return end
  local totals, keys, page_counts={}, {}, {}
  local pages=tower.legacy_warehouse or {}
  for i,inv in ipairs(pages) do
    if inv.valid then
      page_counts[i]=inv.get_item_count()
      for _,item in ipairs(inv.get_contents()) do
        local k=item.name.."/"..(item.quality or "normal")
        if not totals[k] then
          totals[k]={name=item.name,quality=item.quality or "normal",count=0}
          keys[#keys+1]=k
        end
        totals[k].count=totals[k].count+item.count
      end
    end
  end
  table.sort(keys)
  local signature={#pages}
  for i=1,#pages do signature[#signature+1]=page_counts[i] or 0 end
  for _,k in ipairs(keys) do signature[#signature+1]=k..":"..totals[k].count end
  local code=table.concat(signature,"|")
  if recovery.tags.signature==code then return end
  recovery.clear()
  recovery.visible=#keys>0
  recovery.tags={signature=code}
  if #keys==0 then return end
  recovery.add{type="label",caption={"air-logistics.recovery-title"},style="heading_2_label"}
  local rows=recovery.add{type="table",name="recovery_items",column_count=3}
  for _,k in ipairs(keys) do
    local item=totals[k]
    local icon=rows.add{type="sprite",sprite="item/"..item.name}
    icon.style.size=28
    rows.add{type="label",caption={"",{"item-name."..item.name},
      item.quality~="normal" and {"", " (",{"quality-name."..item.quality},")"} or ""}}
    rows.add{type="label",caption=util.format_number(item.count,true)}
  end
  local transfers=recovery.add{type="flow",name="pages",direction="vertical"}
  for i,inv in ipairs(pages) do
    if inv.valid and (page_counts[i] or 0)>0 then
      transfers.add{type="button",name="legacy_take_"..i,
        caption={"air-logistics.legacy-take",util.format_number(page_counts[i],true)}}
    end
  end
end

local function refresh(player)
  local root = player.gui.screen[gui_name]
  if not root then return end
  local frame = root.viewport.content.settings
  local banks = root.viewport.content.warehouse.bank_scroll.banks
  local info = N.inspect(root.tags.tower)
  if not info then close(player); return end
  local entity = storage.towers[root.tags.tower].entity
  local fallback_row = frame.hangar_fallback or (frame.aircraft and frame.aircraft.hangar_fallback)
  if fallback_row then
    local hangar_inventory = storage.towers[root.tags.tower].hangar
    for _, child in ipairs(fallback_row.children) do
      local item_name = child.name:match("^hangar_count_(.+)$")
      if item_name then child.caption = tostring(hangar_inventory.get_item_count_filtered{name = item_name}) end
    end
  end
  refresh_recovery(root,storage.towers[root.tags.tower])
  local mining=info.mining
  local panel=frame.mining
  panel.visible=mining.enabled
  panel.mining_state.caption={"air-logistics.mining-"..(not mining.enabled and "off" or mining.scanning and "scan" or #mining.groups==0 and "none" or "on")}
  if #panel.rows.children~=#mining.groups*4 then
    panel.rows.clear()
    for i=1,#mining.groups do
      panel.rows.add{type="checkbox",name="mining_enabled_"..i,state=false,caption="",tooltip={"air-logistics.mining-toggle-help"}}
      panel.rows.add{type="label",name="resource_"..i}
      panel.rows.add{type="label",name="rate_"..i}
      panel.rows.add{type="label",name="state_"..i}
    end
  end
  for i,g in ipairs(mining.groups) do
    local toggle=panel.rows["mining_enabled_"..i]
    toggle.state=g.enabled
    toggle.tags={kind=g.kind,resource=g.name}
    local product=g.product
    panel.rows["resource_"..i].caption={"", "["..product.type.."="..product.name.."] ",prototypes[product.type][product.name].localised_name}
    panel.rows["rate_"..i].caption={"air-logistics.mining-rate-"..g.kind,util.format_number(g.kind=="spring" and g.n or g.area,true),util.format_number(g.rate,true)}
    panel.rows["state_"..i].caption=g.status=="fluid" and {"air-logistics.mining-fluid",{"fluid-name."..g.required}} or {"air-logistics.mining-status-"..(mining.enabled and g.status or "off")}
  end
  if entity.force ~= player.force then close(player); return end
  local nearby=player.controller_type~=defines.controllers.remote and player.can_reach_entity(entity)
  root.viewport.content.backpack.visible=nearby
  if frame.aircraft.hangar then frame.aircraft.hangar.enabled=nearby end
  if frame.robots then frame.robots.enabled=nearby end
  if frame.robot_material then frame.robot_material.enabled=nearby end
  local cb = storage.towers[root.tags.tower].entity.get_or_create_control_behavior()
  local circuit = root.viewport.content.circuit
  local tags = root.tags
  local connected = has_external_wire(entity)
  if circuit.visible ~= connected then
    circuit.visible = connected
    tags.center_after = game.tick + 2
  end
  local networks = W.supports_output_networks(cb) and cb.output_networks or nil
  if not networks then networks = {red = true, green = true} end
  circuit.networks.circuit_red.state, circuit.networks.circuit_green.state = networks.red, networks.green
  circuit.body.contents.circuit_contents.state = cb.read_contents
  if has_empty_slot_reader then
    circuit.body.empty.circuit_empty.state = cb.read_empty_slots
    circuit.body.empty.empty_signal.circuit_empty_signal.elem_value = cb.empty_slots_signal
    circuit.body.empty.empty_signal.circuit_empty_signal.enabled = cb.read_empty_slots
  end
  frame.energy.caption = {"air-logistics.energy", string.format("%.1f", info.energy / 1000000), info.max_energy/1000000, info.power_input}
  frame.status.caption = {"air-logistics.state-" .. info.visual_state}
  frame.planes.caption = {"air-logistics."..(info.interstellar and "ships" or "planes"), info.planes, info.active, info.max_planes}
  for i = 1, N.slots do
    local grid, slot = frame.slots, info.slots[i]
    if info.rules_controlled or tags.rules_controlled or tags.mining_revision~=mining.revision then
      grid["item_" .. i].elem_value = slot and {name = slot.name, quality = slot.quality} or nil
      grid["mode_" .. i].selected_index = slot and mode_index[slot.mode] or 1
      grid["count_" .. i].text = tostring(slot and slot.count or 0)
    end
    for _, key in ipairs({"item_", "mode_"}) do grid[key .. i].enabled = not info.rules_controlled end
    local supply = grid["mode_" .. i].selected_index == mode_index.supply
    grid["count_" .. i].enabled = not info.rules_controlled and not supply
    if supply then grid["count_" .. i].text = "0" end
  end
  for i = 1, (frame.tags.ports_per_side or 2)*4 do
    local button = port_control(frame, i).header["port_" .. i]
    if info.filters_controlled or tags.filters_controlled or info.port_auto[i]
      or tags.port_auto and tags.port_auto[i] then button.elem_value = info.port_filters[i] end
    button.enabled = not info.filters_controlled and not info.port_auto[i]
  end
  tags.rules_controlled, tags.filters_controlled = info.rules_controlled, info.filters_controlled
  tags.port_auto = info.port_auto
  root.tags = tags
  for i = 1, N.slots do
    frame.slots["stock_" .. i].caption = {"air-logistics.stock", info.counts[i] or 0, info.incoming[i] or 0}
    frame.slots["stock_" .. i].tooltip = {"air-logistics.stock-detail", info.incoming_cargo[i] or 0,
      info.incoming_pickups[i] or 0, info.available_counts[i] or 0, info.reserved_counts[i] or 0}
    local slot = info.slots[i]
    local section = banks["bank_section_" .. i]
    local robot_mode = info.options["robot_mode_" .. i]
    section["robot_mode_" .. i].selected_index = W.robot_modes[robot_mode]
    section["robot_target_"..i].visible = robot_mode=="requester" or robot_mode=="buffer"
    local header = section["bank_header_" .. i]
    local icon = header["bank_icon_" .. i]
    header["bank_title_" .. i].caption = slot
      and {"air-logistics.bank-title", i} or {"air-logistics.bank-empty", i}
    icon.visible = slot ~= nil
    header["bank_stock_" .. i].visible = slot ~= nil
    header["bank_stock_" .. i].caption = (info.reserved_counts[i] or 0) > 0
      and {"air-logistics.bank-stock-reserved", info.counts[i] or 0, info.reserved_counts[i]}
      or {"air-logistics.bank-stock", info.counts[i] or 0}
    header["bank_stock_" .. i].tooltip = {"", {"air-logistics.bank-buffered", info.buffered_counts[i] or 0}, "\n",
      frame.slots["stock_" .. i].tooltip}
    local capacity=(info.bank_sizes[i] or 0)*(slot and W.stack_size(slot.name) or 0)
    local products = {"", {"air-logistics.byproducts"}}
    for _, item in ipairs(info.byproducts[i] or {}) do
      products[#products+1] = " [item="..item.name.."] "..item.count
      if item.quality ~= "normal" then products[#products+1] = {"", " (", {"quality-name."..item.quality}, ")"} end
    end
    section["bank_products_"..i].caption = products
    section["bank_products_"..i].visible = info.byproducts[i] ~= nil
    section["bank_capacity_"..i].value=capacity>0 and math.min(1,(info.counts[i] or 0)/capacity) or 0
    header["bank_stock_"..i].caption={"air-logistics.numeric-stock",info.counts[i] or 0,capacity}
    icon.enabled=slot~=nil and nearby
    if slot then
      icon.sprite = "item/" .. slot.name
      icon.tooltip = {"", {"item-name." .. slot.name}, " / ", {"quality-name." .. (slot.quality or "normal")}, "\n", {"air-logistics.numeric-help"}}
    end
  end
  if info.interstellar then
    frame.airplanes.caption={"air-logistics.star-airplanes",info.aircraft_counts[T.planet.plane],info.aircraft_counts[T.space.plane],info.airplane_cargo,string.format("%.1f",info.airplane_speed)}
  end
  if info.interstellar then
    tags.fluid_names=tags.fluid_names or {}
    for i=1,4 do
      local rule=info.fluid_rules and info.fluid_rules[i]
      if tags.fluid_names[i] ~= (rule and rule.name or "") then
        frame.fluids["fluid_item_"..i].elem_value=rule and rule.name
        frame.fluids["fluid_mode_"..i].selected_index=rule and mode_index[rule.mode] or 1
        frame.fluids["fluid_count_"..i].text=tostring(rule and rule.count or 10000)
        tags.fluid_names[i]=rule and rule.name or ""
      end
      local supply = frame.fluids["fluid_mode_"..i].selected_index == mode_index.supply
      frame.fluids["fluid_count_"..i].enabled = not supply
      if supply then frame.fluids["fluid_count_"..i].text = "0" end
      frame.fluids["fluid_stock_"..i].caption={"air-logistics.stock",util.format_number(math.floor(info.counts[5+i] or 0),true),util.format_number(math.floor(info.incoming[5+i] or 0),true)}
      local rule=info.fluid_rules and info.fluid_rules[i]
      local tank=root.viewport.content.warehouse.bank_scroll["fluid_tank_"..i]
      tank.caption={"air-logistics.fluid-stock",{"air-logistics.port-"..sides[i],""},rule and {"fluid-name."..rule.name} or {"air-logistics.unconfigured"},util.format_number(math.floor(info.counts[5+i] or 0),true),util.format_number(info.fluid_capacity,true)}
    end
  end
  if info.storage_conflict then
    frame.message.caption, tags.storage_blocked_message = {"air-logistics.storage-conflict"}, true
  elseif info.rules_blocked then
    frame.message.caption, tags.storage_blocked_message = {"air-logistics.circuit-storage-blocked"}, true
  elseif tags.storage_blocked_message then
    frame.message.caption, tags.storage_blocked_message = "", nil
  end
  tags.mining_revision=mining.revision
  root.tags = tags
  for i=1,info.port_count do
    local mode = info.port_modes[i] or "disconnected"
    local caption = {"air-logistics.belt-"..mode}
    local label = port_control(frame, i)["port_status_" .. i]
    label.caption = info.port_auto[i] and {"air-logistics.belt-auto-input", #(info.port_input_filters[i] or {})}
      or (mode=="input" or mode=="output") and not info.port_filters[i]
        and {"air-logistics.belt-unconfigured", caption} or caption
    label.tooltip = {"air-logistics.belt-speed", string.format("%.0f",info.port_speeds[i] or 0)}
  end
end

local function open(player, entity)
  close(player)
  local tower = N.register(entity)
  if not tower then return end
  player.opened = nil
  local root = player.gui.screen.add{
    type = "frame", name = gui_name, direction = "vertical",
    tags = {tower = entity.unit_number, center_after = game.tick + 2}
  }
  local titlebar = root.add{type = "flow", name = "titlebar", direction = "horizontal"}
  titlebar.add{type = "label", caption = {"entity-name."..entity.name}, style = "frame_title"}
  local drag = titlebar.add{type = "empty-widget", style = "draggable_space_header"}
  drag.style.horizontally_stretchable = true
  drag.style.height = 24
  drag.drag_target = root
  titlebar.add{type = "sprite-button", name = "air_logistics_close", sprite = "utility/close",
    style = "frame_action_button", tooltip = {"gui.close-instruction"}}
  local height = math.max(200, math.min(760, player.display_resolution.height / player.display_scale - 160))
  local viewport = root.add{type = "scroll-pane", name = "viewport", vertical_scroll_policy = "never"}
  viewport.style.maximal_width = math.max(400, player.display_resolution.width / player.display_scale - 48)
  local columns = viewport.add{type = "flow", name = "content", direction = "horizontal"}
  columns.style.horizontal_spacing = 12
  local backpack = columns.add{type = "flow", name = "backpack", direction = "vertical"}
  backpack.add{type = "label", caption = {"air-logistics.player-inventory"}, style = "heading_2_label"}
  local bag_scroll = backpack.add{type = "scroll-pane", name = "bag_scroll", horizontal_scroll_policy = "never"}
  bag_scroll.style.maximal_height = height
  local bag = gui_inventory(bag_scroll, {type = "inventory", name = "player_inventory", slots_per_row = 10})
  if not bag then bag_scroll.add{type = "label", caption = {"air-logistics.no-inventory-grid"}, tooltip = {"air-logistics.no-inventory-grid-help"}} end
  if bag then bag.inventory = player.get_main_inventory() end
  local warehouse = columns.add{type = "flow", name = "warehouse", direction = "vertical"}
  warehouse.add{type = "label", caption = {"air-logistics.warehouse-banks"}, style = "heading_2_label"}
  local warehouse_content = warehouse.add{type = "scroll-pane", name = "bank_scroll", horizontal_scroll_policy = "never"}
  warehouse_content.style.maximal_height = height
  local banks = warehouse_content.add{type = "flow", name = "banks", direction = "vertical"}
  banks.style.vertical_spacing = 8
  for i = 1, N.slots do
    local section = banks.add{type = "flow", name = "bank_section_" .. i, direction = "vertical"}
    local header = section.add{type = "flow", name = "bank_header_" .. i, direction = "horizontal"}
    header.style.vertical_align = "center"
    header.style.horizontal_spacing = 6
    header.add{type = "label", name = "bank_title_" .. i, caption = {"air-logistics.bank-empty", i}}
    local icon = header.add{type = "sprite-button", name = "bank_icon_" .. i, sprite = "item/steel-chest", visible = false}
    icon.style.size = 40
    header.add{type = "label", name = "bank_stock_" .. i, caption = "", visible = false}
    local capacity=section.add{type="progressbar",name="bank_capacity_"..i,value=0}
    capacity.style.width=300
    section.add{type="label",name="bank_products_"..i,visible=false,tooltip={"air-logistics.byproducts-help"}}
    local robot_mode = section.add{type="drop-down", name="robot_mode_"..i,
      items={{"air-logistics.robot-off"},{"air-logistics.robot-requester"},
        {"air-logistics.robot-provider"},{"air-logistics.robot-buffer"}},
      selected_index=W.robot_modes[tower.options["robot_mode_"..i]],
      tooltip={"air-logistics.robot-mode-help"}}
    robot_mode.style.width=320
    local request=section.add{type="flow",name="robot_target_"..i,direction="horizontal"}
    request.style.vertical_align="center"
    request.add{type="label",caption={"air-logistics.robot-request-amount"}}
    local amount=request.add{type="textfield",name="robot_request_"..i,
      text=tostring(tower.options["robot_request_"..i]),numeric=true,allow_decimal=false,allow_negative=false,
      tooltip={"air-logistics.robot-request-help"}}
    amount.style.width=110
  end
  warehouse_content.add{type="flow",name="recovery",direction="vertical",visible=false}
  if tower.interstellar then
    warehouse_content.add{type="label",caption={"air-logistics.fluid-storage"},style="heading_2_label"}
    for i=1,4 do warehouse_content.add{type="label",name="fluid_tank_"..i,caption=""} end
  end
  local frame = columns.add{type = "scroll-pane", name = "settings", horizontal_scroll_policy = "never",
    tags={ports_per_side=T.get(tower).ports_per_side}}
  frame.style.maximal_height = height + 28
  frame.add{type = "label", caption = {"air-logistics.settings"}, style = "heading_2_label"}
  frame.add{type = "label", name = "energy"}
  frame.add{type = "label", name = "status"}
  frame.add{type = "label", name = "planes"}
  if tower.interstellar then frame.add{type="label",name="airplanes"} end
  local options = frame.add{type = "table", name = "options", column_count = 2}
  options.add{type = "checkbox", name = "option_enabled", state = tower.options.enabled, caption = {"air-logistics.enabled"}}
  options.add{type = "empty-widget"}
  for _, key in ipairs({"min_load", "priority"}) do
    options.add{type = "label", caption = {"air-logistics." .. (tower.interstellar and key=="min_load" and "ship-min-load" or "option-"..key)}, tooltip = {"air-logistics.option-" .. key .. "-help"}}
    local field = options.add{type = "textfield", name = "option_" .. key, text = tostring(tower.options[key]),
      numeric = true, allow_decimal = false, allow_negative = false, tooltip = {"air-logistics.option-" .. key .. "-help"}}
    field.style.width = 90
  end
  local mining=frame.add{type="flow",name="mining",direction="vertical"}
  mining.add{type="label",caption={"air-logistics.mining-title"},style="heading_2_label",tooltip={"air-logistics.mining-help"}}
  mining.add{type="label",name="mining_state"}
  mining.add{type="table",name="rows",column_count=4}
  frame.add{type = "label", caption = {"air-logistics."..(tower.interstellar and "ship-hangar" or "hangar")}, tooltip = {"air-logistics.hangar-help"}}
  local aircraft = frame.add{type = "scroll-pane", name = "aircraft", horizontal_scroll_policy = "never"}
  aircraft.style.maximal_height = 80
  local hangar = gui_inventory(aircraft, {type = "inventory", name = "hangar", slots_per_row = 8,
    handle_cursor_transfer = false, handle_cursor_split = false,
    empty_slot_info = {sprite = "item/"..T.get(tower).plane, text = {"air-logistics.hangar-help"}}})
  if hangar then
    hangar.inventory = tower.hangar
  else
    local fallback = frame.add{type = "flow", name = "hangar_fallback", direction = "horizontal"}
    fallback.style.horizontal_spacing = 6
    for _, name in ipairs(tower.interstellar and {T.planet.plane, T.space.plane} or {T.planet.plane}) do
      if T.accepts(tower, name) then
        fallback.add{type = "sprite-button", name = "hangar_take_" .. name, sprite = "item/" .. name,
          style = "slot_button", tooltip = {"air-logistics.hangar-take"}}
        fallback.add{type = "label", name = "hangar_count_" .. name, caption = "0"}
        fallback.add{type = "button", name = "hangar_store_" .. name, caption = "+",
          tooltip = {"air-logistics.hangar-store"}}
      end
    end
  end
  local requests=frame.add{type="table",name="hangar_requests",column_count=2}
  for _,key in ipairs(tower.interstellar and {"plane_request","ship_request"} or {"plane_request"}) do
    requests.add{type="label",caption={"air-logistics."..key},tooltip={"air-logistics.hangar-request-help"}}
    local field=requests.add{type="textfield",name="hangar_"..key,text=tostring(tower.options[key]),numeric=true,allow_decimal=false,allow_negative=false,tooltip={"air-logistics.hangar-request-help"}}
    field.style.width=90
  end
  frame.add{type="label",caption={"air-logistics.robot-platform"},style="heading_2_label"}
  local robots=gui_inventory(frame,{type="inventory",name="robots",slots_per_row=7,handle_cursor_transfer=false,handle_cursor_split=false})
  if robots then robots.inventory=B.inventory(tower) end
  frame.add{type="label",caption={"air-logistics.robot-material"}}
  local material=gui_inventory(frame,{type="inventory",name="robot_material",slots_per_row=7,handle_cursor_transfer=false,handle_cursor_split=false})
  if material then material.inventory=B.inventory(tower,true) end
  local native_grid_buttons = not has_gui_inventory
  local grid = frame.add{type = "table", name = "slots", column_count = native_grid_buttons and 6 or 5}
  for _, key in ipairs({"slot", "item", "mode", "amount", "inventory"}) do
    grid.add{type = "label", caption = {"air-logistics." .. key}}
  end
  if native_grid_buttons then grid.add{type = "label", caption = {"air-logistics.grid"}} end
  for i = 1, N.slots do
    local slot = tower.slots[i]
    grid.add{type = "label", caption = tostring(i)}
    grid.add{
      type = "choose-elem-button", name = "item_" .. i, elem_type = "item-with-quality",
      ["item-with-quality"] = slot and {name = slot.name, quality = slot.quality} or nil
    }
    grid.add{
      type = "drop-down", name = "mode_" .. i,
      items = {{"air-logistics.storage"}, {"air-logistics.supply"}, {"air-logistics.request"}},
      selected_index = slot and mode_index[slot.mode] or 1
    }
    local field = grid.add{
      type = "textfield", name = "count_" .. i, text = tostring(slot and slot.count or 1000),
      numeric = true, allow_decimal = false, allow_negative = false,
      tooltip = {"air-logistics.amount-help"}
    }
    field.style.width = 90
    grid.add{type = "label", name = "stock_" .. i}
    if native_grid_buttons then
      local bin = tower.storage_bins and tower.storage_bins[i]
      grid.add{type = "sprite-button", name = "section_grid_" .. i, sprite = "item/steel-chest",
        style = "slot_button", enabled = bin ~= nil and bin.valid, tooltip = {"air-logistics.grid-help"}}
    end
  end
  if tower.interstellar then
    frame.add{type="label",caption={"air-logistics.fluid-rules"},style="heading_2_label"}
    local fluid = frame.add{type="table",name="fluids",column_count=5}
    for i=1,4 do
      local rule = tower.fluid_rules and tower.fluid_rules[i]
      fluid.add{type="label",caption={"air-logistics.port-"..sides[i],""}}
      fluid.add{type="choose-elem-button",name="fluid_item_"..i,elem_type="fluid",fluid=rule and rule.name}
      fluid.add{type="drop-down",name="fluid_mode_"..i,items={{"air-logistics.storage"},{"air-logistics.supply"},{"air-logistics.request"}},selected_index=rule and mode_index[rule.mode] or 1}
      local amount=fluid.add{type="textfield",name="fluid_count_"..i,text=tostring(rule and rule.count or 10000),numeric=true,allow_decimal=false,allow_negative=false,tooltip={"air-logistics.amount-help"}}
      amount.style.width=90
      fluid.add{type="label",name="fluid_stock_"..i}
    end
  end
  local ports = frame.add{type = "table", name = "ports", column_count = 3}
  ports.style.horizontal_spacing = 8
  for column = 1, 3 do ports.style.column_alignments[column] = "center" end
  for _, side in ipairs({"", "north", "", "west", "center", "east", "", "south", ""}) do
    if side == "" then
      ports.add{type = "empty-widget"}
    elseif side == "center" then
      local preview = ports.add{type = "sprite", name = "center", sprite = T.get(tower).prefix.."-tower-preview",
        resize_to_sprite = false, tooltip = {"air-logistics.port-diagram-help"}}
      preview.style.size = {160, 180}
    else
      local horizontal = side == "north" or side == "south"
      local group = ports.add{type = "flow", name = side, direction = horizontal and "horizontal" or "vertical"}
      if horizontal then group.style.horizontal_spacing = 12 else group.style.vertical_spacing = 52 end
      for i = 1, (frame.tags.ports_per_side or 2)*4 do
        if sides[math.ceil(i / (frame.tags.ports_per_side or 2))] == side then
          local dock = group.add{type = "flow", name = "dock_" .. i, direction = "vertical"}
          dock.style.width = 96
          local header = dock.add{type = "flow", name = "header", direction = "horizontal"}
          header.style.vertical_align = "center"
          header.add{type = "label", caption = {"air-logistics.port-" .. side, (i - 1) % T.get(tower).ports_per_side + 1}}
          header.add{type = "choose-elem-button", name = "port_" .. i, elem_type = "item-with-quality",
            ["item-with-quality"] = tower.port_filters[i], tooltip = {"air-logistics.belt-filter-help"}}
          local label = dock.add{type = "label", name = "port_status_" .. i}
          label.style.font = "default-small"
          label.style.maximal_width = 96
          label.style.single_line = false
        end
      end
    end
  end
  frame.add{type = "label", name = "message", caption = ""}
  local circuit = columns.add{type = "frame", name = "circuit", direction = "vertical",
    caption = {"gui-control-behavior.circuit-connection"}}
  circuit.style.minimal_width = 160
  circuit.style.vertically_stretchable = false
  local networks = circuit.add{type = "frame", name = "networks", direction = "horizontal", style = "subheader_frame"}
  networks.style.horizontally_stretchable = true
  networks.add{type = "label", caption = {"gui-constant.output"}, style = "subheader_caption_label"}
  networks.add{type = "checkbox", name = "circuit_red", state = true, caption = {"air-logistics.red-wire"}}
  networks.add{type = "checkbox", name = "circuit_green", state = true, caption = {"air-logistics.green-wire"}}
  local body = circuit.add{type = "flow", name = "body", direction = "vertical"}
  body.style.horizontally_stretchable = true
  body.style.vertical_spacing = 0
  local contents = body.add{type = "frame", name = "contents", direction = "vertical", style = "shallow_frame"}
  contents.style.horizontally_stretchable = true
  contents.style.padding = 8
  contents.add{type = "checkbox", name = "circuit_contents", state = false, style = "caption_checkbox",
    caption = {"gui-control-behavior-modes.read-contents"}, tooltip = {"gui-control-behavior-modes.read-contents-description"}}
  if has_empty_slot_reader then
  local empty = body.add{type = "frame", name = "empty", direction = "vertical", style = "shallow_frame"}
  empty.style.horizontally_stretchable = true
  empty.style.padding = 8
  empty.add{type = "checkbox", name = "circuit_empty", state = false, style = "caption_checkbox",
    caption = {"gui-control-behavior-modes.container-read-empty-slots"},
    tooltip = {"gui-control-behavior-modes.container-read-empty-slots-description"}}
  local signal = empty.add{type = "flow", name = "empty_signal", direction = "horizontal"}
  signal.style.vertical_align = "center"
  signal.add{type = "label", caption = {"gui-control-behavior-modes-guis.output-signal"}}
  signal.add{type = "choose-elem-button", name = "circuit_empty_signal", elem_type = "signal"}
  end
  refresh(player)
  root.force_auto_center()
  player.opened = root
end

local function apply(player, kind, index)
  local root = player.gui.screen[gui_name]
  if not root then return end
  local frame = root.viewport.content.settings
  local tower = storage.towers[root.tags.tower]
  if tower and tower.entity.valid and tower.entity.force == player.force then
    local values = {}
    if kind=="fluids" and not tower.interstellar then return end
    if kind == "options" then
      local field = frame.options["option_" .. index] or frame.hangar_requests["hangar_" .. index]
      if index == "enabled" then values[index] = field.state else values[index] = field.text end
    elseif kind == "fluids" then
      values = table.deepcopy(tower.fluid_rules or {})
      local name=frame.fluids["fluid_item_"..index].elem_value
      values[index] = name and {name=name,mode=modes[frame.fluids["fluid_mode_"..index].selected_index],count=frame.fluids["fluid_count_"..index].text} or nil
    elseif kind == "ports" then
      for i = 1, (frame.tags.ports_per_side or 2)*4 do
        if tower.port_auto[i] then values[i] = tower.port_filters[i]
        else values[i] = port_control(frame, i).header["port_" .. i].elem_value end
      end
    else
      values = table.deepcopy(tower.slots or {})
      local value = frame.slots["item_" .. index].elem_value
      values[index] = value and {name = value.name, quality = value.quality or "normal",
        mode = modes[frame.slots["mode_" .. index].selected_index], count = frame.slots["count_" .. index].text} or nil
    end
    local valid
    if kind == "options" then valid = N.configure_options(root.tags.tower, values)
    elseif kind == "fluids" then valid=N.configure_fluids(root.tags.tower,values)
    elseif kind == "ports" then valid = N.configure_ports(root.tags.tower, values)
    else valid = N.configure(root.tags.tower, values) end
    frame.message.caption = valid and {"air-logistics.saved"}
      or kind=="fluids" and {"air-logistics.invalid-fluid"} or tower.storage_conflict and {"air-logistics.storage-conflict"} or {"air-logistics.invalid"}
    if valid or not tower.storage_conflict then
      local tags = root.tags
      tags.storage_blocked_message = nil
      root.tags = tags
    end
    refresh(player)
  end
end

local function own_frame(player, element)
  if not element or not element.valid then return end
  local parent = element
  while parent do
    if parent == player.gui.screen[gui_name] then return parent end
    parent = parent.parent
  end
end

script.on_init(N.init)
script.on_event(defines.events.on_resource_depleted,M.depleted)
script.on_event(defines.events.on_runtime_mod_setting_changed,function(event)
  if event.setting:match("^air%-logistics%-mining%-") or event.setting=="air-logistics-solid-gap" or event.setting=="air-logistics-spring-gap" then M.init() end
  if event.setting=="air-logistics-mining-enabled" then
    for _,player in pairs(game.players) do refresh(player) end
  end
end)
script.on_configuration_changed(function()
  N.init()
  for _, player in pairs(game.players) do
    close(player)
    local frame = player.gui.relative.air_logistics_bonuses
    if frame then frame.destroy(); Bonuses.refresh(player, true) end
  end
end)

local function belt_changed(entity)
  if entity and entity.valid then P.invalidate(entity.surface, entity.position, entity.type) end
  if entity and entity.valid and entity.type=="resource" then M.changed(entity.surface,entity.bounding_box) end
end
script.on_event(defines.events.on_chunk_generated,function(event) M.changed(event.surface,event.area) end)
script.on_event({defines.events.on_player_built_tile,defines.events.on_robot_built_tile,defines.events.on_player_mined_tile,defines.events.on_robot_mined_tile,defines.events.script_raised_set_tiles},function(event)
  local tiles=event.tiles
  if not tiles or not tiles[1] then return end
  local p=tiles[1].position
  local area={left_top={x=p.x,y=p.y},right_bottom={x=p.x+1,y=p.y+1}}
  for _,tile in ipairs(tiles) do
    p=tile.position;area.left_top.x=math.min(area.left_top.x,p.x);area.left_top.y=math.min(area.left_top.y,p.y)
    area.right_bottom.x=math.max(area.right_bottom.x,p.x+1);area.right_bottom.y=math.max(area.right_bottom.y,p.y+1)
  end
  M.changed(game.surfaces[event.surface_index],area)
end)

script.on_event({
  defines.events.on_built_entity, defines.events.on_robot_built_entity,
  defines.events.script_raised_built, defines.events.script_raised_revive
}, function(event)
  local tags = event.tags
  if not tags and event.stack and event.stack.valid_for_read and event.stack.is_item_with_tags then
    tags = event.stack.tags
  end
  belt_changed(event.entity)
  N.register(event.entity, tags)
end)

script.on_event({
  defines.events.on_player_mined_entity, defines.events.on_robot_mined_entity,
  defines.events.on_entity_died, defines.events.script_raised_destroy
}, function(event)
  belt_changed(event.entity)
  N.remove(event.entity, event.buffer)
end)

script.on_event(defines.events.on_player_rotated_entity, function(event) belt_changed(event.entity) end)

script.on_event(defines.events.on_entity_cloned, function(event)
  belt_changed(event.destination)
  N.clone(event)
end)

script.on_event(defines.events.on_entity_settings_pasted, function(event)
  local source = event.source.valid and storage.towers[event.source.unit_number]
  local target = event.destination.valid and storage.towers[event.destination.unit_number]
  if source and target and source.entity.force == target.entity.force then
    N.configure(event.destination.unit_number, source.slots)
    N.configure_ports(event.destination.unit_number, source.port_filters)
    local options=deepcopy(source.options)
    if not target.interstellar then options.ship_request=0 end
    N.configure_options(event.destination.unit_number, options)
    if target.interstellar and source.interstellar then N.configure_fluids(event.destination.unit_number,source.fluid_rules) end
    M.register(target,M.tags(source))
  end
end)

script.on_event(defines.events.on_player_setup_blueprint, function(event)
  local player = game.get_player(event.player_index)
  local blueprint = event.stack and event.stack.valid_for_read
    and event.stack.is_blueprint and event.stack or nil
  if not blueprint then blueprint=player.blueprint_to_setup end
  if not blueprint or not blueprint.valid_for_read or not blueprint.is_blueprint then
    blueprint=player.cursor_stack
  end
  if not blueprint or not blueprint.valid_for_read or not blueprint.is_blueprint then return end
  if not event.mapping or not event.mapping.valid then return end
  for index, entity in pairs(event.mapping.get()) do
    local tower = entity.valid and storage.towers[entity.unit_number]
    if tower then
      local entity_tags=blueprint.get_blueprint_entity_tags(index) or {}
      entity_tags["air-logistics"]=deepcopy(tower.slots or {})
      entity_tags["air-logistics-port-filters"]=deepcopy(tower.port_filters or {})
      entity_tags["air-logistics-options"]=deepcopy(tower.options or {})
      entity_tags["air-logistics-fluid-rules"]=tower.interstellar and deepcopy(tower.fluid_rules or {}) or nil
      entity_tags["air-logistics-mining-config"]=M.tags(tower)
      blueprint.set_blueprint_entity_tags(index,entity_tags)
    end
  end
end)

script.on_event(defines.events.on_gui_opened, function(event)
  local player = game.get_player(event.player_index)
  if event.gui_type == defines.gui_type.bonus then Bonuses.refresh(player, true) end
  if event.element and event.element == player.gui.screen[gui_name] then return end
  if N.is_tower(event.entity)
    and event.entity.force == player.force then open(player, event.entity)
  else close(player) end
end)
script.on_event(defines.events.on_gui_closed, function(event) close(game.get_player(event.player_index)) end)
script.on_event({defines.events.on_gui_elem_changed, defines.events.on_gui_text_changed,
  defines.events.on_gui_selection_state_changed, defines.events.on_gui_checked_state_changed}, function(event)
  local player = game.get_player(event.player_index)
  local root = own_frame(player, event.element)
  if not root then return end
  local name = event.element.name
  if name:match("^mining_enabled_%d+$") then
    local tower=storage.towers[root.tags.tower]
    if tower and tower.entity.valid and tower.entity.force==player.force then
      local tags=event.element.tags
      local valid=M.set_enabled(root.tags.tower,tags.kind,tags.resource,event.element.state)
      root.viewport.content.settings.message.caption=valid and {"air-logistics.saved"} or {"air-logistics.invalid"}
      refresh(player)
    end
  elseif name:match("^circuit_") then
    local tower = storage.towers[root.tags.tower]
    if not tower or not tower.entity.valid or tower.entity.force ~= player.force then return end
    local circuit, cb = root.viewport.content.circuit, tower.entity.get_or_create_control_behavior()
    if W.supports_output_networks(cb) then
      cb.output_networks = {red = circuit.networks.circuit_red.state, green = circuit.networks.circuit_green.state}
    end
    cb.read_contents = circuit.body.contents.circuit_contents.state
    if has_empty_slot_reader then
      cb.read_empty_slots = circuit.body.empty.circuit_empty.state
      cb.empty_slots_signal = circuit.body.empty.empty_signal.circuit_empty_signal.elem_value
    end
    W.ensure(tower, true)
    refresh(player)
  elseif name:match("^robot_mode_[1-5]$") then
    local tower = storage.towers[root.tags.tower]
    if tower and tower.entity.valid and tower.entity.force == player.force then
      N.configure_options(root.tags.tower, {[name] = robot_modes[event.element.selected_index]})
      refresh(player)
    end
  elseif name:match("^robot_request_[1-5]$") then
    local tower = storage.towers[root.tags.tower]
    if tower and tower.entity.valid and tower.entity.force == player.force then
      local valid=N.configure_options(root.tags.tower,{[name]=event.element.text})
      root.viewport.content.settings.message.caption=valid and {"air-logistics.saved"} or {"air-logistics.robot-request-invalid"}
      refresh(player)
    end
  elseif name=="hangar_plane_request" or name=="hangar_ship_request" then apply(player,"options",name:gsub("^hangar_", ""))
  elseif name:match("^fluid_") then
    local tower=storage.towers[root.tags.tower]
    if tower and tower.interstellar then apply(player,"fluids",tonumber(name:match("(%d+)$"))) end
  elseif name:match("^port_%d+$") then apply(player, "ports")
  elseif name:match("^item_%d$") or name:match("^mode_%d$") or name:match("^count_%d$") then apply(player, "rules",tonumber(name:match("(%d+)$")))
  elseif event.element.parent.name == "options" then apply(player, "options",name:gsub("^option_", "")) end
end)

local function cargo_click(event)
  local player=game.get_player(event.player_index)
  local root=own_frame(player,event.element)
  local index=tonumber(event.element.name:match("^bank_icon_(%d+)$"))
  if not root or not index then return end
  local tower=storage.towers[root.tags.tower]
  if not tower or not tower.entity.valid or tower.entity.force~=player.force or player.controller_type==defines.controllers.remote or not player.can_reach_entity(tower.entity) then return end
  W.preserve(tower,game.tick,true)
  local rule=tower.effective_slots[index]
  if not rule then return end
  local cursor=player.cursor_stack
  local right=event.button==defines.mouse_button_type.right
  if cursor.valid_for_read then
    if cursor.name~=rule.name or cursor.quality.name~=rule.quality then return end
    if right then
      local temp=game.create_inventory(1)
      temp[1].transfer_stack(cursor,1);W.transfer(tower,temp[1]);cursor.transfer_stack(temp[1]);temp.destroy()
    else W.transfer(tower,cursor) end
  else
    local temporary=not event.shift and game.create_inventory(1)
    local target=temporary or player.get_main_inventory()
    local amount=event.shift and W.count(tower,rule) or math.min(W.count(tower,rule),prototypes.item[rule.name].stack_size)
    if right then amount=math.ceil(amount/2) end
    for _,inv in ipairs(W.inventories(tower)) do
      amount=amount-W.move(inv,target,rule,amount)
      if amount<=0 then break end
    end
    if temporary then cursor.transfer_stack(temporary[1]);temporary.destroy() end
  end
  refresh(player)
end
local function hangar_feedback(player, key)
  player.create_local_flying_text{text = {"air-logistics." .. key}, position = player.position,
    color = {r = 1, g = 0.72, b = 0.25}}
end

local function hangar_store_click(player, root, item_name)
  local tower = storage.towers[root.tags.tower]
  if not tower then return end
  if not tower.entity.valid then log("Air Logistics Tower: hangar store tower entity invalid") return end
  if tower.entity.force ~= player.force then log("Air Logistics Tower: hangar store force mismatch") return end
  if player.controller_type == defines.controllers.remote then
    log("Air Logistics Tower: hangar store refused in remote view")
    hangar_feedback(player, "hangar-refused")
    return
  end
  local bag_inventory = player.get_main_inventory()
  if not bag_inventory then
    hangar_feedback(player, "no-aircraft-in-backpack")
    return
  end
  local source
  for i = 1, #bag_inventory do
    local stack = bag_inventory[i]
    if stack.valid_for_read and stack.name == item_name then
      source = stack
      break
    end
  end
  if not source then
    for i = 1, #bag_inventory do
      local stack = bag_inventory[i]
      if stack.valid_for_read and T.is_aircraft(stack.name) and T.accepts(tower, stack.name) then
        source = stack
        break
      end
    end
  end
  if not source and player.cursor_stack.valid_for_read and player.cursor_stack.name == item_name then
    source = player.cursor_stack
  end
  if not source then
    hangar_feedback(player, "no-aircraft-in-backpack")
    return
  end
  local temporary = game.create_inventory(1)
  if source.count > 1 then temporary[1].transfer_stack(source, 1) else W.transfer_from_stack(temporary, source) end
  if temporary[1].valid_for_read then
    W.transfer_from_stack(tower.hangar, temporary[1])
    if temporary[1].valid_for_read then
      local back = temporary[1]
      if source == player.cursor_stack then player.cursor_stack.transfer_stack(back, back.count)
      else W.transfer_from_stack(bag_inventory, back) end
      log("Air Logistics Tower: hangar refused " .. item_name)
      hangar_feedback(player, "hangar-full")
    end
  end
  temporary.destroy()
  refresh(player)
end

local function open_native_inventory(player, root, entity)
  if not entity or not entity.valid then return end
  local tower = storage.towers[root.tags.tower]
  if not tower or not tower.entity.valid or tower.entity.force ~= player.force then return end
  if player.controller_type == defines.controllers.remote or not player.can_reach_entity(tower.entity) then return end
  if not entity.operable then entity.operable = true end
  local ok, err = pcall(function() player.opened = entity end)
  if not ok then log("Air Logistics Tower: could not open the native grid: " .. tostring(err)) end
end

local function hangar_take_click(player, root, item_name)
  local tower = storage.towers[root.tags.tower]
  if not tower then return end
  if not tower.entity.valid then log("Air Logistics Tower: hangar take tower entity invalid") return end
  if tower.entity.force ~= player.force then log("Air Logistics Tower: hangar take force mismatch") return end
  if player.controller_type == defines.controllers.remote then
    log("Air Logistics Tower: hangar take refused in remote view")
    hangar_feedback(player, "hangar-refused")
    return
  end
  local bag_inventory = player.get_main_inventory()
  if not bag_inventory then return end
  local hangar_inventory = tower.hangar
  local found = false
  for i = 1, #hangar_inventory do
    local stack = hangar_inventory[i]
    if stack.valid_for_read and stack.name == item_name then
      found = true
      local moved = bag_inventory.insert{name = stack.name, quality = stack.quality.name, count = 1}
      if moved and moved > 0 then
        if stack.count > moved then stack.count = stack.count - moved else stack.clear() end
      else
        hangar_feedback(player, "backpack-full")
      end
      break
    end
  end
  if not found then hangar_feedback(player, "hangar-empty") end
  refresh(player)
end
script.on_event(defines.events.on_gui_click,function(event)
  local player=game.get_player(event.player_index)
  local root=own_frame(player,event.element)
  if not root then return end
  local section_grid = event.element.name:match("^section_grid_(%d+)$")
  if section_grid then
    local tower = storage.towers[root.tags.tower]
    if tower then open_native_inventory(player, root, tower.storage_bins and tower.storage_bins[tonumber(section_grid)]) end
    return
  end
  local hangar_store = event.element.name:match("^hangar_store_(.+)$")
  if hangar_store then hangar_store_click(player, root, hangar_store) return end
  local take = event.element.name:match("^hangar_take_(.+)$")
  if take then hangar_take_click(player, root, take) return end
  local legacy=tonumber(event.element.name:match("^legacy_take_(%d+)$"))
  if event.element.name:match("^bank_icon_%d+$") then cargo_click(event)
  elseif legacy then
    local tower=storage.towers[root.tags.tower]
    local inventory=tower and tower.legacy_warehouse[legacy]
    local bag=player.get_main_inventory()
    if inventory and inventory.valid and bag and tower.entity.valid and player.controller_type~=defines.controllers.remote and player.can_reach_entity(tower.entity) then
      W.preserve(tower,game.tick,true)
      for i=1,#inventory do if inventory[i].valid_for_read then W.transfer_from_stack(bag, inventory[i]) end end
      refresh(player)
    end
  elseif event.element.name=="air_logistics_close" then close(player) end
end)

local function on_gui_inventory_action(event)
  local player = game.get_player(event.player_index)
  local frame = own_frame(player, event.element)
  local tower = frame and storage.towers[frame.tags.tower]
  if not tower or not tower.entity.valid or tower.entity.force ~= player.force then return end
  if player.controller_type==defines.controllers.remote or not player.can_reach_entity(tower.entity) then return end
  local bank_index = tonumber(event.element.name:match("^warehouse_(%d+)$"))
  local legacy_page = event.element.name:match("^legacy_%d+$")
  local from_player = event.element.name == "player_inventory"
  local robot_inventory=event.element.name=="robots" or event.element.name=="robot_material"
  if not robot_inventory and event.element.name ~= "hangar" and not bank_index and not legacy_page and not from_player then return end
  W.preserve(tower,game.tick,true)
  local inv = event.element.inventory
  local actions = defines.inventory_actions
  if event.action == actions.cursor_transfer or event.action == actions.cursor_split then
    if from_player then return end
    local cursor, slot = player.cursor_stack, inv[event.slot]
    if not cursor or not slot then return end
    if cursor.valid_for_read then
      if event.element.name == "hangar" and not T.accepts(tower,cursor.name) then return end
      if robot_inventory and not inv.can_insert(cursor) then return end
      if bank_index then
        local rule = tower.effective_slots[bank_index]
        if not rule or cursor.name ~= rule.name or cursor.quality.name ~= (rule.quality or "normal") then return end
      elseif legacy_page then return end
      if not slot.valid_for_read or slot.name == cursor.name and slot.quality == cursor.quality then
        slot.transfer_stack(cursor, event.action == actions.cursor_split and 1 or cursor.count)
      elseif event.action == actions.cursor_transfer then slot.swap_stack(cursor) end
    elseif slot.valid_for_read then
      cursor.transfer_stack(slot, event.action == actions.cursor_split and math.ceil(slot.count / 2) or slot.count)
    end
    refresh(player)
    return
  end
  local target = player.get_main_inventory()
  if not target then return end
  local half = event.action == actions.stack_split or event.action == actions.inventory_split
  local all = event.action == actions.inventory_transfer or event.action == actions.inventory_split
  if not all and event.action ~= actions.stack_transfer and event.action ~= actions.stack_split then return end
  for i = 1, #inv do
    local stack = inv[i]
    if stack.valid_for_read and (all and (not event.item or stack.name == event.item.name
      and stack.quality == event.quality) or not all and i == event.slot) then
      if half then
        local split = game.create_inventory(1)
        split[1].transfer_stack(stack, math.ceil(stack.count / 2))
        if from_player then
          if T.accepts(tower,split[1].name) then W.transfer_from_stack(tower.hangar, split[1])
          elseif split[1].name=="logistic-robot" or split[1].name=="construction-robot" or split[1].name=="repair-pack" then B.transfer(tower,split[1])
          else W.transfer(tower, split[1]) end
        else W.transfer_from_stack(target, split[1]) end
        stack.transfer_stack(split[1])
        split.destroy()
      elseif from_player then
        if T.accepts(tower,stack.name) then W.transfer_from_stack(tower.hangar, stack)
        elseif stack.name=="logistic-robot" or stack.name=="construction-robot" or stack.name=="repair-pack" then B.transfer(tower,stack)
        else W.transfer(tower, stack) end
      else W.transfer_from_stack(target, stack) end
    end
  end
  refresh(player)
end
if has_gui_inventory then script.on_event(defines.events.on_gui_inventory_action, on_gui_inventory_action) end
script.on_event(defines.events.on_player_changed_force, function(event)
  local player = game.get_player(event.player_index)
  close(player)
  Bonuses.refresh(player)
end)
script.on_event(defines.events.on_player_died, function(event) close(game.get_player(event.player_index)) end)

script.on_event({defines.events.on_player_display_resolution_changed, defines.events.on_player_display_scale_changed}, function(event)
  Bonuses.refresh(game.get_player(event.player_index))
end)

script.on_nth_tick(N.step, function(event)
  N.update(event)
  for _, player in pairs(game.connected_players) do
    local root = player.gui.screen[gui_name]
    if root and root.tags.center_after and event.tick >= root.tags.center_after then
      root.force_auto_center()
      local tags = root.tags
      tags.center_after = nil
      root.tags = tags
    end
    if event.tick % 60 == 30 then refresh(player) end
  end
end)
script.on_event({defines.events.on_pre_surface_deleted, defines.events.on_pre_surface_cleared}, function(event)
  N.remove_surface(event.surface_index)
end)
script.on_event(defines.events.on_forces_merged, function(event)
  for _, flight in pairs(storage.flights) do
    if flight.force == event.source_index then flight.force, flight.speed_key = event.destination.index, nil end
  end
  for _, player in pairs(event.destination.players) do Bonuses.refresh(player) end
end)

script.on_event({defines.events.on_force_reset, defines.events.on_technology_effects_reset}, function(event)
  for _, player in pairs(event.force.players) do Bonuses.refresh(player) end
end)

script.on_event({defines.events.on_research_finished, defines.events.on_research_reversed}, function(event)
  if not event.research.name:match("^air%-logistics%-") then return end
  for _, tower in pairs(storage.towers) do
    if tower.entity.valid then W.ensure(tower, true); N.configure_options(tower.entity.unit_number, tower.options) end
  end
  for _, player in pairs(game.players) do refresh(player); Bonuses.refresh(player) end
end)
remote.add_interface("air-logistics-tower", {configure = N.configure, configure_ports = N.configure_ports,
  configure_options = N.configure_options, configure_fluids=N.configure_fluids, inspect = N.inspect})
