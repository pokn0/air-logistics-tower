local N = {}
local deepcopy = require("util").table.deepcopy
local V = require("scripts.visuals")
local P = require("scripts.ports")
local H = require("scripts.hangar")
local W = require("scripts.warehouse")
local C = require("scripts.circuit")
local R = require("scripts.research")
local T = require("scripts.tier")
local F = require("scripts.fluids")
local B = require("scripts.robots")
local M = require("scripts.mining")
N.configure_fluids = F.configure
N.is_tower = T.is_tower
N.configure_ports = P.configure
N.tower_name = "air-logistics-tower"
N.plane_name = "air-cargo-plane"
N.slots = 5
N.step = 1
N.speed = 0.3

local flight_order = {}
local flight_order_members = {}
local tower_count_generation, tower_count_cache = -1, 0
local function flight_ids()
  local keys = flight_order
  local live, unsorted = 0, false
  for id in pairs(storage.flights) do
    live = live + 1
    if not flight_order_members[id] then
      if #keys > 0 and id < keys[#keys] then unsorted = true end
      keys[#keys + 1] = id
      flight_order_members[id] = true
    end
  end
  if live ~= #keys then
    local count, size = 0, #keys
    for i = 1, size do
      local id = keys[i]
      if storage.flights[id] then
        count = count + 1
        keys[count] = id
      else flight_order_members[id] = nil end
    end
    for i = size, count + 1, -1 do keys[i] = nil end
  end
  if unsorted then table.sort(keys) end
  return keys
end
local function ordered(t)
  if t == storage.flights then return flight_ids() end
  local keys = {}
  for key in pairs(t) do keys[#keys + 1] = key end
  table.sort(keys)
  return keys
end

local update_robot_requests

function N.configure_options(id, options)
  if not C.configure(id, options) then return false end
  P.update(storage.towers[id])
  update_robot_requests(storage.towers[id])
  H.request(storage.towers[id])
  return true
end

local function item_id(slot)
  return {name = slot.name, quality = slot.quality or "normal", type=slot.type}
end

local function item_key(slot) return (slot.type or "item").."/"..slot.name.."/"..(slot.quality or "normal") end

local reservation_tick, reservation_deliveries, reservation_pickups, reservation_active
local reservation_spoil_tick
local home_flights_tick, home_flights_index
local EMPTY_FLIGHTS = {}

local function flights_by_home(tick)
  if home_flights_tick ~= tick then
    local index = {}
    for _, flight in pairs(storage.flights) do
      local list = index[flight.home]
      if list then list[#list + 1] = flight else index[flight.home] = {flight} end
    end
    home_flights_tick, home_flights_index = tick, index
  end
  return home_flights_index
end

H.flights_by_home = function(id) return flights_by_home(game.tick)[id] or EMPTY_FLIGHTS end

local function flight_contents(flight)
  local contents, expires = flight.reservation_contents, flight.reservation_spoil_tick
  if contents and (not expires or game.tick < expires) then return contents, expires end
  contents, expires = flight.cargo.get_contents(), nil
  for i = 1, #flight.cargo do
    local stack = flight.cargo[i]
    if stack.valid_for_read then
      local spoil_tick = stack.spoil_tick
      if spoil_tick > 0 then expires = math.min(expires or spoil_tick, spoil_tick) end
    end
  end
  flight.reservation_contents, flight.reservation_spoil_tick = contents, expires
  return contents, expires
end

local function reservations()
  if reservation_tick == game.tick or reservation_tick and (not reservation_spoil_tick or game.tick < reservation_spoil_tick) then
    return reservation_deliveries,reservation_pickups,reservation_active
  end
  reservation_spoil_tick = nil
  local deliveries, pickups, active_counts = {}, {}, {}
  local function reserve(totals,id,slot,amount)
    totals[id] = totals[id] or {}
    local key = item_key(slot)
    totals[id][key] = (totals[id][key] or 0) + amount
  end
  for _, flight in pairs(storage.flights) do
    active_counts[flight.home] = (active_counts[flight.home] or 0) + 1
    if flight.phase == "pickup" then
      reserve(deliveries,flight.receiver,flight.item,flight.reserved)
      reserve(pickups,flight.source,flight.item,flight.reserved)
    elseif flight.phase == "deliver" then
      local contents, expires = flight_contents(flight)
      for _, item in ipairs(contents) do reserve(deliveries,flight.target,item,item.count) end
      if expires then reservation_spoil_tick = math.min(reservation_spoil_tick or expires, expires) end
      if flight.fluid then reserve(deliveries,flight.target,{type="fluid",name=flight.fluid.name},flight.fluid.amount) end
    end
  end
  reservation_tick,reservation_deliveries,reservation_pickups,reservation_active = game.tick,deliveries,pickups,active_counts
  return deliveries,pickups,active_counts
end

local function distance(a, b)
  return math.sqrt((a.x - b.x)^2 + (a.y - b.y)^2)
end

local function usable(tower, flight)
  return tower and tower.entity.valid and (flight.interstellar and tower.interstellar
    or not flight.interstellar and tower.entity.surface.index == flight.surface)
    and tower.entity.force.index == flight.force
end

local function clean_slots(slots)
  if type(slots) ~= "table" then return nil end
  local clean, seen = {}, {}
  for i = 1, N.slots do
    local slot = slots[i]
    if slot and type(slot) ~= "table" then return nil end
    if slot and slot.name then
      local quality = slot.quality or "normal"
      local count = slot.mode == "supply" and 0 or tonumber(slot.count)
      local key = tostring(slot.name) .. "/" .. tostring(quality)
      if type(slot.name) ~= "string" or type(quality) ~= "string"
        or T.is_aircraft(slot.name) or not prototypes.item[slot.name] or not prototypes.quality[quality]
        or (slot.mode ~= "supply" and slot.mode ~= "request" and slot.mode ~= "storage")
        or not count or count ~= count or count < 0 or count > 1000000 or seen[key] then
        return nil
      end
      seen[key] = true
      clean[i] = {name = slot.name, quality = quality, mode = slot.mode, count = math.floor(count)}
    end
  end
  return clean
end

function N.configure(id, slots)
  local tower = storage.towers[id]
  if not tower or not tower.entity.valid then return false end
  tower.storage_conflict = nil
  local clean = clean_slots(slots)
  if not clean then return false end
  if not W.compatible(tower, clean) then tower.storage_conflict = true; return false end
  tower.storage_conflict = nil
  W.reassign_products(tower,clean)
  tower.slots = clean
  C.update(tower)
  P.update(tower)
  return true
end

M.configure=N.configure

function N.register(entity, tags, cloning)
  if not T.is_tower(entity) then return end
  local id = entity.unit_number
  if storage.towers[id] then H.import(storage.towers[id]); return storage.towers[id] end
  local power = entity.surface.create_entity{
    name = T.get({entity=entity}).power, position = entity.position, force = entity.force
  }
  assert(power, "Air Logistics Tower: could not create charging interface")
  power.destructible = false
  local initial_slots = tags and clean_slots(tags["air-logistics"])
  local tower = {entity = entity, power = power, slots = initial_slots or {}, cloning = cloning,
    interstellar = entity.name == T.space.name}
  storage.towers[id] = tower
  storage.tower_generation = (storage.tower_generation or 0) + 1
  W.ensure(tower, true)
  F.ensure(tower)
  if tags and tags["air-logistics-fluid-rules"] then F.configure(id,tags["air-logistics-fluid-rules"]) end
  if tags and tags["air-logistics-fluid-contents"] then F.restore_snapshot(tower,tags["air-logistics-fluid-contents"]) end
  C.ensure(tower)
  B.ensure(tower)
  H.import(tower)
  B.import(tower)
  if tags and tags["air-logistics-options"] then C.configure(id, tags["air-logistics-options"], true) end
  if tags and tags["air-logistics"] then N.configure(id, tags["air-logistics"]) end
  P.ensure(tower)
  if tags and tags["air-logistics-port-filters"] then P.configure(id, tags["air-logistics-port-filters"]) end
  P.update(tower)
  V.tower(tower, game.tick)
  M.register(tower,tags and tags["air-logistics-mining-config"])
  return tower
end

function N.remove(entity, buffer, discard)
  if not T.is_tower(entity) then return end
  local tower = storage.towers[entity.unit_number]
  if not tower then return end
  M.remove(tower)
  if buffer and buffer.valid then
    local stack = buffer.find_item_stack(entity.name)
    if stack then
      stack.set_tag("air-logistics", tower.slots)
      stack.set_tag("air-logistics-port-filters", tower.port_filters)
      stack.set_tag("air-logistics-options", tower.options)
      stack.set_tag("air-logistics-fluid-rules", tower.fluid_rules)
      stack.set_tag("air-logistics-fluid-contents", F.snapshot(tower))
      stack.set_tag("air-logistics-mining-config", M.tags(tower))
    end
  end
  if tower.power and tower.power.valid then tower.power.destroy() end
  V.remove_tower(tower)
  P.remove(tower, buffer, discard)
  H.remove(tower, buffer, discard)
  W.remove(tower, buffer, discard)
  C.remove(tower)
  F.remove(tower)
  B.remove(tower, buffer, discard)
  storage.towers[entity.unit_number] = nil
  storage.tower_generation = (storage.tower_generation or 0) + 1
end

function N.clone(event)
  local original = event.source.valid and storage.towers[event.source.unit_number]
  local target = N.register(event.destination, original and {
    ["air-logistics"] = original.slots, ["air-logistics-port-filters"] = original.port_filters,
    ["air-logistics-options"] = original.options, ["air-logistics-fluid-rules"] = original.fluid_rules,
    ["air-logistics-mining-config"] = M.tags(original)
  }, true)
  if original and target then H.copy(original, target); W.copy(original, target); B.copy(original,target); F.restore_snapshot(target,F.snapshot(original)) end
  if target then target.cloning = nil; P.update(target) end
end

function N.init()
  reservation_tick,home_flights_tick = nil,nil
  storage.towers = storage.towers or {}
  storage.flights = storage.flights or {}
  storage.next_flight = storage.next_flight or 1
  storage.delivered = storage.delivered or 0
  storage.tower_generation = (storage.tower_generation or 0) + 1
  for _, id in ipairs(ordered(storage.towers)) do
    local tower = storage.towers[id]
    V.remove_tower(tower)
    if not tower.entity.valid then
      M.remove(tower)
      if tower.power and tower.power.valid then tower.power.destroy() end
      storage.towers[id] = nil
      P.remove(tower)
      H.remove(tower)
      W.remove(tower)
      C.remove(tower)
      F.remove(tower)
      B.remove(tower)
    else
      if not tower.power or not tower.power.valid then
        tower.power = tower.entity.surface.create_entity{
          name = T.get(tower).power, position = tower.entity.position, force = tower.entity.force
        }
        tower.power.destructible = false
      end
      tower.warehouse_ready = nil
      local slots = deepcopy(tower.slots)
      tower.interstellar = tower.entity.name == T.space.name
      W.repair_bars(tower)
      W.ensure(tower)
      F.ensure(tower)
      C.ensure(tower)
      for _, slot in pairs(tower.effective_slots or {}) do
        if slot.mode == "supply" then slot.count = 0 end
      end
      B.ensure(tower)
      B.import(tower)
      tower.output_signature = nil
      H.import(tower)
      for i, slot in pairs(slots) do
        if not prototypes.item[slot.name] or not prototypes.quality[slot.quality or "normal"] then
          slots[i] = nil
        end
      end
      N.configure(id, slots)
      P.ensure(tower)
      P.update(tower)
      V.tower(tower, game.tick)
    end
  end
  for _, surface in pairs(game.surfaces) do
    for _, entity in pairs(surface.find_entities_filtered{name = {N.tower_name,T.space.name}}) do N.register(entity) end
  end
  for id, flight in pairs(storage.flights) do
    if not game.surfaces[flight.surface] then
      V.remove_flight(flight)
      if flight.cargo and flight.cargo.valid then flight.cargo.destroy() end
      if flight.plane and flight.plane.valid then flight.plane.destroy() end
      storage.flights[id] = nil
    else
      flight.reservation_contents, flight.reservation_spoil_tick = nil, nil
      if not flight.transit_until then V.create_flight(flight); V.draw(flight, game.tick) end
    end
  end
  M.init()
end

local function rules(tower)
  local tier = T.get(tower)
  if tier ~= T.space then return tower.effective_slots end
  local slots, fluid_rules = tower.effective_slots, tower.fluid_rules
  local cache = tower.merged_rules
  if cache and cache.tier == tier and cache.slots == slots and cache.fluid == fluid_rules then
    return cache.value
  end
  local result = deepcopy(slots)
  for i,rule in ipairs(F.rules(tower)) do result[5+i] = rule end
  tower.merged_rules = {tier = tier, slots = slots, fluid = fluid_rules, value = result}
  return result
end
local function count(tower,item)
  return item.type == "fluid" and F.count(tower,item) or W.count(tower,item)
end
local function receiving_limit(tower,item,goal)
  if item.type == "fluid" then return goal end
  return math.min(goal, R.storage_per_bank(tower.entity.force,tower) * W.stack_size(item.name))
end
local function cargo_empty(flight) return flight.cargo.is_empty() and (not flight.fluid or flight.fluid.amount < 0.001) end
local function can_insert(tower,item)
  if item.type == "fluid" then return F.can_insert(tower,item) end
  return W.can_insert(tower,item)
end

local function scan_flights()
  local incoming_by_tower, pickup_by_source = {}, {}
  for _, flight in pairs(storage.flights) do
    local phase = flight.phase
    if phase == "deliver" then
      local list = incoming_by_tower[flight.target]
      if list then list[#list + 1] = flight else incoming_by_tower[flight.target] = {flight} end
    elseif phase == "pickup" then
      local list = incoming_by_tower[flight.receiver]
      if list then list[#list + 1] = flight else incoming_by_tower[flight.receiver] = {flight} end
      list = pickup_by_source[flight.source]
      if list then list[#list + 1] = flight else pickup_by_source[flight.source] = {flight} end
    end
  end
  return incoming_by_tower, pickup_by_source
end

local EMPTY_SCAN = {}

local function incoming(id, slot, exclude, aircraft_only, list)
  local cargo, reserved = 0, 0
  local kind, name, quality = slot.type, slot.name, slot.quality or "normal"
  local filter = kind == "fluid" and nil or item_id(slot)
  local function account(flight)
    if flight == exclude then return end
    if flight.target == id and flight.phase == "deliver" then
      if kind == "fluid" then
        if flight.fluid and flight.fluid.name == name then cargo = cargo + flight.fluid.amount end
      else cargo = cargo + flight.cargo.get_item_count(filter) end
    elseif flight.phase == "pickup" and flight.receiver == id
      and flight.item.type == kind and flight.item.name == name and flight.item.quality == quality then
      reserved = reserved + flight.reserved
    end
  end
  if list then
    for i = 1, #list do account(list[i]) end
  else
    for _, flight in pairs(storage.flights) do account(flight) end
  end
  local robots = not aircraft_only and W.robot_count(storage.towers[id],slot,"deliver") or 0
  return cargo + reserved + robots, cargo + robots, reserved
end

update_robot_requests = function(tower)
  local deliveries, tower_id
  local modes=tower.robot_mode_options==tower.options and tower.robot_mode_snapshot
  for i,slot in pairs(tower.effective_slots) do
    local mode = modes and modes[i] or W.robot_mode(tower,i)
    if mode=="requester" or mode=="buffer" then
      local target=0
      if tower.enabled ~= false then
        local bank=W.inventory(tower,i,true)
        local total, banked = W.count(tower,slot)
        local buffered
        if W.index(tower,slot) == i then buffered = total - banked
        else buffered = total - bank.get_item_count(item_id(slot)) end
        if not deliveries then deliveries, tower_id = reservations(), tower.entity.unit_number end
        local in_flight=deliveries[tower_id]
        local aircraft=in_flight and in_flight[item_key(slot)] or 0
        target=math.max(0,math.min(#bank*W.stack_size(slot.name),
          tower.options["robot_request_"..i]-aircraft-buffered))
      end
      W.request(tower,i,target)
    end
  end
end

local function available(tower, slot, exclude, pickup_list)
  local reserve = 0
  local id = tower.entity.unit_number
  if slot.type ~= "fluid" then
    for _,rule in pairs(tower.effective_slots) do
      if rule.name == slot.name and rule.quality == (slot.quality or "normal") then
        if rule.mode == "request" then return 0 end
        if rule.mode == "supply" then reserve = rule.count end
        break
      end
    end
  end
  local reserved = W.robot_count(tower,slot,"pickup")
  local name, quality = slot.name, slot.quality or "normal"
  local function account(flight)
    if flight ~= exclude and flight.phase == "pickup" and flight.source == id
      and flight.item.type == slot.type and flight.item.name == name and flight.item.quality == quality then
      reserved = reserved + flight.reserved
    end
  end
  if pickup_list then
    for i = 1, #pickup_list do account(pickup_list[i]) end
  else
    for _, flight in pairs(storage.flights) do account(flight) end
  end
  return math.max(0, (slot.type == "fluid" and F.available(tower,slot) or count(tower,item_id(slot))-reserve) - reserved), reserved
end

local function active(id)
  local total = 0
  for _, flight in pairs(storage.flights) do
    if flight.home == id then total = total + 1 end
  end
  return total
end

function N.inspect(id)
  local tower = storage.towers[id]
  if not tower or not tower.entity.valid then return nil end
  local incoming_by_tower, pickup_by_source = scan_flights()
  local counts, pending, buffered = {}, {}, {}
  local enroute, pickups, free, reserved = {}, {}, {}, {}
  for i, slot in pairs(tower.effective_slots) do
    counts[i] = count(tower, item_id(slot))
    if slot.type ~= "fluid" then buffered[i] = counts[i] - W.inventory(tower, i).get_item_count(item_id(slot)) end
    pending[i], enroute[i], pickups[i] = incoming(id, slot, nil, nil, incoming_by_tower[id] or EMPTY_SCAN)
    free[i], reserved[i] = available(tower, slot, nil, pickup_by_source[id] or EMPTY_SCAN)
  end
  local fluid_incoming,fluid_reserved={},{}
  for i=1,4 do
    local rule=tower.fluid_rules and tower.fluid_rules[i]
    if rule then
      local j=5+i
      counts[j]=tower.fluid_ports[i].get_fluid_count(rule.name)
      if rule.mode=="request" then
        if fluid_incoming[rule.name]==nil then fluid_incoming[rule.name]=incoming(id,rule,nil,nil,incoming_by_tower[id] or EMPTY_SCAN) end
        pending[j]=math.min(math.max(0,rule.count-counts[j]),fluid_incoming[rule.name])
        fluid_incoming[rule.name]=fluid_incoming[rule.name]-pending[j]
      else
        local available_here=math.max(0,counts[j]-(rule.mode=="supply" and rule.count or 0))
        if fluid_reserved[rule.name]==nil then local _,amount=available(tower,rule,nil,pickup_by_source[id] or EMPTY_SCAN);fluid_reserved[rule.name]=amount end
        reserved[j]=math.min(available_here,fluid_reserved[rule.name]);fluid_reserved[rule.name]=fluid_reserved[rule.name]-reserved[j]
        free[j]=available_here-reserved[j]
      end
    end
  end
  local planes = 0
  local aircraft_counts={}
  for _,name in ipairs({T.planet.plane,T.space.plane}) do
    aircraft_counts[name]=tower.hangar.get_item_count_filtered{name=name}
    planes=planes+aircraft_counts[name]
  end
  local bank_sizes, byproducts = {}, {}
  for i = 1, N.slots do local inventory = W.inventory(tower, i); bank_sizes[i] = inventory and #inventory or 0 end
  for _, i in ipairs(tower.spoilage_sources or {}) do
    local slot = tower.effective_slots[i]
    for _, item in ipairs(W.inventory(tower,i).get_contents()) do
      if not slot or item.name ~= slot.name or item.quality ~= (slot.quality or "normal") then
        byproducts[i] = byproducts[i] or {}
        byproducts[i][#byproducts[i]+1] = item
      end
    end
  end
  return {
    mining=M.inspect(tower),
    interstellar=tower.interstellar, aircraft_counts=aircraft_counts, airplane_cargo=R.cargo(tower.entity.force,T.planet), airplane_speed=R.speed(tower.entity.force,T.planet)*60, port_count=#P.get_layout(tower), ports_per_side=T.get(tower).ports_per_side,
    fluid_rules=deepcopy(tower.fluid_rules), fluid_capacity=100000, fluid_cargo_capacity=R.fluid_cargo(tower.entity.force),
    max_energy=T.get(tower).energy, power_input=T.get(tower).input, plane_name=T.get(tower).plane,
    slots = deepcopy(tower.effective_slots), counts = counts, incoming = pending, buffered_counts = buffered,
    incoming_cargo = enroute, incoming_pickups = pickups, available_counts = free, reserved_counts = reserved,
    options = deepcopy(tower.options), enabled = tower.enabled,
    min_load = tower.effective_min_load, priority = tower.effective_priority,
    rules_controlled = tower.rules_controlled, filters_controlled = tower.filters_controlled,
    storage_capacity = W.capacity(tower), bank_sizes = bank_sizes, byproducts = byproducts,
    legacy_pages = #(tower.legacy_warehouse or {}), cargo_capacity = R.cargo(tower.entity.force,tower),
    rules_blocked = tower.rules_blocked, storage_conflict = tower.storage_conflict,
    speed = R.speed(tower.entity.force,tower) * 60,
    max_planes = R.planes(tower.entity.force,tower),
    active = active(id), planes = planes, plane_qualities = tower.hangar.get_item_quality_counts(T.get(tower).plane),
    energy = tower.power.valid and tower.power.energy or 0, delivered = storage.delivered,
    visual_state = tower.visual and tower.visual.state or "unpowered",
    port_modes = deepcopy(tower.port_modes), port_filters = deepcopy(tower.effective_port_filters),
    port_speeds = deepcopy(tower.port_speeds), port_auto = deepcopy(tower.port_auto),
    port_input_filters = deepcopy(tower.port_input_filters)
  }
end

local function unload(source, target)
  for i = 1, #source do
    if source[i].valid_for_read then target.transfer_from_stack(source[i]) end
  end
end

local function finish(id, flight)
  V.remove_flight(flight)
  flight.cargo.destroy()
  flight.plane.destroy()
  storage.flights[id] = nil
  reservation_tick,home_flights_tick = nil,nil
end

local function spill(inv, flight)
  local surface = game.surfaces[flight.surface]
  if not surface then return end
  for i = 1, #inv do
    if inv[i].valid_for_read then
      local drops = surface.spill_item_stack{
        position = flight.position, stack = inv[i], enable_looted = true,
        force = game.forces[flight.force], allow_belts = false, use_start_position_on_failure = true
      }
      if #drops > 0 then inv[i].clear() end
    end
  end
end

local function return_destination(flight)
  local home = storage.towers[flight.home]
  if usable(home, flight) then return home end
  local nearest, best
  for _, id in ipairs(ordered(storage.towers)) do
    local tower = storage.towers[id]
    if usable(tower, flight) then
      local d = tower.entity.surface.index == flight.surface and distance(flight.position, tower.entity.position) or 2000
      if not best or d < best then nearest, best, flight.home = tower, d, id end
    end
  end
  if nearest then reservation_tick = nil end
  return nearest
end

local load_cargo = W.move

local function unload_cargo(tower,cargo,item,goal)
  local index = W.index(tower,item)
  local inventory = index and W.inventory(tower,index)
  if not inventory then return 0 end
  local room = math.max(0,receiving_limit(tower,item,goal)-W.count(tower,item))
  return load_cargo(cargo,inventory,item,room)
end

local function load_warehouse(tower, cargo, slot, amount)
  local loaded = 0
  for _, inventory in ipairs(W.sources(tower,slot)) do
    loaded = loaded + load_cargo(inventory, cargo, slot, amount - loaded)
    if loaded >= amount then break end
  end
  for _, bin in ipairs(tower.port_buffers or {}) do
    if loaded >= amount then break end
    if bin.valid then loaded = loaded + load_cargo(bin.get_inventory(defines.inventory.chest), cargo, slot, amount - loaded) end
  end
  return loaded
end

local function flight_cost(d,home,craft) return math.min(T.get(home).energy*0.98, (T.get(craft)==T.space and 5000000 or 1000000) + d * 10000) end

local function restore_cargo(tower, cargo)
  for j = 1, #cargo do
    if cargo[j].valid_for_read then W.restore(tower, cargo[j]) end
  end
  assert(cargo.is_empty(), "Air Logistics Tower: departure rollback could not restore cargo")
end

local function move_to(flight,target,tick,speed,pos,surface)
  pos = pos or target.entity.position
  local destination = flight.destination
  if destination then destination.x, destination.y = pos.x-1, pos.y+2
  else destination = {x=pos.x-1,y=pos.y+2}; flight.destination = destination end
  surface = surface or target.entity.surface.index
  if flight.surface ~= surface then
    if not flight.transit_until then
      flight.departure = flight.departure or {x=flight.position.x,y=flight.position.y-20}
      if not V.move(flight,flight.departure,tick,speed) then return false end
      flight.transit_until = tick + math.max(120,math.ceil(1200*T.space.speed/speed))
      V.remove_flight(flight)
    end
    if tick < flight.transit_until then return false end
    flight.surface,flight.position = surface,{x=pos.x-16,y=pos.y-16}
    flight.transit_until,flight.departure,flight.route,flight.altitude = nil,nil,nil,2
    flight.body_target,flight.shadow_target = nil,nil
    V.create_flight(flight)
  elseif flight.transit_until then
    flight.transit_until,flight.departure,flight.route = nil,nil,nil
    V.create_flight(flight)
  end
  return V.move(flight,destination,tick,speed)
end

local function request_map(tower)
  local cache = tower.request_map_cache
  local slots, fluids = tower.effective_slots, tower.fluid_rules
  if cache and cache.slots == slots and cache.fluids == fluids and cache.revision == tower.request_revision then
    return cache.map
  end
  local map = {}
  for _, slot in pairs(slots or {}) do
    if slot.mode == "request" then map[item_key(slot)] = slot end
  end
  if fluids then
    for _, slot in ipairs(F.rules(tower)) do
      if slot.mode == "request" then map[item_key(slot)] = slot end
    end
  end
  cache = {slots = slots, fluids = fluids, revision = tower.request_revision, map = map}
  tower.request_map_cache = cache
  return map
end

function N.invalidate_requests(tower)
  tower.request_map_cache = nil
  tower.request_revision = (tower.request_revision or 0) + 1
end

local move_speeds, move_requests = {}, {}

local function refresh_tower_state(tower)
  local value = tower.move_state
  if not value then value = {}; tower.move_state = value end
  local entity = tower.entity
  local valid = tower.update_valid_tick == game.tick and tower.update_valid or entity.valid
  value.valid = valid
  if valid then
    value.force, value.surface = entity.force_index, entity.surface_index
    local position = value.position
    if position then
      local current = entity.position
      position.x, position.y = current.x, current.y
    else
      value.position = entity.position
    end
    value.deconstructed = entity.to_be_deconstructed()
  end
  return value
end

local function state_of(tower, tick)
  if tower.move_state_tick ~= tick then
    tower.move_state_tick = tick
    return refresh_tower_state(tower)
  end
  return tower.move_state
end

local function usable_state(value, tower, flight)
  return value.valid and value.force == flight.force
    and (flight.interstellar and tower.interstellar or not flight.interstellar and value.surface == flight.surface)
end

local function move_flights(tick)
  if not next(storage.flights) then return end
  local flight_ids = ordered(storage.flights)
  V.set_fleet_size(#flight_ids)
  if #flight_ids >= 96 then
    if tower_count_generation ~= storage.tower_generation then
      tower_count_cache = 0
      for _ in pairs(storage.towers) do tower_count_cache = tower_count_cache + 1 end
      tower_count_generation = storage.tower_generation
    end
    if #flight_ids >= tower_count_cache * 2 then
      for _, tower in pairs(storage.towers) do
        tower.move_state_tick = tick
        refresh_tower_state(tower)
      end
    end
  end
  local speeds, request_cache = move_speeds, move_requests
  for key in pairs(speeds) do speeds[key] = nil end
  for key in pairs(request_cache) do request_cache[key] = nil end
  local function delivery_slot(tower,flight)
    if not tower.enabled then return end
    local map = request_cache[tower]
    if not map then map = request_map(tower); request_cache[tower] = map end
    flight.item_key = flight.item_key or item_key(flight.item)
    return map[flight.item_key]
  end
  for _, id in ipairs(flight_ids) do
    local flight = storage.flights[id]
    local previous_phase = flight.phase
    local target = storage.towers[flight.target]
    if flight.phase == "pickup" then
      local receiver = storage.towers[flight.receiver]
      local target_state = target and state_of(target, tick)
      if not target_state or not usable_state(target_state, target, flight) or not target.enabled
        or target_state.deconstructed
        or not (receiver and usable_state(state_of(receiver, tick), receiver, flight)) or not delivery_slot(receiver, flight) then
        flight.phase, flight.reserved, flight.turn_until = "return", nil, tick + 40
      end
    end
    if flight.phase == "deliver" then
      local target_state = target and state_of(target, tick)
      if not target_state or not usable_state(target_state, target, flight) or not delivery_slot(target, flight) then
        flight.phase = "return"
        flight.turn_until = tick + 40
      end
    end
    if flight.phase == "return" then
      local home = storage.towers[flight.home]
      target = home and usable_state(state_of(home, tick), home, flight) and home or return_destination(flight)
    end
    if not target then
      if not flight.fluid or flight.fluid.amount < 0.001 then
        spill(flight.cargo, flight); spill(flight.plane, flight)
        if cargo_empty(flight) and flight.plane.is_empty() then finish(id, flight) end
      end
    else
      local key = flight.speed_key
      if not key then
        key = flight.force .. (flight.interstellar and "/space" or "/planet")
        flight.speed_key = key
      end
      local speed = speeds[key]
      if not speed then speed = R.speed(game.forces[flight.force], flight); speeds[key] = speed end
      local destination = state_of(target, tick)
      if move_to(flight,target,tick,speed,destination.position,destination.surface) then
        if flight.phase == "pickup" then
          local receiver = storage.towers[flight.receiver]
          local request = delivery_slot(receiver, flight)
          local amount = math.min(flight.reserved, available(target, flight.item, flight),
            math.max(0, receiving_limit(receiver,flight.item,request.count) - count(receiver, flight.item) - incoming(flight.receiver, flight.item, flight)))
          local loaded = 0
          if amount >= flight.minimum then
            if flight.item.type == "fluid" then flight.fluid = F.load(target,flight.item,amount); loaded = flight.fluid and flight.fluid.amount or 0
            else loaded = load_warehouse(target,flight.cargo,flight.item,amount) end
          end
          if loaded >= flight.minimum then
            flight.phase, flight.target = "deliver", flight.receiver
          else
            restore_cargo(target, flight.cargo)
            if flight.fluid then F.restore(target,flight.fluid) end
            flight.phase = "return"
          end
          flight.reserved, flight.turn_until = nil, tick + 40
          target.launch_until = tick + 90
          V.tower(target, tick)
        elseif flight.phase == "deliver" then
          local request = delivery_slot(target, flight)
          if flight.item.type == "fluid" then
            local remaining = math.max(0,request.count-count(target,flight.item))
            storage.delivered = storage.delivered + F.unload(target,flight.fluid,remaining)
          else
            storage.delivered = storage.delivered + unload_cargo(target,flight.cargo,flight.item,request.count)
          end
          flight.phase = "return"
          flight.turn_until = tick + 40
          target.launch_until = tick + 90
          V.tower(target, tick)
        elseif not flight.unload_tick or tick >= flight.unload_tick then
          flight.unload_tick = tick + 60
          for i = 1, #flight.cargo do
            local stack = flight.cargo[i]
            if stack.valid_for_read then
              local item = {name=stack.name,quality=stack.quality.name}
              local index = W.index(target,item)
              if index then
                local rule = target.effective_slots[index]
                unload_cargo(target,flight.cargo,item,rule.mode == "request" and rule.count or math.huge)
              else
                W.restore(target,stack)
              end
            end
          end
          if flight.fluid then F.restore(target,flight.fluid) end
          if cargo_empty(flight) then unload(flight.plane, target.hangar) end
          if cargo_empty(flight) and flight.plane.is_empty() then finish(id, flight) end
        end
      end
    end
    if flight.phase ~= previous_phase then reservation_tick = nil end
  end
end

local PLANET_CRAFT, SPACE_FIRST_CRAFT, PLANET_FIRST_CRAFT = {T.planet}, {T.space,T.planet}, {T.planet,T.space}
local EMPTY_GROUP = {}
local DISPATCH_STEPS = 15

local dispatch_state
local refresh_state

local function dispatch_begin(ids)
  ids = ids or ordered(storage.towers)
  local s = {
    ids = ids, cursor = 1, progress = false,
    stocks = {}, stock_maps = {}, cached_rules = {}, request_rules = {},
    positions = {}, surfaces = {}, eligible = {}, limits = {}, priorities = {},
    grouped = {}, receivers = {}, request_only = {}, exhausted = {},
    tower_ids = {}, direct_stock = {},
    per_step = math.max(4, math.ceil(#ids / DISPATCH_STEPS)),
    generation = storage.tower_generation,
  }
  s.deliveries, s.pickups, s.active_counts = reservations()
  table.sort(ids, function(a, b)
    local ta, tb = storage.towers[a], storage.towers[b]
    local pa, pb = ta.effective_priority or 0, tb.effective_priority or 0
    local aa, ab = ta.dispatch_turn or 0, tb.dispatch_turn or 0
    return pa > pb or pa == pb and (aa < ab or aa == ab and a < b)
  end)
  for _, id in ipairs(ids) do
    local tower = storage.towers[id]
    if tower.entity.valid and tower.power.valid then
      if tower.power.force ~= tower.entity.force then tower.power.force = tower.entity.force end
      s.positions[id], s.surfaces[id] = tower.entity.position, tower.entity.surface.index
      s.eligible[id] = tower.enabled and not tower.entity.to_be_deconstructed()
      s.limits[id] = R.planes(tower.entity.force,tower)
      s.priorities[id] = tower.effective_priority
      s.tower_ids[tower] = id
      local key = T.group(tower,T.planet)
      local group_keys, group_count = {key}, 1
      local group = s.grouped[key]
      if not group then group = {}; s.grouped[key] = group end
      group[#group + 1] = id
      if tower.interstellar then
        local second=T.group(tower,T.space)
        group_keys[2], group_count = second, 2
        group=s.grouped[second]
        if not group then group={};s.grouped[second]=group end
        group[#group+1]=id
      end
      local tower_rules = s.cached_rules[id]
      if not tower_rules then tower_rules=rules(tower);s.cached_rules[id]=tower_rules end
      local only
      local item_types = 0
      for i = 1, (tower.interstellar and 9 or N.slots) do
        local rule = tower_rules[i]
        if rule and rule.type ~= "fluid" then item_types = item_types + 1 end
        if rule and rule.mode == "request" then
          local rule_key = item_key(rule)
          if only then only[rule_key] = true else only = {[rule_key] = true} end
          for gi = 1, group_count do
            local byitem = s.receivers[group_keys[gi]]
            if not byitem then byitem = {}; s.receivers[group_keys[gi]] = byitem end
            local list = byitem[rule_key]
            if list then list[#list + 1] = id else byitem[rule_key] = {id} end
          end
        end
      end
      s.request_only[id] = only
      s.direct_stock[id] = item_types == 1
        and not (tower.port_buffers and #tower.port_buffers > 0)
        and not (tower.legacy_warehouse and #tower.legacy_warehouse > 0)
        and not (tower.spoilage_sources and #tower.spoilage_sources > 0)
    end
  end
  s.stock = function(tower, slot, source_only)
    local id = s.tower_ids[tower] or tower.entity.unit_number
    local key = item_key(slot)
    local entry = s.stocks[id]
    if not entry then entry = {}; s.stocks[id] = entry end
    local value = entry[key]
    if not value then
      local total
      if slot.type == "fluid" then
        total = F.count(tower, slot)
      elseif s.direct_stock[id] then
        total = W.count(tower,slot)
      else
        local map = s.stock_maps[id]
        if not map then map = W.stock_map(tower); s.stock_maps[id] = map end
        total = W.mapped_count(tower, map, slot.name, slot.quality or "normal")
      end
      local supply = slot.type == "fluid" and F.available(tower,slot) or total
      if slot.type ~= "fluid" then
        local index = W.index(tower,slot)
        local rule = index and tower.effective_slots[index]
        if rule and rule.mode == "request" then supply = 0
        elseif rule and rule.mode == "supply" then supply = supply - rule.count end
      end
      value = {count=total,
        available=math.max(0,supply-(s.pickups[id] and s.pickups[id][key] or 0)-W.robot_count(tower,slot,"pickup"))}
      entry[key] = value
    end
    if not source_only and value.room == nil then
      value.incoming = (s.deliveries[id] and s.deliveries[id][key] or 0)+W.robot_count(tower,slot,"deliver")
      value.room = can_insert(tower,slot)
      value.limit = receiving_limit(tower,slot,math.huge)
    end
    return value
  end
  s.request_rule = function(tower, key)
    local id = s.tower_ids[tower] or tower.entity.unit_number
    local map = s.request_rules[id]
    if map == nil then map = tower.enabled and request_map(tower) or false; s.request_rules[id] = map end
    return map and map[key] or nil
  end
  dispatch_state = s
end

local function dispatch_one(s, home_id)
  local home = storage.towers[home_id]
  if not (home and s.eligible[home_id] and not s.exhausted[home_id]
    and (s.active_counts[home_id] or 0) < s.limits[home_id]) then return false end
  local launched=false
  local crafts=not home.interstellar and PLANET_CRAFT or home.next_craft==2 and SPACE_FIRST_CRAFT or PLANET_FIRST_CRAFT
  local home_force = home.entity.force
  local home_energy = home.power.energy
  local energy_cap = T.get(home).energy * 0.98
  local min_load = (home.effective_min_load or 0) / 100
  local hangar = home.hangar
  for _,craft in ipairs(crafts) do
    local craft_plane = craft.plane
    local plane_stack
    if T.accepts(home,craft_plane) then
      for i = 1, #hangar do
        local stack = hangar[i]
        if stack.valid_for_read and stack.name == craft_plane then plane_stack = stack; break end
      end
    end
    if plane_stack then
      local start = home.next_slot or 1
      local slot_count = home.interstellar and 9 or N.slots
      local home_rules = s.cached_rules[home_id]
      if not home_rules then home_rules=rules(home);s.cached_rules[home_id]=home_rules end
      local cargo_slots = R.cargo(home_force,craft)
      local fluid_cargo = R.fluid_cargo(home_force)
      local cost_base = craft==T.space and 5000000 or 1000000
      local reach = home_energy >= energy_cap and math.huge or (home_energy - cost_base) / 10000
      local craft_group = T.group(home,craft)
      local group = s.grouped[craft_group]
      for offset = 0, slot_count - 1 do
        local i = (start + offset - 1) % slot_count + 1
        local slot = home_rules[i]
        if slot and (slot.mode == "supply" or slot.mode == "request") and (slot.type ~= "fluid" or craft==T.space) then
          local pickup = slot.mode == "request"
          local cargo_size=cargo_slots
          if slot.name=="promethium-asteroid-chunk" then cargo_size=math.min(65535,cargo_slots*math.max(1,math.ceil(50/prototypes.item[slot.name].stack_size))) end
          local capacity = slot.type == "fluid" and fluid_cargo or math.min(W.stack_size(slot.name)*cargo_slots,prototypes.item[slot.name].stack_size*cargo_size)
          local minimum = math.max(1, math.ceil(capacity * min_load))
          local best, target_id, amount, priority, turn
          local slot_key = item_key(slot)
          local ready = false
          local receivers_by_item = not pickup and s.receivers[craft_group]
          local candidates = pickup and group or (receivers_by_item and receivers_by_item[slot_key])
          if candidates and #candidates > 0 and reach >= 0 then
            local home_stock = s.stock(home,slot, not pickup)
            ready = pickup and home_stock.room and slot.count-home_stock.count-home_stock.incoming >= minimum
              or not pickup and home_stock.available >= minimum
          end
          local skipped = pickup and s.request_only
          if ready then
            for gi = 1, #candidates do
              local id = candidates[gi]
              if id ~= home_id and s.eligible[id] and not (skipped and skipped[id] and skipped[id][slot_key]) then
                local candidate_priority = s.priorities[id]
                if not target_id or candidate_priority >= priority then
                  local tower = storage.towers[id]
                  local turns = pickup and tower.supplied_turns or tower.received_turns
                  local candidate_turn = turns and turns[slot_key] or 0
                  if not target_id or candidate_priority > priority or candidate_turn <= turn then
                    local d
                    if s.surfaces[home_id] == s.surfaces[id] then
                      local pa, pb = s.positions[home_id], s.positions[id]
                      local dx, dy = pa.x - pb.x, pa.y - pb.y
                      d = math.sqrt(dx*dx + dy*dy)
                    else d = 2000 end
                    if d <= reach and (not target_id or candidate_priority > priority
                      or candidate_turn < turn or candidate_turn == turn and d < best) then
                      local request = pickup and slot or s.request_rule(tower, slot_key)
                      if request then
                        local receiver_stock = s.stock(pickup and home or tower, slot)
                        local source_stock = s.stock(pickup and tower or home, slot, true)
                        local missing = math.min(request.count,receiver_stock.limit) - receiver_stock.count - receiver_stock.incoming
                        local planned = math.min(source_stock.available, missing, capacity)
                        if planned >= minimum and receiver_stock.room then
                          best, target_id, priority, amount = d, id, candidate_priority, planned
                          turn = candidate_turn
                        end
                      end
                    end
                  end
                end
              end
            end
          end
          if target_id then
            local source_id, receiver_id = pickup and target_id or home_id, pickup and home_id or target_id
            local source, receiver = storage.towers[source_id], storage.towers[receiver_id]
            local cargo, plane = game.create_inventory(cargo_size), game.create_inventory(1)
            local fluid
            local loaded = amount
            if not pickup then
              if slot.type == "fluid" then fluid = F.load(home,slot,amount); loaded = fluid and fluid.amount or 0
              else loaded = load_warehouse(home,cargo,slot,amount) end
            end
            if loaded >= minimum then
              local source_stock, receiver_stock = s.stock(source, slot, true), s.stock(receiver, slot)
              source_stock.available = math.max(0, source_stock.available - loaded)
              if not pickup then source_stock.count = math.max(0, source_stock.count - loaded) end
              receiver_stock.incoming = receiver_stock.incoming + loaded
              s.active_counts[home_id] = (s.active_counts[home_id] or 0) + 1
              plane[1].transfer_stack(plane_stack, 1)
              assert(not plane.is_empty(), "Air Logistics Tower: aircraft allocation failed")
              home_energy = home_energy - flight_cost(best,home,craft)
              home.power.energy = home_energy
              local pos = home.entity.position
              local id = storage.next_flight
              storage.next_flight = id + 1
              reservation_tick,home_flights_tick = nil,nil
              local target_position = storage.towers[target_id].entity.position
              storage.flights[id] = {
                home = home_id, target = target_id, surface = home.entity.surface.index, interstellar=craft==T.space, fluid=fluid,
                source = source_id, receiver = receiver_id, reserved = pickup and amount or nil, minimum = minimum,
                force = home_force.index, position = {x = pos.x-1, y = pos.y+2},
                phase = pickup and "pickup" or "deliver", item = item_id(slot), cargo = cargo, plane = plane,
                heading = (math.atan2(target_position.x - pos.x, -(target_position.y - pos.y)) / (2 * math.pi)) % 1,
                turn_until = game.tick + 8
              }
              source.supplied_turns = source.supplied_turns or {}
              receiver.received_turns = receiver.received_turns or {}
              source.supplied_turns[slot_key], receiver.received_turns[slot_key], home.dispatch_turn = id, id, id
              V.create_flight(storage.flights[id])
              V.draw(storage.flights[id], game.tick)
              home.launch_until = game.tick + 90
              home.last_energy = home_energy
              V.tower(home, game.tick)
              launched = true
              home.next_slot = i % slot_count + 1
              home.next_craft=craft==T.planet and 2 or 1
            else
              restore_cargo(home, cargo)
              if fluid then F.restore(home,fluid) end
              cargo.destroy(); plane.destroy()
            end
          end
        end
        if launched then break end
      end
    end
  end
  s.exhausted[home_id] = not launched
  return launched
end

local function dispatch_step()
  local s = dispatch_state
  if not s then return end
  if s.generation ~= storage.tower_generation then dispatch_state = nil; return end
  local budget = s.per_step
  while budget > 0 do
    if s.cursor > #s.ids then
      if not s.progress then dispatch_state = nil; return end
      s.progress, s.cursor = false, 1
    end
    local home_id = s.ids[s.cursor]
    s.cursor = s.cursor + 1
    budget = budget - 1
    if dispatch_one(s, home_id) then s.progress = true end
  end
end

function N.update(event)
  local tick = event.tick
  for _, tower in pairs(storage.towers) do
    local valid = tower.entity.valid
    tower.update_valid_tick, tower.update_valid = tick, valid
    if valid then W.preserve(tower,tick) end
  end
  if tick % 2 == 0 then
    V.steps = 2
    move_flights(tick)
    V.steps = 1
  end
  local active_counts
  local function active_count(id)
    if not active_counts then local _, _, counts = reservations(); active_counts = counts end
    return active_counts[id] or 0
  end
  for id, tower in pairs(storage.towers) do
    if (tower.update_valid_tick == tick and tower.update_valid) or
       (tower.update_valid_tick ~= tick and tower.entity.valid) then
      local phase = (tick + id) % 60
      if tower.port_scan_dirty then P.update(tower) end
      if (tick + id) % 15 == 0 then
        C.update(tower)
        P.learn(tower)
        H.import(tower, phase == 0)
        V.tower(tower, tick)
        W.ensure(tower); F.ensure(tower)
        update_robot_requests(tower)
        C.publish(tower, tower.read_status and active_count(id) or 0)
      end
      if phase == 0 then
        P.update(tower, true)
        B.ensure(tower); B.import(tower)
      end
      if (tick + id) % (tower.port_interval or P.interval) == 0 then P.tick(tower) end
    end
  end
  if tick % 60 == 0 then
    local tower_ids = ordered(storage.towers)
    dispatch_begin(tower_ids)
    refresh_state = {ids = tower_ids, cursor = 1, per_step = math.max(1, math.ceil(#tower_ids / 60))}
  end
  if refresh_state then
    local ids, budget = refresh_state.ids, refresh_state.per_step
    while budget > 0 and refresh_state.cursor <= #ids do
      local id = ids[refresh_state.cursor]
      local tower = storage.towers[id]
      refresh_state.cursor = refresh_state.cursor + 1
      budget = budget - 1
      if tower then
        if tower.entity.valid then
          H.request(tower)
        else
          M.remove(tower)
          if tower.power and tower.power.valid then tower.power.destroy() end
          V.remove_tower(tower)
          P.remove(tower)
          H.remove(tower)
          W.remove(tower)
          C.remove(tower)
          F.remove(tower)
          B.remove(tower)
          storage.towers[id] = nil
          storage.tower_generation = storage.tower_generation + 1
        end
      end
    end
    if refresh_state.cursor > #ids then refresh_state = nil end
  end
  dispatch_step()
  M.update(tick)
end

function N.remove_surface(index)
  reservation_tick, home_flights_tick = nil, nil
  local tower_ids = ordered(storage.towers)
  local fallback = {}
  for _, tower_id in ipairs(tower_ids) do
    local tower = storage.towers[tower_id]
    if tower.entity.valid and tower.interstellar and tower.entity.surface_index ~= index then
      local force = tower.entity.force_index
      if not fallback[force] then fallback[force] = tower end
    end
  end
  for _, id in ipairs(ordered(storage.flights)) do
    local flight = storage.flights[id]
    if flight.surface == index then
      if not flight.interstellar then
        finish(id, flight)
      else
        local safe
        for _,tower_id in ipairs({flight.receiver,flight.home,flight.source}) do
          local tower=storage.towers[tower_id]
          if usable(tower,flight) and tower.entity.surface_index ~= index then safe=tower;break end
        end
        if not safe then safe=fallback[flight.force] end
        if safe then
          V.remove_flight(flight)
          local pos=safe.entity.position
          flight.surface,flight.position=safe.entity.surface_index,{x=pos.x,y=pos.y-16}
          flight.home,flight.target=safe.entity.unit_number,safe.entity.unit_number
          flight.phase,flight.reserved,flight.transit_until,flight.route,flight.departure="return",nil,nil,nil,nil
        else
          finish(id,flight)
        end
      end
    end
  end
  for _, tower_id in ipairs(tower_ids) do
    local tower=storage.towers[tower_id]
    if tower and tower.entity.valid and tower.entity.surface_index == index then
      N.remove(tower.entity,nil,true)
    end
  end
end

return N
